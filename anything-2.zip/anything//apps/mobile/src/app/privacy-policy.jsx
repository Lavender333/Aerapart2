import { View, Text, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useRouter } from "expo-router";
import { ArrowLeft } from "lucide-react-native";

export default function PrivacyPolicyScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  return (
    <View style={{ flex: 1, backgroundColor: "#FFFFFF" }}>
      <StatusBar style="dark" />

      <View
        style={{
          paddingTop: insets.top + 16,
          paddingHorizontal: 20,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <ArrowLeft size={24} color="#000000" onPress={() => router.back()} />
          <Text style={{ fontSize: 20, fontWeight: "600", color: "#000000" }}>
            Privacy Policy
          </Text>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 20,
          paddingBottom: insets.bottom + 40,
        }}
        showsVerticalScrollIndicator={false}
      >
        <Text style={{ fontSize: 12, color: "#6B7280", marginBottom: 24 }}>
          Last updated: February 7, 2026
        </Text>

        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 12,
              color: "#000000",
            }}
          >
            1. Data Collected
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 12,
            }}
          >
            AERA collects the following information to provide emergency
            disaster relief services:
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Location Data:</Text> Your
            real-time GPS location when you enable live location sharing, both
            when the app is in use (foreground) and when monitoring is active
            (background)
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Safety Status:</Text> Your
            reported safety status (safe, need help, emergency)
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            •{" "}
            <Text style={{ fontWeight: "600" }}>Emergency Help Requests:</Text>{" "}
            Messages and details you submit when requesting assistance
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Account Information:</Text>{" "}
            Email address, name, and authentication data
          </Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: "#374151" }}>
            • <Text style={{ fontWeight: "600" }}>Household Data:</Text>{" "}
            Information about your household members and their safety status
          </Text>
        </View>

        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 12,
              color: "#000000",
            }}
          >
            2. How Data Is Collected
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>User Input:</Text> Information
            you provide when creating an account, updating your profile, or
            submitting help requests
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Device Permissions:</Text> GPS
            location data when you grant location access
          </Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: "#374151" }}>
            • <Text style={{ fontWeight: "600" }}>Background Services:</Text>{" "}
            Continuous location tracking when you activate safety monitoring
            (only when explicitly enabled by you)
          </Text>
        </View>

        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 12,
              color: "#000000",
            }}
          >
            3. How Data Is Used
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 12,
            }}
          >
            Your data is used exclusively for:
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Safety Monitoring:</Text>{" "}
            Tracking your location during active safety monitoring to enable
            emergency response
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            •{" "}
            <Text style={{ fontWeight: "600" }}>
              Emergency Response Coordination:
            </Text>{" "}
            Sharing your location and status with your designated response team
            when you request help
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 12,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>App Functionality:</Text>{" "}
            Providing core features like household tracking, inventory
            management, and alerts
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#6B7280",
              fontStyle: "italic",
            }}
          >
            We do not use your data for advertising, marketing, or any purpose
            unrelated to emergency disaster relief.
          </Text>
        </View>

        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 12,
              color: "#000000",
            }}
          >
            4. Data Sharing
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 12,
            }}
          >
            Your data is shared only as follows:
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Response Team:</Text> Your
            real-time location and safety status are shared with members of your
            organization's emergency response team when you activate live
            location sharing or submit a help request
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Organization Members:</Text>{" "}
            Information you choose to share within your organization (such as
            household status updates)
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>No Third-Party Sales:</Text>{" "}
            We never sell your personal data to third parties
          </Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: "#374151" }}>
            • <Text style={{ fontWeight: "600" }}>No External Sharing:</Text>{" "}
            Your data is not shared with advertisers or external services except
            as required by law
          </Text>
        </View>

        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 12,
              color: "#000000",
            }}
          >
            5. User Consent
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 12,
            }}
          >
            You are in control of your data:
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • Location access requires explicit permission through iOS system
            prompts
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • Live location sharing requires additional in-app consent
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • You can turn off location sharing at any time through the app
          </Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: "#374151" }}>
            • You can manage permissions in your device Settings
          </Text>
        </View>

        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 12,
              color: "#000000",
            }}
          >
            6. Data Retention & Deletion
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Active Data:</Text> Your data
            is retained while you have an active account
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Location History:</Text>{" "}
            Real-time location data is used for immediate emergency response and
            is not stored long-term
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Account Deletion:</Text> You
            can delete your account directly from the app (Settings → Delete
            Account) or by contacting support. All your personal data will be
            permanently removed within 30 days.
          </Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: "#374151" }}>
            • <Text style={{ fontWeight: "600" }}>Inactive Accounts:</Text>{" "}
            Accounts inactive for 2 years may be automatically deleted
          </Text>
        </View>

        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 12,
              color: "#000000",
            }}
          >
            7. User Rights
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 12,
            }}
          >
            You have the right to:
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Access:</Text> Request a copy
            of your personal data
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Correction:</Text> Update or
            correct your information through the app
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            • <Text style={{ fontWeight: "600" }}>Deletion:</Text> Request
            permanent deletion of your account and data
          </Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: "#374151" }}>
            • <Text style={{ fontWeight: "600" }}>Opt-Out:</Text> Disable
            location sharing or other features at any time
          </Text>
        </View>

        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 12,
              color: "#000000",
            }}
          >
            8. Contact Information
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#374151",
              marginBottom: 8,
            }}
          >
            For privacy concerns, data requests, or account deletion:
          </Text>
          <Text
            style={{
              fontSize: 15,
              lineHeight: 22,
              color: "#000000",
              fontWeight: "600",
              marginBottom: 8,
            }}
          >
            Email: aerapp369@gmail.com
          </Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: "#6B7280" }}>
            We will respond to all privacy-related inquiries within 7 business
            days.
          </Text>
        </View>

        <View style={{ marginBottom: 32 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 12,
              color: "#000000",
            }}
          >
            9. Changes to This Policy
          </Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: "#374151" }}>
            We may update this privacy policy as our services evolve.
            Significant changes will be communicated through the app or via
            email. Continued use of the app after changes constitutes acceptance
            of the updated policy.
          </Text>
        </View>

        <View
          style={{ padding: 16, backgroundColor: "#EFF6FF", borderRadius: 8 }}
        >
          <Text style={{ fontSize: 14, lineHeight: 20, color: "#374151" }}>
            <Text style={{ fontWeight: "600" }}>Questions?</Text> If you have
            any questions about this privacy policy or how we handle your data,
            please contact us at aerapp369@gmail.com
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
