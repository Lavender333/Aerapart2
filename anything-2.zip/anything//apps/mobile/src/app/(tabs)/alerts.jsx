import React from "react";
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Bell,
  Info,
  AlertTriangle,
  CheckCircle,
  ChevronRight,
} from "lucide-react-native";
import { useQuery } from "@tanstack/react-query";
import { StatusBar } from "expo-status-bar";

const fetchAlerts = async () => {
  const res = await fetch("/api/disaster-relief/alerts");
  if (!res.ok) throw new Error("Failed to fetch alerts");
  return res.json();
};

export default function AlertsScreen() {
  const insets = useSafeAreaInsets();
  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ["alerts"],
    queryFn: fetchAlerts,
  });

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#1A5DFF" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View className="mb-8 flex-row justify-between items-center">
          <View>
            <Text style={styles.title}>Broadcasts</Text>
            <Text style={styles.subtitle}>
              Critical updates from Central Command.
            </Text>
          </View>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{alerts.length}</Text>
          </View>
        </View>

        {alerts.length === 0 ? (
          <View style={styles.emptyState}>
            <Bell size={48} color="#D1D5DB" />
            <Text style={styles.emptyText}>No active alerts at this time.</Text>
          </View>
        ) : (
          alerts.map((alert) => (
            <TouchableOpacity
              key={alert.id}
              style={styles.alertCard}
              activeOpacity={0.7}
            >
              <View style={styles.alertHeader}>
                <View style={styles.iconBox}>
                  <AlertTriangle size={20} color="#FF3D3D" />
                </View>
                <View className="flex-1 ml-4">
                  <Text style={styles.alertTitle}>{alert.title}</Text>
                  <Text style={styles.alertTime}>
                    {new Date(alert.created_at).toLocaleDateString()} at{" "}
                    {new Date(alert.created_at).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </Text>
                </View>
                <ChevronRight size={16} color="#D1D5DB" />
              </View>
              <Text style={styles.alertMessage}>{alert.message}</Text>
            </TouchableOpacity>
          ))
        )}

        <View style={styles.emergencyCard}>
          <Text style={styles.emergencyTitle}>Need to broadcast?</Text>
          <Text style={styles.emergencyText}>
            Only authorized personnel can send organization-wide alerts.
          </Text>
          <TouchableOpacity style={styles.requestButton}>
            <Text style={styles.requestButtonText}>REQUEST ACCESS</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  title: {
    fontSize: 32,
    fontWeight: "800",
    color: "#111827",
    fontFamily: "Bricolage Grotesque",
  },
  subtitle: {
    fontSize: 16,
    color: "#6B7280",
    marginTop: 4,
  },
  badge: {
    backgroundColor: "#FF3D3D",
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
  },
  badgeText: {
    color: "white",
    fontSize: 14,
    fontWeight: "900",
  },
  emptyState: {
    alignItems: "center",
    paddingVertical: 60,
  },
  emptyText: {
    marginTop: 16,
    color: "#9CA3AF",
    fontSize: 16,
    fontWeight: "500",
  },
  alertCard: {
    backgroundColor: "white",
    borderRadius: 24,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#F3F4F6",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
  },
  alertHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  iconBox: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: "#FEE2E2",
    justifyContent: "center",
    alignItems: "center",
  },
  alertTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: "#1F2937",
    fontFamily: "Bricolage Grotesque",
  },
  alertTime: {
    fontSize: 12,
    color: "#9CA3AF",
    marginTop: 2,
  },
  alertMessage: {
    fontSize: 14,
    color: "#4B5563",
    lineHeight: 20,
  },
  emergencyCard: {
    backgroundColor: "#111827",
    borderRadius: 24,
    padding: 24,
    marginTop: 20,
  },
  emergencyTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "white",
    fontFamily: "Bricolage Grotesque",
  },
  emergencyText: {
    fontSize: 14,
    color: "#9CA3AF",
    marginTop: 4,
    marginBottom: 20,
  },
  requestButton: {
    backgroundColor: "#374151",
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: "center",
  },
  requestButtonText: {
    color: "white",
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 1,
  },
});
