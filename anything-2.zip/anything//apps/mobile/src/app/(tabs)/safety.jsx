import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  StyleSheet,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Shield,
  CheckCircle,
  XCircle,
  HelpCircle,
  ChevronRight,
  MapPin,
} from "lucide-react-native";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { StatusBar } from "expo-status-bar";

const fetchSafety = async () => {
  const res = await fetch("/api/disaster-relief/safety");
  if (!res.ok) throw new Error("Failed to fetch safety status");
  return res.json();
};

export default function SafetyScreen() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();

  const { data: households = [], isLoading } = useQuery({
    queryKey: ["safetyStatus"],
    queryFn: fetchSafety,
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }) => {
      const res = await fetch("/api/disaster-relief/safety", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status }),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["safetyStatus"] });
    },
  });

  const handleStatusUpdate = (memberId, name, currentStatus) => {
    Alert.alert(
      `Update Status for ${name}`,
      `Current status: ${currentStatus}`,
      [
        {
          text: "Safe",
          onPress: () =>
            updateStatusMutation.mutate({ id: memberId, status: "safe" }),
        },
        {
          text: "Needs Help",
          onPress: () =>
            updateStatusMutation.mutate({ id: memberId, status: "needs_help" }),
        },
        { text: "Cancel", style: "cancel" },
      ],
    );
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "safe":
        return "#10B981";
      case "needs_help":
        return "#EF4444";
      case "unsafe":
        return "#F59E0B";
      default:
        return "#9CA3AF";
    }
  };

  const getStatusIcon = (status) => {
    const color = getStatusColor(status);
    switch (status) {
      case "safe":
        return <CheckCircle size={18} color={color} />;
      case "needs_help":
        return <XCircle size={18} color={color} />;
      default:
        return <HelpCircle size={18} color={color} />;
    }
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#1A5DFF" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View className="mb-8">
          <Text style={styles.title}>Safety Tracking</Text>
          <Text style={styles.subtitle}>
            Keep your household status updated for responders.
          </Text>
        </View>

        {households.map((household) => (
          <View key={household.id} style={styles.householdCard}>
            <View style={styles.householdHeader}>
              <View>
                <Text style={styles.householdName}>{household.name}</Text>
                <View className="flex-row items-center mt-1">
                  <MapPin size={12} color="#6B7280" />
                  <Text style={styles.householdAddress}>
                    {household.address}
                  </Text>
                </View>
              </View>
              <View style={styles.badge}>
                <Text style={styles.badgeText}>
                  {household.members.length} MEMBERS
                </Text>
              </View>
            </View>

            <View style={styles.memberList}>
              {household.members.map((member) => (
                <TouchableOpacity
                  key={member.id}
                  style={styles.memberItem}
                  onPress={() =>
                    handleStatusUpdate(member.id, member.name, member.status)
                  }
                >
                  <View className="flex-row items-center">
                    <View
                      style={[
                        styles.statusDot,
                        { backgroundColor: getStatusColor(member.status) },
                      ]}
                    />
                    <View>
                      <Text style={styles.memberName}>{member.name}</Text>
                      <Text style={styles.memberStatus}>
                        Last seen:{" "}
                        {new Date(member.last_seen).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </Text>
                    </View>
                  </View>
                  <View className="flex-row items-center">
                    <View
                      style={[
                        styles.statusBadge,
                        {
                          backgroundColor: getStatusColor(member.status) + "15",
                        },
                      ]}
                    >
                      <Text
                        style={[
                          styles.statusBadgeText,
                          { color: getStatusColor(member.status) },
                        ]}
                      >
                        {member.status.toUpperCase()}
                      </Text>
                    </View>
                    <ChevronRight
                      size={16}
                      color="#D1D5DB"
                      style={{ marginLeft: 8 }}
                    />
                  </View>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity style={styles.addButton}>
              <Text style={styles.addButtonText}>+ ADD MEMBER</Text>
            </TouchableOpacity>
          </View>
        ))}

        <View style={styles.infoCard}>
          <Shield size={24} color="#1A5DFF" />
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={styles.infoTitle}>Privacy Notice</Text>
            <Text style={styles.infoText}>
              Your safety status is only visible to verified responders and your
              organization's emergency coordinators.
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  title: {
    fontSize: 32,
    fontWeight: "800",
    color: "#111827",
    fontFamily: "Bricolage Grotesque",
  },
  subtitle: {
    fontSize: 16,
    color: "#6B7280",
    marginTop: 4,
  },
  householdCard: {
    backgroundColor: "white",
    borderRadius: 32,
    padding: 24,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#F3F4F6",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 15,
  },
  householdHeader: {
    flexDirection: "row",
    justifyContent: "between",
    alignItems: "start",
    marginBottom: 24,
  },
  householdName: {
    fontSize: 20,
    fontWeight: "800",
    color: "#111827",
    fontFamily: "Bricolage Grotesque",
  },
  householdAddress: {
    fontSize: 13,
    color: "#6B7280",
    marginLeft: 4,
  },
  badge: {
    backgroundColor: "#F3F4F6",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: "800",
    color: "#4B5563",
  },
  memberList: {
    gap: 12,
  },
  memberItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#F9FAFB",
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 12,
  },
  memberName: {
    fontSize: 15,
    fontWeight: "700",
    color: "#1F2937",
  },
  memberStatus: {
    fontSize: 12,
    color: "#9CA3AF",
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusBadgeText: {
    fontSize: 10,
    fontWeight: "800",
  },
  addButton: {
    marginTop: 20,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderStyle: "dashed",
    borderRadius: 16,
    alignItems: "center",
  },
  addButtonText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#6B7280",
  },
  infoCard: {
    backgroundColor: "#EFF6FF",
    padding: 20,
    borderRadius: 24,
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#1E40AF",
    marginBottom: 2,
  },
  infoText: {
    fontSize: 12,
    color: "#1E40AF",
    lineHeight: 18,
    opacity: 0.8,
  },
});
