import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  ActivityIndicator,
  Alert,
  StyleSheet,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  AlertTriangle,
  MapPin,
  Send,
  Info,
  Home as HomeIcon,
  Package,
  HelpCircle,
} from "lucide-react-native";
import * as Location from "expo-location";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import { StatusBar } from "expo-status-bar";
import useUser from "@/utils/auth/useUser";
import { useAuth } from "@/utils/auth/useAuth";

const fetchOrganizations = async () => {
  const res = await fetch("/api/organizations");
  if (!res.ok) throw new Error("Failed to fetch organizations");
  return res.json();
};

const fetchUserRole = async () => {
  const res = await fetch("/api/users/role");
  if (!res.ok) throw new Error("Failed to fetch user role");
  return res.json();
};

const fetchHelpRequests = async () => {
  const res = await fetch("/api/help-requests");
  if (!res.ok) throw new Error("Failed to fetch help requests");
  return res.json();
};

export default function SOSScreen() {
  const insets = useSafeAreaInsets();
  const { data: user, loading: userLoading } = useUser();
  const { signIn, isReady, isAuthenticated } = useAuth();
  const queryClient = useQueryClient();

  // Fetch user role info
  const { data: roleInfo, isLoading: roleLoading } = useQuery({
    queryKey: ["userRole"],
    queryFn: fetchUserRole,
    enabled: isReady && isAuthenticated,
  });

  const { data: organizations = [] } = useQuery({
    queryKey: ["organizations"],
    queryFn: fetchOrganizations,
    enabled: isReady && isAuthenticated,
  });

  const selectedOrg = organizations[0];

  const isSystemAdmin = roleInfo?.user?.system_role === "system_admin";
  const isOrgAdmin = roleInfo?.organizations?.some(
    (org) => org.role === "org_admin" || org.role === "admin",
  );
  const isGeneralUser =
    !isSystemAdmin && !isOrgAdmin && roleInfo?.organizations?.length > 0;

  if (!isReady || userLoading || roleLoading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#F9FAFB",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text style={{ marginTop: 12, color: "#6B7280" }}>Loading...</Text>
      </View>
    );
  }

  if (!isAuthenticated) {
    return <UnauthenticatedView signIn={signIn} insets={insets} />;
  }

  // GENERAL USER VIEW
  if (isGeneralUser) {
    const userOrg = roleInfo?.organizations?.[0];
    return <GeneralUserView userOrg={userOrg} user={user} insets={insets} />;
  }

  // ADMIN VIEW (System Admin or Org Admin)
  return <AdminView user={user} selectedOrg={selectedOrg} insets={insets} />;
}

// Unauthenticated View
function UnauthenticatedView({ signIn, insets }) {
  return (
    <KeyboardAvoidingAnimatedView
      style={{ flex: 1, backgroundColor: "#F7F9FC" }}
      behavior="padding"
    >
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ marginBottom: 24 }}>
          <Text style={styles.title}>Emergency Assistance</Text>
          <Text style={styles.subtitle}>
            Help is available when you need it
          </Text>
        </View>

        <View style={styles.authPrompt}>
          <Info size={24} color="#3B82F6" />
          <Text style={styles.authText}>
            Please sign in to access emergency services
          </Text>
          <TouchableOpacity
            onPress={() => signIn()}
            style={styles.signInButton}
          >
            <Text style={styles.signInButtonText}>Sign In</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingAnimatedView>
  );
}

// General User View - Simple Help Request Interface
function GeneralUserView({ userOrg, user, insets }) {
  const queryClient = useQueryClient();

  const { data: helpRequestsData } = useQuery({
    queryKey: ["helpRequests"],
    queryFn: fetchHelpRequests,
  });

  const createHelpRequest = useMutation({
    mutationFn: async (data) => {
      const res = await fetch("/api/help-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create help request");
      return res.json();
    },
    onSuccess: () => {
      Alert.alert(
        "Request Submitted",
        "Your organization has been notified and will respond soon.",
      );
      queryClient.invalidateQueries({ queryKey: ["helpRequests"] });
    },
    onError: (error) => {
      Alert.alert("Error", "Failed to submit request. Please try again.");
    },
  });

  const handleHelpRequest = (requestType, title) => {
    Alert.alert(title, `Submit a request for ${title.toLowerCase()}?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Submit",
        onPress: () => {
          createHelpRequest.mutate({
            org_id: userOrg?.org_id,
            request_type: requestType,
            message: "",
            priority: "medium",
          });
        },
      },
    ]);
  };

  return (
    <KeyboardAvoidingAnimatedView
      style={{ flex: 1, backgroundColor: "#F7F9FC" }}
      behavior="padding"
    >
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ marginBottom: 24 }}>
          <Text style={styles.subtitle}>Welcome back</Text>
          <Text style={styles.title}>{user?.name || user?.email}</Text>
          {userOrg && (
            <View style={styles.orgCard}>
              <HomeIcon size={20} color="#3B82F6" />
              <View style={{ marginLeft: 12, flex: 1 }}>
                <Text style={styles.orgLabel}>Your Organization</Text>
                <Text style={styles.orgName}>{userOrg.org_name}</Text>
                {userOrg.address && (
                  <Text style={styles.orgAddress}>{userOrg.address}</Text>
                )}
              </View>
            </View>
          )}
        </View>

        <Text style={styles.sectionTitle}>Need Assistance?</Text>

        <HelpButton
          icon={<Package size={24} color="#3B82F6" />}
          title="Food & Water"
          description="Request food or water supplies"
          onPress={() => handleHelpRequest("food", "Food & Water")}
          disabled={createHelpRequest.isLoading}
        />

        <HelpButton
          icon={<AlertTriangle size={24} color="#EF4444" />}
          title="Medical Help"
          description="Request medical assistance"
          onPress={() => handleHelpRequest("medical", "Medical Help")}
          disabled={createHelpRequest.isLoading}
        />

        <HelpButton
          icon={<HomeIcon size={24} color="#10B981" />}
          title="Shelter"
          description="Request shelter or housing"
          onPress={() => handleHelpRequest("shelter", "Shelter")}
          disabled={createHelpRequest.isLoading}
        />

        <HelpButton
          icon={<MapPin size={24} color="#F59E0B" />}
          title="Transportation"
          description="Request transportation help"
          onPress={() => handleHelpRequest("transport", "Transportation")}
          disabled={createHelpRequest.isLoading}
        />

        <HelpButton
          icon={<HelpCircle size={24} color="#8B5CF6" />}
          title="Other"
          description="Other assistance needed"
          onPress={() => handleHelpRequest("other", "Other")}
          disabled={createHelpRequest.isLoading}
        />

        <Text style={[styles.sectionTitle, { marginTop: 24 }]}>
          My Requests
        </Text>
        <MyRequestsList requests={helpRequestsData?.requests || []} />
      </ScrollView>
    </KeyboardAvoidingAnimatedView>
  );
}

// Help Button Component
function HelpButton({ icon, title, description, onPress, disabled }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      style={styles.helpButton}
    >
      <View style={styles.helpButtonIcon}>{icon}</View>
      <View style={{ marginLeft: 16, flex: 1 }}>
        <Text style={styles.helpButtonTitle}>{title}</Text>
        <Text style={styles.helpButtonDesc}>{description}</Text>
      </View>
      {disabled && <ActivityIndicator size="small" color="#3B82F6" />}
    </TouchableOpacity>
  );
}

// My Requests List
function MyRequestsList({ requests }) {
  if (requests.length === 0) {
    return (
      <View style={styles.emptyState}>
        <Text style={styles.emptyText}>No requests yet</Text>
      </View>
    );
  }

  return (
    <View>
      {requests.slice(0, 5).map((req) => (
        <View
          key={req.id}
          style={[
            styles.requestCard,
            {
              borderLeftColor:
                req.status === "resolved"
                  ? "#10B981"
                  : req.status === "in_progress"
                    ? "#F59E0B"
                    : "#3B82F6",
            },
          ]}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Text style={styles.requestType}>{req.request_type}</Text>
            <Text
              style={[
                styles.requestStatus,
                {
                  color:
                    req.status === "resolved"
                      ? "#10B981"
                      : req.status === "in_progress"
                        ? "#F59E0B"
                        : "#3B82F6",
                },
              ]}
            >
              {req.status}
            </Text>
          </View>
          <Text style={styles.requestDate}>
            {new Date(req.created_at).toLocaleDateString()}
          </Text>
        </View>
      ))}
    </View>
  );
}

// Admin View - Existing SOS Interface
function AdminView({ user, selectedOrg, insets }) {
  const [message, setMessage] = useState("");
  const [location, setLocation] = useState(null);
  const [loadingLocation, setLoadingLocation] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        Alert.alert(
          "Location Access",
          "We need your location to send accurate emergency alerts",
        );
        return;
      }
      refreshLocation();
    })();
  }, []);

  const refreshLocation = async () => {
    setLoadingLocation(true);
    try {
      let loc = await Location.getCurrentPositionAsync({});
      setLocation(loc);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingLocation(false);
    }
  };

  const sosMutation = useMutation({
    mutationFn: async (data) => {
      const res = await fetch("/api/disaster-relief/sos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to send SOS");
      return res.json();
    },
    onSuccess: () => {
      Alert.alert(
        "Help is On The Way",
        "Your emergency request has been received. Stay safe and stay where you are if possible.",
      );
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ["sosRequests"] });
    },
    onError: (error) => {
      Alert.alert("Unable to Send", error.message);
    },
  });

  const handleSOS = () => {
    if (!selectedOrg) {
      Alert.alert(
        "No Organization",
        "You need to join an organization before sending SOS requests",
      );
      return;
    }

    if (!location) {
      Alert.alert(
        "Location Required",
        "Please wait while we determine your location",
      );
      return;
    }

    Alert.alert(
      "Send Emergency Request?",
      "This will alert your response team immediately",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Send Request",
          style: "default",
          onPress: () => {
            sosMutation.mutate({
              org_id: selectedOrg.id,
              reporter_name: user?.email || "Mobile User",
              latitude: location.coords.latitude,
              longitude: location.coords.longitude,
              message: message || "Emergency assistance needed",
              priority: "high",
            });
          },
        },
      ],
    );
  };

  return (
    <KeyboardAvoidingAnimatedView
      style={{ flex: 1, backgroundColor: "#F7F9FC" }}
      behavior="padding"
    >
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ marginBottom: 24 }}>
          <Text style={styles.title}>Emergency Assistance</Text>
          <Text style={styles.subtitle}>
            {selectedOrg ? `${selectedOrg.name} • ` : ""}Help is available when
            you need it
          </Text>
        </View>

        <TouchableOpacity
          onPress={handleSOS}
          disabled={sosMutation.isLoading || !location}
          activeOpacity={0.85}
          style={[styles.sosButton, !location && styles.sosButtonDisabled]}
        >
          <View style={styles.sosButtonInner}>
            <AlertTriangle color="white" size={56} />
            <Text style={styles.sosText}>REQUEST HELP</Text>
            {loadingLocation && (
              <ActivityIndicator
                size="small"
                color="white"
                style={{ marginTop: 8 }}
              />
            )}
          </View>
        </TouchableOpacity>

        <View style={styles.card}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <Info size={20} color="#374151" />
            <Text style={styles.cardTitle}>Describe the situation</Text>
          </View>
          <TextInput
            style={styles.input}
            placeholder="What assistance do you need? (optional)"
            placeholderTextColor="#9CA3AF"
            multiline
            numberOfLines={4}
            value={message}
            onChangeText={setMessage}
          />
        </View>

        <View style={styles.card}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 16,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <MapPin size={20} color="#374151" />
              <Text style={styles.cardTitle}>Your Location</Text>
            </View>
            <TouchableOpacity
              onPress={refreshLocation}
              disabled={loadingLocation}
            >
              {loadingLocation ? (
                <ActivityIndicator size="small" color="#3B82F6" />
              ) : (
                <Text
                  style={{
                    color: "#3B82F6",
                    fontWeight: "700",
                    fontSize: 12,
                  }}
                >
                  UPDATE
                </Text>
              )}
            </TouchableOpacity>
          </View>
          {location ? (
            <View>
              <Text style={styles.locationText}>
                Latitude: {location.coords.latitude.toFixed(6)}
              </Text>
              <Text style={styles.locationText}>
                Longitude: {location.coords.longitude.toFixed(6)}
              </Text>
              <Text style={styles.locationStatus}>
                Accuracy: ±{location.coords.accuracy.toFixed(1)}m
              </Text>
            </View>
          ) : (
            <Text style={styles.locationEmpty}>
              Determining your position...
            </Text>
          )}
        </View>

        <View
          style={{
            marginTop: 24,
            padding: 16,
            backgroundColor: "#EFF6FF",
            borderRadius: 16,
            borderWidth: 1,
            borderColor: "#BFDBFE",
            flexDirection: "row",
            gap: 12,
          }}
        >
          <Info size={20} color="#1E40AF" />
          <Text
            style={{
              flex: 1,
              color: "#1E40AF",
              fontSize: 13,
              lineHeight: 18,
            }}
          >
            Your location will be shared with the response team when you send a
            request
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingAnimatedView>
  );
}

const styles = StyleSheet.create({
  title: {
    fontSize: 32,
    fontWeight: "800",
    color: "#111827",
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 15,
    color: "#6B7280",
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 16,
  },
  orgCard: {
    backgroundColor: "white",
    padding: 12,
    borderRadius: 12,
    marginTop: 16,
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  orgLabel: {
    color: "#9CA3AF",
    fontSize: 12,
  },
  orgName: {
    color: "#111827",
    fontSize: 16,
    fontWeight: "600",
    marginTop: 2,
  },
  orgAddress: {
    color: "#6B7280",
    fontSize: 12,
    marginTop: 2,
  },
  helpButton: {
    backgroundColor: "white",
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  helpButtonIcon: {
    width: 48,
    height: 48,
    backgroundColor: "#F9FAFB",
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  helpButtonTitle: {
    color: "#111827",
    fontSize: 16,
    fontWeight: "600",
  },
  helpButtonDesc: {
    color: "#9CA3AF",
    fontSize: 14,
    marginTop: 2,
  },
  requestCard: {
    backgroundColor: "white",
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  requestType: {
    color: "#111827",
    fontSize: 14,
    fontWeight: "600",
    textTransform: "capitalize",
  },
  requestStatus: {
    fontSize: 12,
    textTransform: "capitalize",
    fontWeight: "600",
  },
  requestDate: {
    color: "#9CA3AF",
    fontSize: 12,
    marginTop: 4,
  },
  emptyState: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 12,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  emptyText: {
    color: "#6B7280",
    fontSize: 14,
  },
  authPrompt: {
    backgroundColor: "white",
    borderRadius: 24,
    padding: 32,
    alignItems: "center",
    marginVertical: 40,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  authText: {
    fontSize: 16,
    color: "#374151",
    marginTop: 16,
    marginBottom: 24,
    textAlign: "center",
  },
  signInButton: {
    backgroundColor: "#3B82F6",
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 16,
  },
  signInButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "700",
  },
  sosButton: {
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: "#DBEAFE",
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 32,
    shadowColor: "#3B82F6",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 8,
  },
  sosButtonDisabled: {
    opacity: 0.6,
  },
  sosButtonInner: {
    width: 180,
    height: 180,
    borderRadius: 90,
    backgroundColor: "#3B82F6",
    justifyContent: "center",
    alignItems: "center",
  },
  sosText: {
    color: "white",
    fontSize: 18,
    fontWeight: "900",
    marginTop: 10,
    letterSpacing: 0.5,
  },
  card: {
    backgroundColor: "white",
    borderRadius: 24,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#F3F4F6",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#374151",
    marginLeft: 10,
  },
  input: {
    backgroundColor: "#F9FAFB",
    borderRadius: 16,
    padding: 16,
    fontSize: 14,
    color: "#1F2937",
    minHeight: 100,
    textAlignVertical: "top",
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  locationText: {
    fontSize: 15,
    color: "#374151",
    fontWeight: "500",
    marginBottom: 4,
  },
  locationStatus: {
    fontSize: 12,
    color: "#10B981",
    fontWeight: "700",
    marginTop: 4,
  },
  locationEmpty: {
    color: "#9CA3AF",
    fontStyle: "italic",
  },
});
