import React from "react";
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  Dimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Package,
  Droplets,
  Utensils,
  HeartPulse,
  Tent,
} from "lucide-react-native";
import { useQuery } from "@tanstack/react-query";
import { StatusBar } from "expo-status-bar";

const fetchInventory = async () => {
  const res = await fetch("/api/disaster-relief/inventory");
  if (!res.ok) throw new Error("Failed to fetch inventory");
  return res.json();
};

export default function InventoryScreen() {
  const insets = useSafeAreaInsets();
  const { data: inventory = [], isLoading } = useQuery({
    queryKey: ["inventory"],
    queryFn: fetchInventory,
  });

  const getCategoryIcon = (category) => {
    switch (category) {
      case "water":
        return <Droplets size={24} color="#3B82F6" />;
      case "food":
        return <Utensils size={24} color="#F59E0B" />;
      case "medical":
        return <HeartPulse size={24} color="#EF4444" />;
      case "shelter":
        return <Tent size={24} color="#10B981" />;
      default:
        return <Package size={24} color="#6B7280" />;
    }
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#1A5DFF" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View className="mb-8">
          <Text style={styles.title}>Supply Inventory</Text>
          <Text style={styles.subtitle}>
            Real-time stock levels at central relief hub.
          </Text>
        </View>

        <View style={styles.grid}>
          {inventory.map((item) => {
            const percentage = (item.quantity / item.capacity) * 100;
            const isLow = percentage < 20;

            return (
              <View key={item.id} style={styles.itemCard}>
                <View style={styles.itemHeader}>
                  <View
                    style={[
                      styles.iconContainer,
                      { backgroundColor: isLow ? "#FEE2E2" : "#F3F4F6" },
                    ]}
                  >
                    {getCategoryIcon(item.category)}
                  </View>
                  {isLow && (
                    <View style={styles.lowStockBadge}>
                      <Text style={styles.lowStockText}>LOW</Text>
                    </View>
                  )}
                </View>

                <Text style={styles.itemName} numberOfLines={1}>
                  {item.item_name}
                </Text>
                <Text style={styles.itemQuantity}>
                  {item.quantity}{" "}
                  <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                    {item.unit}
                  </Text>
                </Text>

                <View style={styles.progressContainer}>
                  <View style={styles.progressBar}>
                    <View
                      style={[
                        styles.progressFill,
                        {
                          width: `${Math.min(percentage, 100)}%`,
                          backgroundColor: isLow ? "#EF4444" : "#1A5DFF",
                        },
                      ]}
                    />
                  </View>
                  <Text style={styles.progressText}>
                    {Math.round(percentage)}% full
                  </Text>
                </View>
              </View>
            );
          })}
        </View>

        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Supply Summary</Text>
          <View className="flex-row justify-between items-center mt-4">
            <View className="items-center">
              <Text style={styles.summaryValue}>{inventory.length}</Text>
              <Text style={styles.summaryLabel}>Total Items</Text>
            </View>
            <View style={styles.divider} />
            <View className="items-center">
              <Text style={[styles.summaryValue, { color: "#EF4444" }]}>
                {inventory.filter((i) => i.quantity / i.capacity < 0.2).length}
              </Text>
              <Text style={styles.summaryLabel}>Low Stock</Text>
            </View>
            <View style={styles.divider} />
            <View className="items-center">
              <Text style={[styles.summaryValue, { color: "#10B981" }]}>
                98%
              </Text>
              <Text style={styles.summaryLabel}>Availability</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  title: {
    fontSize: 32,
    fontWeight: "800",
    color: "#111827",
    fontFamily: "Bricolage Grotesque",
  },
  subtitle: {
    fontSize: 16,
    color: "#6B7280",
    marginTop: 4,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  itemCard: {
    width: (Dimensions.get("window").width - 56) / 2,
    backgroundColor: "white",
    borderRadius: 24,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#F3F4F6",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
  },
  itemHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 16,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
  },
  lowStockBadge: {
    backgroundColor: "#EF4444",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  lowStockText: {
    color: "white",
    fontSize: 8,
    fontWeight: "900",
  },
  itemName: {
    fontSize: 14,
    fontWeight: "700",
    color: "#374151",
    marginBottom: 4,
  },
  itemQuantity: {
    fontSize: 20,
    fontWeight: "800",
    color: "#111827",
    fontFamily: "Geist",
  },
  progressContainer: {
    marginTop: 12,
  },
  progressBar: {
    height: 6,
    backgroundColor: "#F3F4F6",
    borderRadius: 3,
    overflow: "hidden",
    marginBottom: 4,
  },
  progressFill: {
    height: "100%",
    borderRadius: 3,
  },
  progressText: {
    fontSize: 10,
    color: "#9CA3AF",
    fontWeight: "600",
  },
  summaryCard: {
    backgroundColor: "white",
    borderRadius: 24,
    padding: 20,
    marginTop: 10,
    borderWidth: 1,
    borderColor: "#F3F4F6",
  },
  summaryTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: "#111827",
    fontFamily: "Bricolage Grotesque",
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: "800",
    color: "#1A5DFF",
    fontFamily: "Geist",
  },
  summaryLabel: {
    fontSize: 10,
    color: "#6B7280",
    fontWeight: "700",
    marginTop: 2,
  },
  divider: {
    width: 1,
    height: 30,
    backgroundColor: "#F3F4F6",
  },
});
