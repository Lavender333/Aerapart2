import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import MapView, { Marker, Circle, PROVIDER_GOOGLE } from "react-native-maps";
import * as Location from "expo-location";
import { MapPin, Radio, Users } from "lucide-react-native";
import { useQuery, useMutation } from "@tanstack/react-query";
import LocationConsentModal from "@/components/LocationConsentModal";

const fetchLiveLocations = async (orgId) => {
  const res = await fetch(`/api/disaster-relief/live-location?orgId=${orgId}`);
  if (!res.ok) throw new Error("Failed to fetch live locations");
  return res.json();
};

const fetchSOSRequests = async () => {
  const res = await fetch("/api/disaster-relief/sos");
  if (!res.ok) throw new Error("Failed to fetch SOS requests");
  return res.json();
};

export default function LiveMapScreen() {
  const insets = useSafeAreaInsets();
  const [myLocation, setMyLocation] = useState(null);
  const [sharingLocation, setSharingLocation] = useState(false);
  const [selectedOrgId, setSelectedOrgId] = useState(1); // Default org
  const [showConsentModal, setShowConsentModal] = useState(false);

  const { data: responders = [], isLoading: loadingResponders } = useQuery({
    queryKey: ["liveLocations", selectedOrgId],
    queryFn: () => fetchLiveLocations(selectedOrgId),
    refetchInterval: 5000,
    enabled: !!selectedOrgId && sharingLocation,
  });

  const { data: sosRequests = [] } = useQuery({
    queryKey: ["sosRequests"],
    queryFn: fetchSOSRequests,
    refetchInterval: 5000,
  });

  const updateLocationMutation = useMutation({
    mutationFn: async (coords) => {
      const res = await fetch("/api/disaster-relief/live-location", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orgId: selectedOrgId,
          latitude: coords.latitude,
          longitude: coords.longitude,
          status: "active",
        }),
      });
      if (!res.ok) throw new Error("Failed to update location");
      return res.json();
    },
  });

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        Alert.alert("Permission denied", "Location permission is required");
        return;
      }

      const location = await Location.getCurrentPositionAsync({});
      setMyLocation({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      });
    })();
  }, []);

  useEffect(() => {
    let locationSubscription;

    if (sharingLocation) {
      (async () => {
        locationSubscription = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.High,
            timeInterval: 5000,
            distanceInterval: 10,
          },
          (location) => {
            const coords = {
              latitude: location.coords.latitude,
              longitude: location.coords.longitude,
            };
            setMyLocation((prev) => ({ ...prev, ...coords }));
            updateLocationMutation.mutate(coords);
          },
        );
      })();
    }

    return () => {
      if (locationSubscription) {
        locationSubscription.remove();
      }
    };
  }, [sharingLocation, selectedOrgId]);

  const toggleLocationSharing = () => {
    if (!sharingLocation) {
      // Show consent modal before enabling location sharing
      setShowConsentModal(true);
    } else {
      // Directly stop sharing
      setSharingLocation(false);
      Alert.alert("Location Sharing Stopped", "Your location is now private");
    }
  };

  const handleConsentAgree = () => {
    setShowConsentModal(false);
    setSharingLocation(true);
    Alert.alert(
      "Location Sharing Active",
      "Your live location is now visible to your response team",
    );
  };

  const handleConsentDecline = () => {
    setShowConsentModal(false);
  };

  if (!myLocation) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "white",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <ActivityIndicator size="large" color="#4F46E5" />
        <Text style={{ marginTop: 16, color: "#6B7280" }}>
          Getting your location...
        </Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "white" }}>
      <StatusBar style="dark" />

      <LocationConsentModal
        visible={showConsentModal}
        onAgree={handleConsentAgree}
        onDecline={handleConsentDecline}
      />

      <MapView
        provider={PROVIDER_GOOGLE}
        style={{ flex: 1 }}
        initialRegion={myLocation}
        showsUserLocation={true}
        showsMyLocationButton={false}
      >
        {sharingLocation && myLocation && (
          <>
            <Circle
              center={{
                latitude: myLocation.latitude,
                longitude: myLocation.longitude,
              }}
              radius={100}
              fillColor="rgba(79, 70, 229, 0.2)"
              strokeColor="rgba(79, 70, 229, 0.5)"
              strokeWidth={2}
            />
            <Marker
              coordinate={{
                latitude: myLocation.latitude,
                longitude: myLocation.longitude,
              }}
              title="You"
              description="Your current location"
              pinColor="#4F46E5"
            />
          </>
        )}

        {responders.map((responder) => (
          <Marker
            key={responder.id}
            coordinate={{
              latitude: responder.latitude,
              longitude: responder.longitude,
            }}
            title={responder.name}
            description={`Status: ${responder.status}`}
            pinColor="#10B981"
          />
        ))}

        {sosRequests
          .filter((req) => req.status === "pending")
          .map((req) => (
            <Marker
              key={`sos-${req.id}`}
              coordinate={{
                latitude: req.latitude,
                longitude: req.longitude,
              }}
              title={`SOS: ${req.reporter_name}`}
              description={req.message}
              pinColor={req.priority === "high" ? "#EF4444" : "#F59E0B"}
            />
          ))}
      </MapView>

      <View
        style={{
          position: "absolute",
          top: insets.top + 12,
          left: 16,
          right: 16,
        }}
      >
        <View
          style={{
            backgroundColor: "rgba(255, 255, 255, 0.95)",
            borderRadius: 16,
            padding: 16,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.1,
            shadowRadius: 12,
            borderWidth: 1,
            borderColor: "#F3F4F6",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <View
              style={{ flexDirection: "row", alignItems: "center", gap: 8 }}
            >
              <View
                style={{
                  width: 12,
                  height: 12,
                  borderRadius: 6,
                  backgroundColor: sharingLocation ? "#10B981" : "#D1D5DB",
                }}
              />
              <Text style={{ fontWeight: "700", color: "#111827" }}>
                {sharingLocation ? "Location Sharing ON" : "Location Private"}
              </Text>
            </View>
            <View
              style={{ flexDirection: "row", alignItems: "center", gap: 8 }}
            >
              <Users size={16} color="#6B7280" />
              <Text style={{ fontSize: 14, color: "#6B7280" }}>
                {responders.length} Active
              </Text>
            </View>
          </View>
        </View>
      </View>

      <View
        style={{
          position: "absolute",
          bottom: insets.bottom + 20,
          left: 16,
          right: 16,
        }}
      >
        <View
          style={{
            backgroundColor: "white",
            borderRadius: 24,
            padding: 24,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 10 },
            shadowOpacity: 0.15,
            shadowRadius: 30,
            borderWidth: 1,
            borderColor: "#F3F4F6",
          }}
        >
          <TouchableOpacity
            onPress={toggleLocationSharing}
            activeOpacity={0.8}
            style={{
              paddingVertical: 16,
              paddingHorizontal: 24,
              borderRadius: 16,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 12,
              backgroundColor: sharingLocation ? "#EF4444" : "#4F46E5",
            }}
          >
            <Radio size={24} color="white" />
            <Text style={{ color: "white", fontWeight: "700", fontSize: 18 }}>
              {sharingLocation
                ? "Stop Sharing Location"
                : "Share Live Location"}
            </Text>
          </TouchableOpacity>

          {sharingLocation && (
            <View
              style={{
                marginTop: 16,
                padding: 16,
                backgroundColor: "#EFF6FF",
                borderRadius: 16,
              }}
            >
              <Text
                style={{
                  color: "#1E40AF",
                  fontSize: 14,
                  fontWeight: "500",
                  textAlign: "center",
                }}
              >
                Your team can see your location in real-time
              </Text>
            </View>
          )}

          <View style={{ flexDirection: "row", gap: 16, marginTop: 16 }}>
            <View style={{ flex: 1, alignItems: "center" }}>
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  backgroundColor: "#FEE2E2",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 8,
                }}
              >
                <View
                  style={{
                    width: 16,
                    height: 16,
                    borderRadius: 8,
                    backgroundColor: "#EF4444",
                  }}
                />
              </View>
              <Text
                style={{ fontSize: 12, color: "#6B7280", textAlign: "center" }}
              >
                Active SOS
              </Text>
              <Text
                style={{ fontSize: 18, fontWeight: "700", color: "#111827" }}
              >
                {sosRequests.filter((r) => r.status === "pending").length}
              </Text>
            </View>

            <View style={{ flex: 1, alignItems: "center" }}>
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  backgroundColor: "#D1FAE5",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 8,
                }}
              >
                <View
                  style={{
                    width: 16,
                    height: 16,
                    borderRadius: 8,
                    backgroundColor: "#10B981",
                  }}
                />
              </View>
              <Text
                style={{ fontSize: 12, color: "#6B7280", textAlign: "center" }}
              >
                Responders
              </Text>
              <Text
                style={{ fontSize: 18, fontWeight: "700", color: "#111827" }}
              >
                {responders.length}
              </Text>
            </View>

            <View style={{ flex: 1, alignItems: "center" }}>
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  backgroundColor: "#DBEAFE",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 8,
                }}
              >
                <MapPin size={20} color="#3B82F6" />
              </View>
              <Text
                style={{ fontSize: 12, color: "#6B7280", textAlign: "center" }}
              >
                Coverage
              </Text>
              <Text
                style={{ fontSize: 18, fontWeight: "700", color: "#111827" }}
              >
                100m
              </Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}
