import {
  View,
  Text,
  Pressable,
  ScrollView,
  Linking,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useRouter } from "expo-router";
import {
  ArrowLeft,
  FileText,
  Shield,
  Mail,
  ExternalLink,
  Trash2,
} from "lucide-react-native";
import { useState } from "react";
import { useAuth } from "@/utils/auth";

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { signOut } = useAuth();
  const [isDeleting, setIsDeleting] = useState(false);

  const handlePrivacyPolicy = () => {
    router.push("/privacy-policy");
  };

  const handleContactSupport = () => {
    Linking.openURL("mailto:aerapp369@gmail.com?subject=AERA Support Request");
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      "Delete Account",
      "Are you sure you want to delete your account? This will permanently remove all your data including:\n\n• Your profile and account information\n• Household and member data\n• Help requests and safety status\n• All location history\n\nThis action cannot be undone.",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete Account",
          style: "destructive",
          onPress: confirmDeleteAccount,
        },
      ],
    );
  };

  const confirmDeleteAccount = async () => {
    try {
      setIsDeleting(true);

      const response = await fetch(
        `${process.env.EXPO_PUBLIC_BASE_URL}/api/auth/delete-account`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        },
      );

      if (!response.ok) {
        throw new Error("Failed to delete account");
      }

      // Sign out and redirect to home
      await signOut();
      router.replace("/");

      Alert.alert(
        "Account Deleted",
        "Your account and all associated data have been permanently deleted.",
      );
    } catch (error) {
      console.error("Error deleting account:", error);
      Alert.alert(
        "Error",
        "Failed to delete account. Please try again or contact support at aerapp369@gmail.com",
      );
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <StatusBar style="dark" />

      <View
        style={{
          paddingTop: insets.top + 16,
          paddingHorizontal: 20,
          paddingBottom: 16,
          backgroundColor: "#FFFFFF",
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <ArrowLeft size={24} color="#000000" onPress={() => router.back()} />
          <Text style={{ fontSize: 20, fontWeight: "600", color: "#000000" }}>
            Settings
          </Text>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ marginTop: 20 }}>
          <Text
            style={{
              fontSize: 13,
              fontWeight: "600",
              color: "#6B7280",
              marginBottom: 8,
              paddingHorizontal: 20,
            }}
          >
            LEGAL & PRIVACY
          </Text>

          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderTopWidth: 1,
              borderBottomWidth: 1,
              borderColor: "#E5E7EB",
            }}
          >
            <Pressable
              onPress={handlePrivacyPolicy}
              style={({ pressed }) => ({
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                paddingVertical: 16,
                paddingHorizontal: 20,
                backgroundColor: pressed ? "#F9FAFB" : "#FFFFFF",
              })}
            >
              <View
                style={{ flexDirection: "row", alignItems: "center", gap: 12 }}
              >
                <View
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 18,
                    backgroundColor: "#EFF6FF",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Shield size={18} color="#2563EB" />
                </View>
                <Text style={{ fontSize: 16, color: "#000000" }}>
                  Privacy Policy
                </Text>
              </View>
              <ExternalLink size={20} color="#9CA3AF" />
            </Pressable>
          </View>
        </View>

        <View style={{ marginTop: 32 }}>
          <Text
            style={{
              fontSize: 13,
              fontWeight: "600",
              color: "#6B7280",
              marginBottom: 8,
              paddingHorizontal: 20,
            }}
          >
            SUPPORT
          </Text>

          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderTopWidth: 1,
              borderBottomWidth: 1,
              borderColor: "#E5E7EB",
            }}
          >
            <Pressable
              onPress={handleContactSupport}
              style={({ pressed }) => ({
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                paddingVertical: 16,
                paddingHorizontal: 20,
                backgroundColor: pressed ? "#F9FAFB" : "#FFFFFF",
              })}
            >
              <View
                style={{ flexDirection: "row", alignItems: "center", gap: 12 }}
              >
                <View
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 18,
                    backgroundColor: "#FEF3C7",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Mail size={18} color="#D97706" />
                </View>
                <Text style={{ fontSize: 16, color: "#000000" }}>
                  Contact Support
                </Text>
              </View>
              <ExternalLink size={20} color="#9CA3AF" />
            </Pressable>
          </View>
        </View>

        <View style={{ marginTop: 32 }}>
          <Text
            style={{
              fontSize: 13,
              fontWeight: "600",
              color: "#6B7280",
              marginBottom: 8,
              paddingHorizontal: 20,
            }}
          >
            ACCOUNT
          </Text>

          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderTopWidth: 1,
              borderBottomWidth: 1,
              borderColor: "#E5E7EB",
            }}
          >
            <Pressable
              onPress={handleDeleteAccount}
              disabled={isDeleting}
              style={({ pressed }) => ({
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                paddingVertical: 16,
                paddingHorizontal: 20,
                backgroundColor: pressed ? "#FEF2F2" : "#FFFFFF",
                opacity: isDeleting ? 0.5 : 1,
              })}
            >
              <View
                style={{ flexDirection: "row", alignItems: "center", gap: 12 }}
              >
                <View
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 18,
                    backgroundColor: "#FEE2E2",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Trash2 size={18} color="#DC2626" />
                </View>
                <Text
                  style={{ fontSize: 16, color: "#DC2626", fontWeight: "500" }}
                >
                  {isDeleting ? "Deleting..." : "Delete Account"}
                </Text>
              </View>
            </Pressable>
          </View>

          <View style={{ paddingHorizontal: 20, marginTop: 8 }}>
            <Text style={{ fontSize: 12, color: "#6B7280", lineHeight: 16 }}>
              Permanently delete your account and all associated data. This
              action cannot be undone.
            </Text>
          </View>
        </View>

        <View style={{ marginTop: 24, paddingHorizontal: 20 }}>
          <View
            style={{
              padding: 12,
              backgroundColor: "#EFF6FF",
              borderRadius: 8,
              borderWidth: 1,
              borderColor: "#DBEAFE",
            }}
          >
            <Text style={{ fontSize: 12, lineHeight: 16, color: "#1E40AF" }}>
              <Text style={{ fontWeight: "600" }}>Data Privacy:</Text> Your
              real-time location is only shared with your organization's
              response team when you activate live location sharing. You can
              disable this at any time.
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
