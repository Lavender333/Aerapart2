import { Modal, View, Text, Pressable } from "react-native";
import { MapPin, Shield, Users, X } from "lucide-react-native";

export default function LocationConsentModal({ visible, onAgree, onDecline }) {
  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="fade"
      onRequestClose={onDecline}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          justifyContent: "center",
          alignItems: "center",
          padding: 20,
        }}
      >
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 16,
            padding: 24,
            width: "100%",
            maxWidth: 400,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 20,
            }}
          >
            <Text style={{ fontSize: 20, fontWeight: "700", color: "#000000" }}>
              Enable Live Location
            </Text>
            <Pressable onPress={onDecline} hitSlop={8}>
              <X size={24} color="#6B7280" />
            </Pressable>
          </View>

          <View style={{ marginBottom: 24 }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "flex-start",
                gap: 12,
                marginBottom: 16,
              }}
            >
              <View
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: "#EFF6FF",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <MapPin size={20} color="#2563EB" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 15,
                    fontWeight: "600",
                    color: "#000000",
                    marginBottom: 4,
                  }}
                >
                  What data is shared
                </Text>
                <Text
                  style={{ fontSize: 14, lineHeight: 20, color: "#6B7280" }}
                >
                  Your real-time GPS location will be continuously shared while
                  live location is active, even when the app is in the
                  background.
                </Text>
              </View>
            </View>

            <View
              style={{
                flexDirection: "row",
                alignItems: "flex-start",
                gap: 12,
                marginBottom: 16,
              }}
            >
              <View
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: "#FEF3C7",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Users size={20} color="#D97706" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 15,
                    fontWeight: "600",
                    color: "#000000",
                    marginBottom: 4,
                  }}
                >
                  Who can see it
                </Text>
                <Text
                  style={{ fontSize: 14, lineHeight: 20, color: "#6B7280" }}
                >
                  Your location will be shared with members of your
                  organization's emergency response team to coordinate
                  assistance.
                </Text>
              </View>
            </View>

            <View
              style={{
                flexDirection: "row",
                alignItems: "flex-start",
                gap: 12,
              }}
            >
              <View
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: "#DCFCE7",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Shield size={20} color="#16A34A" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 15,
                    fontWeight: "600",
                    color: "#000000",
                    marginBottom: 4,
                  }}
                >
                  How to stop it
                </Text>
                <Text
                  style={{ fontSize: 14, lineHeight: 20, color: "#6B7280" }}
                >
                  You can turn off live location sharing at any time through the
                  Safety tab or device settings.
                </Text>
              </View>
            </View>
          </View>

          <View
            style={{
              padding: 12,
              backgroundColor: "#FEF3C7",
              borderRadius: 8,
              marginBottom: 20,
            }}
          >
            <Text style={{ fontSize: 13, lineHeight: 18, color: "#92400E" }}>
              <Text style={{ fontWeight: "600" }}>Privacy Notice:</Text> Your
              location data is used exclusively for emergency response
              coordination and is never sold to third parties.
            </Text>
          </View>

          <View style={{ gap: 12 }}>
            <Pressable
              onPress={onAgree}
              style={{
                backgroundColor: "#2563EB",
                paddingVertical: 14,
                borderRadius: 10,
                alignItems: "center",
              }}
            >
              <Text
                style={{ fontSize: 16, fontWeight: "600", color: "#FFFFFF" }}
              >
                Agree & Enable
              </Text>
            </Pressable>

            <Pressable
              onPress={onDecline}
              style={{ paddingVertical: 14, alignItems: "center" }}
            >
              <Text
                style={{ fontSize: 16, fontWeight: "600", color: "#6B7280" }}
              >
                Not Now
              </Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}
