import { useState } from "react";

export function useUserRoleEditor(onSuccess) {
  const [editingUser, setEditingUser] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const handleEditUser = (user) => {
    setEditingUser({
      ...user,
      new_system_role: user.system_role,
    });
    setShowEditModal(true);
  };

  const handleUpdateRole = async () => {
    try {
      const response = await fetch("/api/users/role", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: editingUser.id,
          system_role: editingUser.new_system_role,
        }),
      });

      if (!response.ok) throw new Error("Failed to update role");

      if (onSuccess) {
        await onSuccess();
      }
      setShowEditModal(false);
      setEditingUser(null);
    } catch (error) {
      console.error("Error updating role:", error);
      alert("Failed to update user role");
    }
  };

  const closeModal = () => {
    setShowEditModal(false);
    setEditingUser(null);
  };

  const updateEditingUser = (updates) => {
    setEditingUser((prev) => ({ ...prev, ...updates }));
  };

  return {
    editingUser,
    showEditModal,
    handleEditUser,
    handleUpdateRole,
    closeModal,
    updateEditingUser,
  };
}
