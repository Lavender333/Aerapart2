import { useState, useEffect } from "react";

export function useAdminData(isAdmin) {
  const [users, setUsers] = useState([]);
  const [organizations, setOrganizations] = useState([]);
  const [members, setMembers] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isAdmin) {
      fetchData();
    }
  }, [isAdmin]);

  const fetchData = async () => {
    try {
      const [usersRes, statsRes, orgsRes, membersRes] = await Promise.all([
        fetch("/api/admin/users"),
        fetch("/api/admin/stats"),
        fetch("/api/admin/organizations"),
        fetch("/api/admin/members"),
      ]);

      if (!usersRes.ok || !statsRes.ok) {
        throw new Error("Failed to fetch admin data");
      }

      const usersData = await usersRes.json();
      const statsData = await statsRes.json();
      const orgsData = orgsRes.ok
        ? await orgsRes.json()
        : { organizations: [] };
      const membersData = membersRes.ok
        ? await membersRes.json()
        : { members: [] };

      setUsers(usersData.users || []);
      setStats(statsData);
      setOrganizations(orgsData.organizations || []);
      setMembers(membersData.members || []);
    } catch (error) {
      console.error("Error fetching admin data:", error);
    } finally {
      setLoading(false);
    }
  };

  return {
    users,
    organizations,
    members,
    stats,
    loading,
    refetchData: fetchData,
  };
}
