import { useState, useEffect } from "react";

export function useAdminAccess(user, userLoading) {
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userLoading && !user) {
      window.location.href = "/admin/login";
      return;
    }

    if (user) {
      checkAdminAccess();
    }
  }, [user, userLoading]);

  const checkAdminAccess = async () => {
    try {
      const response = await fetch("/api/users/role");
      const data = await response.json();

      if (data.user?.system_role !== "system_admin") {
        window.location.href = "/admin/login";
        return;
      }

      setIsAdmin(true);
    } catch (error) {
      console.error("Error checking admin access:", error);
      window.location.href = "/admin/login";
    } finally {
      setLoading(false);
    }
  };

  return { isAdmin, loading };
}
