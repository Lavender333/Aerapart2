export function StatCard({ title, value, icon: Icon, color }) {
  const colors = {
    blue: "bg-blue-900/30 border-blue-700 text-blue-300",
    purple: "bg-purple-900/30 border-purple-700 text-purple-300",
    red: "bg-red-900/30 border-red-700 text-red-300",
    green: "bg-green-900/30 border-green-700 text-green-300",
  };

  return (
    <div className={`backdrop-blur-xl border rounded-2xl p-6 ${colors[color]}`}>
      <div className="flex items-center justify-between mb-4">
        <Icon size={24} />
      </div>
      <p className="text-3xl font-bold mb-1">{value}</p>
      <p className="text-sm opacity-80">{title}</p>
    </div>
  );
}
