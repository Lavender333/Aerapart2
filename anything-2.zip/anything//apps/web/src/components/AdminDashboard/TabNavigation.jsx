import { Users, Building2, UserCircle } from "lucide-react";

export function TabNavigation({ activeTab, onTabChange }) {
  return (
    <div className="flex gap-2 mb-6">
      <button
        onClick={() => onTabChange("users")}
        className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
          activeTab === "users"
            ? "bg-red-600 text-white"
            : "bg-slate-800/50 text-slate-400 hover:bg-slate-700/50"
        }`}
      >
        <Users size={18} className="inline mr-2" />
        Users
      </button>
      <button
        onClick={() => onTabChange("organizations")}
        className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
          activeTab === "organizations"
            ? "bg-red-600 text-white"
            : "bg-slate-800/50 text-slate-400 hover:bg-slate-700/50"
        }`}
      >
        <Building2 size={18} className="inline mr-2" />
        Organizations
      </button>
      <button
        onClick={() => onTabChange("members")}
        className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
          activeTab === "members"
            ? "bg-red-600 text-white"
            : "bg-slate-800/50 text-slate-400 hover:bg-slate-700/50"
        }`}
      >
        <UserCircle size={18} className="inline mr-2" />
        Members
      </button>
    </div>
  );
}
