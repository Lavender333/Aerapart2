import { Users, Building2, AlertTriangle, Shield } from "lucide-react";
import { StatCard } from "./StatCard";

export function StatsGrid({ stats }) {
  if (!stats) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <StatCard
        title="Total Users"
        value={stats.users.total_users}
        icon={Users}
        color="blue"
      />
      <StatCard
        title="Organizations"
        value={stats.organizations.total_organizations}
        icon={Building2}
        color="purple"
      />
      <StatCard
        title="Active SOS"
        value={stats.sos.pending_sos}
        icon={AlertTriangle}
        color="red"
      />
      <StatCard
        title="Safe Members"
        value={stats.members.safe_members}
        icon={Shield}
        color="green"
      />
    </div>
  );
}
