export function OrganizationsTable({ organizations }) {
  return (
    <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
      <h2 className="text-2xl font-bold text-white mb-6">Organizations</h2>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-700">
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Name
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Creator Email
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Created At
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Members
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Join Code
              </th>
            </tr>
          </thead>
          <tbody>
            {organizations.map((org) => (
              <tr
                key={org.id}
                className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors"
              >
                <td className="py-4 px-4">
                  <div>
                    <p className="text-white font-medium">{org.name}</p>
                    {org.address && (
                      <p className="text-slate-400 text-sm">{org.address}</p>
                    )}
                  </div>
                </td>
                <td className="py-4 px-4">
                  <p className="text-slate-300">{org.creator_email || "N/A"}</p>
                  {org.creator_name && (
                    <p className="text-slate-500 text-sm">{org.creator_name}</p>
                  )}
                </td>
                <td className="py-4 px-4 text-slate-300">
                  {new Date(org.created_at).toLocaleString()}
                </td>
                <td className="py-4 px-4">
                  <span className="bg-blue-900/30 text-blue-300 px-3 py-1 rounded-full text-sm font-semibold">
                    {org.member_count} members
                  </span>
                </td>
                <td className="py-4 px-4">
                  <span className="font-mono text-slate-300 bg-slate-900/50 px-3 py-1 rounded">
                    {org.join_code}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {organizations.length === 0 && (
          <p className="text-center py-8 text-slate-500">
            No organizations found
          </p>
        )}
      </div>
    </div>
  );
}
