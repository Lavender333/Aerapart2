export function EditUserModal({
  editingUser,
  showEditModal,
  onClose,
  onUpdate,
  onUserChange,
}) {
  if (!showEditModal || !editingUser) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl w-full max-w-md p-6">
        <h2 className="text-2xl font-bold text-white mb-6">Edit User Role</h2>

        <div className="space-y-4">
          <div>
            <p className="text-sm text-slate-400 mb-1">User</p>
            <p className="text-white font-medium">{editingUser.email}</p>
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">
              System Role
            </label>
            <select
              value={editingUser.new_system_role}
              onChange={(e) =>
                onUserChange({ new_system_role: e.target.value })
              }
              className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:border-red-500 focus:ring-2 focus:ring-red-500/20 outline-none"
            >
              <option value="user">User</option>
              <option value="system_admin">System Admin</option>
            </select>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={onUpdate}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-3 rounded-lg font-semibold transition-colors"
            >
              Update Role
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
