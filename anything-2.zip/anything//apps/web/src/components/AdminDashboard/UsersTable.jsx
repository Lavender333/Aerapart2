import { Building2, Edit } from "lucide-react";

export function UsersTable({ users, onEditUser }) {
  return (
    <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-700">
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                User
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                System Role
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Organizations
              </th>
              <th className="text-right py-3 px-4 text-slate-400 font-semibold text-sm">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr
                key={u.id}
                className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors"
              >
                <td className="py-4 px-4">
                  <div>
                    <p className="text-white font-medium">
                      {u.name || "No name"}
                    </p>
                    <p className="text-slate-400 text-sm">{u.email}</p>
                  </div>
                </td>
                <td className="py-4 px-4">
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                      u.system_role === "system_admin"
                        ? "bg-red-900/30 text-red-300 border border-red-700"
                        : "bg-slate-700 text-slate-300 border border-slate-600"
                    }`}
                  >
                    {u.system_role === "system_admin" ? "SYSTEM ADMIN" : "USER"}
                  </span>
                </td>
                <td className="py-4 px-4">
                  {u.organizations.length > 0 ? (
                    <div className="space-y-1">
                      {u.organizations.slice(0, 2).map((org, idx) => (
                        <div
                          key={idx}
                          className="text-sm text-slate-300 flex items-center gap-2"
                        >
                          <Building2 size={14} className="text-slate-500" />
                          <span className="font-medium">{org.org_name}</span>
                          <span className="text-slate-500">({org.role})</span>
                        </div>
                      ))}
                      {u.organizations.length > 2 && (
                        <p className="text-xs text-slate-500">
                          +{u.organizations.length - 2} more
                        </p>
                      )}
                    </div>
                  ) : (
                    <span className="text-slate-500 text-sm">
                      No organizations
                    </span>
                  )}
                </td>
                <td className="py-4 px-4 text-right">
                  <button
                    onClick={() => onEditUser(u)}
                    className="inline-flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm font-medium transition-colors"
                  >
                    <Edit size={14} />
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {users.length === 0 && (
          <p className="text-center py-8 text-slate-500">No users found</p>
        )}
      </div>
    </div>
  );
}
