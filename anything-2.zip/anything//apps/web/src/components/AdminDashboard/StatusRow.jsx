export function StatusRow({ label, value, color }) {
  const colors = {
    red: "text-red-400",
    yellow: "text-yellow-400",
    blue: "text-blue-400",
    green: "text-green-400",
    gray: "text-slate-400",
  };

  return (
    <div className="flex justify-between items-center">
      <span className="text-slate-400 text-sm">{label}</span>
      <span className={`font-bold ${colors[color]}`}>{value}</span>
    </div>
  );
}
