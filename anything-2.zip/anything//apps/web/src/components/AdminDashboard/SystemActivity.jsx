import { Activity, HelpCircle, BarChart3 } from "lucide-react";
import { StatusRow } from "./StatusRow";

export function SystemActivity({ stats }) {
  if (!stats) return null;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Activity size={20} className="text-red-400" />
          <h3 className="text-lg font-bold text-white">Emergency Status</h3>
        </div>
        <div className="space-y-3">
          <StatusRow
            label="Pending SOS"
            value={stats.sos.pending_sos}
            color="red"
          />
          <StatusRow
            label="Responding"
            value={stats.sos.responding_sos}
            color="yellow"
          />
          <StatusRow
            label="Resolved SOS"
            value={stats.sos.resolved_sos}
            color="green"
          />
        </div>
      </div>

      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <HelpCircle size={20} className="text-blue-400" />
          <h3 className="text-lg font-bold text-white">Help Requests</h3>
        </div>
        <div className="space-y-3">
          <StatusRow
            label="Pending"
            value={stats.helpRequests.pending_requests}
            color="yellow"
          />
          <StatusRow
            label="In Progress"
            value={stats.helpRequests.in_progress_requests}
            color="blue"
          />
          <StatusRow
            label="Resolved"
            value={stats.helpRequests.resolved_requests}
            color="green"
          />
        </div>
      </div>

      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <BarChart3 size={20} className="text-green-400" />
          <h3 className="text-lg font-bold text-white">Safety Status</h3>
        </div>
        <div className="space-y-3">
          <StatusRow
            label="Safe"
            value={stats.members.safe_members}
            color="green"
          />
          <StatusRow
            label="Unknown"
            value={stats.members.unknown_members}
            color="gray"
          />
          <StatusRow
            label="At Risk"
            value={stats.members.at_risk_members}
            color="red"
          />
        </div>
      </div>
    </div>
  );
}
