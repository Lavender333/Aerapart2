export function MembersTable({ members }) {
  return (
    <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
      <h2 className="text-2xl font-bold text-white mb-6">Members</h2>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-700">
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Name
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Organization
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Role
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Status
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Type
              </th>
              <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                Household
              </th>
            </tr>
          </thead>
          <tbody>
            {members.map((member) => (
              <tr
                key={member.id}
                className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors"
              >
                <td className="py-4 px-4">
                  <div>
                    <p className="text-white font-medium">{member.name}</p>
                    {member.age && (
                      <p className="text-slate-400 text-sm">
                        Age: {member.age}
                      </p>
                    )}
                  </div>
                </td>
                <td className="py-4 px-4">
                  <p className="text-slate-300">
                    {member.organization_name || "No organization"}
                  </p>
                </td>
                <td className="py-4 px-4">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold ${
                      member.org_role === "org_admin"
                        ? "bg-purple-900/30 text-purple-300 border border-purple-700"
                        : member.org_role === "general_user"
                          ? "bg-blue-900/30 text-blue-300 border border-blue-700"
                          : "bg-slate-700 text-slate-300 border border-slate-600"
                    }`}
                  >
                    {member.org_role || "N/A"}
                  </span>
                </td>
                <td className="py-4 px-4">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      member.status === "safe"
                        ? "bg-green-900/30 text-green-300"
                        : member.status === "unknown"
                          ? "bg-gray-700 text-gray-300"
                          : "bg-red-900/30 text-red-300"
                    }`}
                  >
                    {member.status}
                  </span>
                </td>
                <td className="py-4 px-4 text-slate-300">
                  {member.member_type}
                </td>
                <td className="py-4 px-4">
                  <p className="text-slate-300">
                    {member.household_name || "N/A"}
                  </p>
                  {member.household_address && (
                    <p className="text-slate-500 text-sm">
                      {member.household_address}
                    </p>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {members.length === 0 && (
          <p className="text-center py-8 text-slate-500">No members found</p>
        )}
      </div>
    </div>
  );
}
