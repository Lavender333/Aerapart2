"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useUser from "@/utils/useUser";
import {
  Bell,
  AlertTriangle,
  Shield,
  CheckCircle2,
  Building2,
  Package,
  HelpCircle,
  ChevronRight,
  MapPin,
  FileText,
  DollarSign,
  LogOut,
} from "lucide-react";

export default function MemberHomePage() {
  const { data: user, loading: userLoading } = useUser();
  const [showSupplyModal, setShowSupplyModal] = useState(false);
  const [selectedOrg, setSelectedOrg] = useState(null);
  const [showGetHelpModal, setShowGetHelpModal] = useState(false);
  const [helpMessage, setHelpMessage] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [joinError, setJoinError] = useState("");
  const queryClient = useQueryClient();

  // Fetch user's organizations
  const { data: organizations = [] } = useQuery({
    queryKey: ["organizations", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const res = await fetch(`/api/organizations?userId=${user.id}`);
      if (!res.ok) throw new Error("Failed to fetch organizations");
      return res.json();
    },
    enabled: !!user,
  });

  const primaryOrg = organizations[0];

  // Fetch announcements
  const { data: announcements = [] } = useQuery({
    queryKey: ["announcements", primaryOrg?.id],
    queryFn: async () => {
      const res = await fetch(`/api/announcements?org_id=${primaryOrg.id}`);
      if (!res.ok) throw new Error("Failed to fetch announcements");
      return res.json();
    },
    enabled: !!primaryOrg,
  });

  // Fetch status check
  const { data: statusCheck } = useQuery({
    queryKey: ["statusCheck", primaryOrg?.id],
    queryFn: async () => {
      const res = await fetch(`/api/status-check?org_id=${primaryOrg.id}`);
      if (!res.ok) throw new Error("Failed to fetch status check");
      return res.json();
    },
    enabled: !!primaryOrg,
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  // Fetch inventory for supply levels
  const { data: inventory = [] } = useQuery({
    queryKey: ["inventory", selectedOrg?.id],
    queryFn: async () => {
      const res = await fetch(
        `/api/disaster-relief/inventory?org_id=${selectedOrg.id}`,
      );
      if (!res.ok) throw new Error("Failed to fetch inventory");
      return res.json();
    },
    enabled: !!selectedOrg,
  });

  // Join organization mutation
  const joinOrgMutation = useMutation({
    mutationFn: async (code) => {
      const res = await fetch("/api/organizations/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: code.toUpperCase(),
          role: "general_user",
        }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to join organization");
      }
      return res.json();
    },
    onSuccess: async (data) => {
      const orgId = data.organization?.id;

      // Update household with org_id if user has a household
      if (orgId) {
        try {
          await fetch("/api/disaster-relief/household", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ orgId }),
          });
          console.log("✅ Household updated with org_id:", orgId);
        } catch (error) {
          console.error("Error updating household:", error);
        }
      }

      queryClient.invalidateQueries(["organizations", user?.id]);
      setJoinCode("");
      setJoinError("");
      // Reload the page to show the new org
      window.location.reload();
    },
    onError: (error) => {
      setJoinError(error.message);
    },
  });

  // Submit status response
  const submitStatusMutation = useMutation({
    mutationFn: async (response) => {
      const res = await fetch("/api/status-check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status_check_id: statusCheck.statusCheck.id,
          response,
          org_id: primaryOrg.id,
        }),
      });
      if (!res.ok) throw new Error("Failed to submit response");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["statusCheck", primaryOrg?.id]);
    },
  });

  // Submit help request
  const submitHelpMutation = useMutation({
    mutationFn: async (message) => {
      const res = await fetch("/api/help-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          org_id: primaryOrg.id,
          message,
          request_type: "assistance",
          priority: "medium",
        }),
      });
      if (!res.ok) throw new Error("Failed to submit help request");
      return res.json();
    },
    onSuccess: () => {
      setShowGetHelpModal(false);
      setHelpMessage("");
      alert("Help request submitted successfully!");
    },
  });

  useEffect(() => {
    if (!userLoading && !user) {
      window.location.href = "/account/signin";
    }
  }, [user, userLoading]);

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  const getSupplyLevel = (item) => {
    const percentage = (item.quantity / item.capacity) * 100;
    if (percentage >= 70)
      return { level: "High", color: "text-green-600", bg: "bg-green-100" };
    if (percentage >= 30)
      return { level: "Medium", color: "text-yellow-600", bg: "bg-yellow-100" };
    return { level: "Low", color: "text-red-600", bg: "bg-red-100" };
  };

  // If no organization, show welcome screen with join option
  if (!primaryOrg) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="max-w-4xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold">
                  A
                </div>
                <h1 className="text-lg font-bold text-gray-900">AERA</h1>
              </div>
              <a
                href="/account/logout"
                className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
              >
                <LogOut size={18} className="text-gray-600" />
              </a>
            </div>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-4 py-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">
              Welcome to AERA, {user.name || "User"}!
            </h2>
            <p className="text-gray-600 text-lg">
              Get connected to your community and access disaster relief
              resources
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 max-w-2xl mx-auto">
            <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Building2 size={32} className="text-blue-600" />
            </div>

            <h3 className="text-2xl font-bold text-gray-900 text-center mb-3">
              Join an Organization
            </h3>
            <p className="text-gray-600 text-center mb-8">
              Connect with your local disaster relief organization to access
              resources, receive alerts, and stay informed during emergencies.
            </p>

            {/* Join Code Input */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Have a join code?
              </label>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={joinCode}
                  onChange={(e) => {
                    setJoinCode(e.target.value.toUpperCase());
                    setJoinError("");
                  }}
                  placeholder="Enter 6-character code"
                  maxLength={6}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-mono text-lg tracking-widest uppercase"
                />
                <button
                  onClick={() => joinOrgMutation.mutate(joinCode)}
                  disabled={joinCode.length !== 6 || joinOrgMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white px-6 py-3 rounded-2xl font-bold transition-colors"
                >
                  {joinOrgMutation.isPending ? "Joining..." : "Join"}
                </button>
              </div>
              {joinError && (
                <p className="text-red-600 text-sm mt-2 flex items-center gap-2">
                  <AlertTriangle size={16} />
                  {joinError}
                </p>
              )}
              <p className="text-sm text-gray-500 mt-2">
                Ask your organization admin for the join code
              </p>
            </div>

            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-white text-gray-500">or</span>
              </div>
            </div>

            <div className="space-y-4">
              <a
                href="/organizations"
                className="block w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg transition-all text-center"
              >
                Browse or Create Organization
              </a>

              <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="bg-blue-50 rounded-2xl p-4 text-center">
                  <AlertTriangle
                    size={24}
                    className="text-blue-600 mx-auto mb-2"
                  />
                  <p className="text-sm font-semibold text-gray-900">
                    Emergency Alerts
                  </p>
                </div>
                <div className="bg-green-50 rounded-2xl p-4 text-center">
                  <Package size={24} className="text-green-600 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-gray-900">
                    Resource Access
                  </p>
                </div>
                <div className="bg-purple-50 rounded-2xl p-4 text-center">
                  <HelpCircle
                    size={24}
                    className="text-purple-600 mx-auto mb-2"
                  />
                  <p className="text-sm font-semibold text-gray-900">
                    Get Help
                  </p>
                </div>
                <div className="bg-orange-50 rounded-2xl p-4 text-center">
                  <Bell size={24} className="text-orange-600 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-gray-900">
                    Status Updates
                  </p>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold">
                A
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">AERA</h1>
                <p className="text-xs text-gray-500">{primaryOrg.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors">
                <Bell size={18} className="text-gray-600" />
              </button>
              <a
                href="/account/logout"
                className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
              >
                <LogOut size={18} className="text-gray-600" />
              </a>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* Welcome Section */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-1">
            Welcome, {user.name || "User"}!
          </h2>
          <p className="text-gray-600">Stay informed and stay safe</p>
        </div>

        {/* Status Check Request */}
        {statusCheck?.hasActiveCheck && !statusCheck?.hasResponded && (
          <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-3xl p-6 text-white shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <AlertTriangle size={24} />
              <h3 className="text-xl font-bold">Status Check Requested</h3>
            </div>
            <p className="text-lg mb-6 text-purple-100">
              {statusCheck.statusCheck.message}
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => submitStatusMutation.mutate("safe")}
                disabled={submitStatusMutation.isPending}
                className="flex-1 bg-green-500 hover:bg-green-600 disabled:bg-green-400 text-white font-bold py-4 rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2"
              >
                <CheckCircle2 size={20} />I Am Safe
              </button>
              <button
                onClick={() => submitStatusMutation.mutate("need_help")}
                disabled={submitStatusMutation.isPending}
                className="flex-1 bg-red-500 hover:bg-red-600 disabled:bg-red-400 text-white font-bold py-4 rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2"
              >
                <AlertTriangle size={20} />I Need Help
              </button>
            </div>
          </div>
        )}

        {/* Status Check Response Confirmation */}
        {statusCheck?.hasActiveCheck && statusCheck?.hasResponded && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-4">
            <div className="flex items-center gap-3">
              <CheckCircle2 size={20} className="text-green-600" />
              <div>
                <p className="font-semibold text-green-900">Status Submitted</p>
                <p className="text-sm text-green-700">
                  You marked yourself as:{" "}
                  {statusCheck.response.response === "safe"
                    ? "Safe"
                    : "Needing Help"}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Get Help Button */}
        <button
          onClick={() => setShowGetHelpModal(true)}
          className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-3"
        >
          <HelpCircle size={24} />
          Get Help
        </button>

        {/* Announcements */}
        {announcements.length > 0 && (
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Bell size={20} className="text-blue-600" />
              Announcements
            </h3>
            <div className="space-y-4">
              {announcements.slice(0, 3).map((announcement) => (
                <div
                  key={announcement.id}
                  className="p-4 bg-blue-50 rounded-2xl border border-blue-100"
                >
                  <h4 className="font-bold text-gray-900 mb-1">
                    {announcement.title}
                  </h4>
                  <p className="text-sm text-gray-700 mb-2">
                    {announcement.message}
                  </p>
                  <p className="text-xs text-gray-500">
                    {new Date(announcement.created_at).toLocaleDateString()} •{" "}
                    {announcement.created_by_name || "Organization"}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Nearest Resource Depot */}
        <button
          onClick={() => {
            setSelectedOrg(primaryOrg);
            setShowSupplyModal(true);
          }}
          className="w-full bg-white rounded-3xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all text-left"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <Building2 size={24} className="text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Nearest Resource Depot</p>
                <h3 className="text-lg font-bold text-gray-900">
                  {primaryOrg.name}
                </h3>
              </div>
            </div>
            <ChevronRight size={20} className="text-gray-400" />
          </div>
          {primaryOrg.address && (
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <MapPin size={16} />
              <span>{primaryOrg.address}</span>
            </div>
          )}
        </button>

        {/* Recovery & Resources */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-xl font-bold text-gray-900 mb-4">
            Recovery & Resources
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-4 border border-green-200">
              <div className="w-10 h-10 bg-green-500 rounded-xl flex items-center justify-center mb-3">
                <DollarSign size={20} className="text-white" />
              </div>
              <h4 className="font-bold text-gray-900 text-sm mb-1">
                G.A.P. Center
              </h4>
              <p className="text-xs text-gray-600">
                Grants, Advances & Payments
              </p>
            </div>
            <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl p-4 border border-orange-200">
              <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center mb-3">
                <FileText size={20} className="text-white" />
              </div>
              <h4 className="font-bold text-gray-900 text-sm mb-1">
                Assessments
              </h4>
              <p className="text-xs text-gray-600">Report damage & needs</p>
            </div>
          </div>
        </div>

        {/* Alerts Console */}
        <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-3xl p-6 text-white shadow-lg">
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle size={24} />
            <h3 className="text-xl font-bold">Alerts Console</h3>
          </div>
          <p className="text-red-100 text-sm mb-4">
            Critical emergency information
          </p>
          <div className="bg-red-400/30 rounded-2xl p-4 backdrop-blur">
            <p className="font-bold mb-1">Flash Flood Warning</p>
            <p className="text-sm text-red-100">
              Severe weather alert active in your area. Stay indoors and avoid
              low-lying areas.
            </p>
          </div>
        </div>
      </main>

      {/* Supply Levels Modal */}
      {showSupplyModal && selectedOrg && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                Supply Levels
              </h2>
              <button
                onClick={() => {
                  setShowSupplyModal(false);
                  setSelectedOrg(null);
                }}
                className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="mb-6">
              <p className="text-sm text-gray-600 mb-1">Organization</p>
              <p className="font-bold text-gray-900">{selectedOrg.name}</p>
            </div>

            <div className="space-y-3">
              {inventory.length > 0 ? (
                inventory.map((item) => {
                  const supplyInfo = getSupplyLevel(item);
                  return (
                    <div
                      key={item.id}
                      className="p-4 bg-gray-50 rounded-2xl flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <Package size={20} className="text-gray-600" />
                        <div>
                          <p className="font-bold text-gray-900">
                            {item.item_name}
                          </p>
                          <p className="text-sm text-gray-600">
                            {item.quantity} {item.unit} available
                          </p>
                        </div>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold ${supplyInfo.bg} ${supplyInfo.color}`}
                      >
                        {supplyInfo.level}
                      </span>
                    </div>
                  );
                })
              ) : (
                <p className="text-center text-gray-500 py-8">
                  No supply information available
                </p>
              )}
            </div>

            <button
              onClick={() => {
                setShowSupplyModal(false);
                setSelectedOrg(null);
              }}
              className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-2xl transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Get Help Modal */}
      {showGetHelpModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Request Help
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  What do you need help with?
                </label>
                <textarea
                  value={helpMessage}
                  onChange={(e) => setHelpMessage(e.target.value)}
                  placeholder="Describe your situation and what assistance you need..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none min-h-[120px]"
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowGetHelpModal(false);
                    setHelpMessage("");
                  }}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-2xl font-semibold text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => submitHelpMutation.mutate(helpMessage)}
                  disabled={!helpMessage.trim() || submitHelpMutation.isPending}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white px-4 py-3 rounded-2xl font-semibold transition-colors"
                >
                  {submitHelpMutation.isPending ? "Submitting..." : "Submit"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
