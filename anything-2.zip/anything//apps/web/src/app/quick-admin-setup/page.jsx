"use client";

import { useState } from "react";

export default function QuickAdminSetup() {
  const [status, setStatus] = useState("");

  const createAdmin = async () => {
    setStatus("Creating...");
    try {
      const response = await fetch("/api/admin/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: "aerapp369@gmail.com",
          password: "aerapp369",
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setStatus("✅ Admin created! Go to /admin/login");
      } else {
        setStatus("❌ Error: " + (data.error || "Failed"));
      }
    } catch (error) {
      setStatus("❌ Error: " + error.message);
    }
  };

  return (
    <div style={{ padding: "40px", maxWidth: "500px", margin: "0 auto" }}>
      <h1>Quick Admin Setup</h1>
      <p>Email: aerapp369@gmail.com</p>
      <p>Password: aerapp369</p>
      <button
        onClick={createAdmin}
        style={{
          padding: "12px 24px",
          fontSize: "16px",
          backgroundColor: "#dc2626",
          color: "white",
          border: "none",
          borderRadius: "8px",
          cursor: "pointer",
          marginTop: "20px",
        }}
      >
        Create Admin Now
      </button>
      {status && (
        <p style={{ marginTop: "20px", fontSize: "18px" }}>{status}</p>
      )}
    </div>
  );
}
