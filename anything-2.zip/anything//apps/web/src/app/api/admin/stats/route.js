import { getToken } from "@auth/core/jwt";
import sql from "../../utils/sql";

export async function GET(request) {
  try {
    const jwt = await getToken({
      req: request,
      secret: process.env.AUTH_SECRET,
      secureCookie: process.env.AUTH_URL?.startsWith("https"),
    });

    if (!jwt) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify user is system admin
    const adminCheck = await sql`
      SELECT system_role
      FROM auth_users
      WHERE id = ${parseInt(jwt.sub)}
    `;

    if (
      adminCheck.length === 0 ||
      adminCheck[0].system_role !== "system_admin"
    ) {
      return Response.json(
        { error: "Access denied. System admin privileges required." },
        { status: 403 },
      );
    }

    // Get system-wide statistics
    const [userStats] = await sql`
      SELECT 
        COUNT(*) as total_users,
        COUNT(*) FILTER (WHERE system_role = 'system_admin') as admin_count,
        COUNT(*) FILTER (WHERE system_role = 'user') as regular_user_count
      FROM auth_users
    `;

    const [orgStats] = await sql`
      SELECT COUNT(*) as total_organizations
      FROM organizations
    `;

    const [householdStats] = await sql`
      SELECT COUNT(*) as total_households
      FROM households
    `;

    const [memberStats] = await sql`
      SELECT 
        COUNT(*) as total_members,
        COUNT(*) FILTER (WHERE status = 'safe') as safe_members,
        COUNT(*) FILTER (WHERE status = 'unknown') as unknown_members,
        COUNT(*) FILTER (WHERE status IN ('unsafe', 'needs_help')) as at_risk_members
      FROM members
    `;

    const [sosStats] = await sql`
      SELECT 
        COUNT(*) as total_sos,
        COUNT(*) FILTER (WHERE status = 'pending') as pending_sos,
        COUNT(*) FILTER (WHERE status = 'responding') as responding_sos,
        COUNT(*) FILTER (WHERE status = 'resolved') as resolved_sos
      FROM sos_requests
    `;

    const [helpStats] = await sql`
      SELECT 
        COUNT(*) as total_help_requests,
        COUNT(*) FILTER (WHERE status = 'pending') as pending_requests,
        COUNT(*) FILTER (WHERE status = 'in_progress') as in_progress_requests,
        COUNT(*) FILTER (WHERE status = 'resolved') as resolved_requests
      FROM help_requests
    `;

    return Response.json({
      users: userStats,
      organizations: orgStats,
      households: householdStats,
      members: memberStats,
      sos: sosStats,
      helpRequests: helpStats,
    });
  } catch (error) {
    console.error("Error fetching admin stats:", error);
    return Response.json(
      { error: "Failed to fetch statistics" },
      { status: 500 },
    );
  }
}
