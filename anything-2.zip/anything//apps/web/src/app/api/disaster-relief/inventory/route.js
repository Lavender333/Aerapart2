import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const orgId = searchParams.get("orgId") || 1;

    const rows = await sql`
      SELECT * FROM inventory 
      WHERE org_id = ${orgId} 
      ORDER BY category, item_name
    `;

    return Response.json(rows);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to fetch inventory" },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const body = await request.json();
    const { id, quantity } = body;

    const [updated] = await sql`
      UPDATE inventory 
      SET quantity = ${quantity}, updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id} 
      RETURNING *
    `;

    return Response.json(updated);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to update inventory" },
      { status: 500 },
    );
  }
}
