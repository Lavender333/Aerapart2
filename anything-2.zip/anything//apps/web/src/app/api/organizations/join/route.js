import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Join an organization using a join code
export async function POST(request) {
  try {
    const session = await auth();

    if (!session || !session.user) {
      return Response.json(
        { error: "You must be signed in to join an organization" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { code, role } = body;

    if (!code) {
      return Response.json({ error: "Join code is required" }, { status: 400 });
    }

    // Find organization by join code
    const [org] = await sql`
      SELECT * FROM organizations
      WHERE join_code = ${code.toUpperCase()}
    `;

    if (!org) {
      return Response.json({ error: "Invalid join code" }, { status: 404 });
    }

    // Get user ID from session
    const userId = session.user.id;

    // Determine the role to assign
    // If they selected 'org_admin' during signup, make them org_admin
    // Otherwise, make them general_user (member)
    const userRole = role === "org_admin" ? "org_admin" : "general_user";

    // Check if user is already in this organization
    const [existing] = await sql`
      SELECT * FROM user_organizations
      WHERE user_id = ${userId.toString()} AND org_id = ${org.id}
    `;

    if (existing) {
      return Response.json(
        { error: "You are already a member of this organization" },
        { status: 400 },
      );
    }

    // Add user to organization
    await sql`
      INSERT INTO user_organizations (user_id, org_id, role)
      VALUES (${userId.toString()}, ${org.id}, ${userRole})
    `;

    return Response.json({
      success: true,
      organization: org,
      role: userRole,
    });
  } catch (error) {
    console.error("Error joining organization:", error);
    return Response.json(
      { error: "Failed to join organization" },
      { status: 500 },
    );
  }
}
