import sql from "../../utils/sql";
import argon2 from "argon2";
import { encode } from "@auth/core/jwt";

export async function POST(request) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return Response.json(
        { error: "Email and password are required" },
        { status: 400 },
      );
    }

    console.log("Step 1: Finding user by email:", email);
    // Find user by email
    const users = await sql`
      SELECT id, email, system_role, name
      FROM auth_users
      WHERE email = ${email}
    `;

    if (users.length === 0) {
      console.log("Step 1 FAILED: User not found");
      return Response.json({ error: "Invalid credentials" }, { status: 401 });
    }

    const user = users[0];
    console.log("Step 1 SUCCESS: User found", user);

    // Check if user is system admin
    if (user.system_role !== "system_admin") {
      console.log("Step 2 FAILED: Not a system admin");
      return Response.json(
        { error: "Access denied. System admin privileges required." },
        { status: 403 },
      );
    }
    console.log("Step 2 SUCCESS: User is system admin");

    console.log("Step 3: Getting password hash from auth_accounts");
    // Get password hash from auth_accounts
    const accounts = await sql`
      SELECT password
      FROM auth_accounts
      WHERE "userId" = ${user.id} AND type = 'credentials'
    `;

    if (accounts.length === 0 || !accounts[0].password) {
      console.log("Step 3 FAILED: No password found");
      return Response.json({ error: "Invalid credentials" }, { status: 401 });
    }

    // Convert to string explicitly and validate
    let passwordHash = String(accounts[0].password);
    console.log(
      "Step 3 SUCCESS: Password hash retrieved",
      "\nType:",
      typeof passwordHash,
      "\nLength:",
      passwordHash?.length,
      "\nPrefix:",
      passwordHash?.substring(0, 15),
      "\nConstructor:",
      passwordHash?.constructor?.name,
    );

    // Validate that passwordHash is a string and looks like an argon2 hash
    if (!passwordHash || typeof passwordHash !== "string") {
      console.log("Step 3.5 FAILED: Password is not a string");
      return Response.json({ error: "Invalid credentials" }, { status: 401 });
    }

    if (!passwordHash.startsWith("$argon2")) {
      console.log(
        "Step 3.5 FAILED: Invalid password hash format - doesn't start with $argon2",
      );
      return Response.json({ error: "Invalid credentials" }, { status: 401 });
    }

    console.log("Step 4: Verifying password with argon2");
    console.log("Hash to verify:", passwordHash);
    console.log("Password provided:", password ? "[PROVIDED]" : "[MISSING]");

    // Verify password
    const validPassword = await argon2.verify(passwordHash, password);

    if (!validPassword) {
      console.log("Step 4 FAILED: Password verification failed");
      return Response.json({ error: "Invalid credentials" }, { status: 401 });
    }
    console.log("Step 4 SUCCESS: Password verified");

    console.log("Step 5: Creating session token");
    // Create a session token
    const token = await encode({
      token: {
        sub: user.id.toString(),
        email: user.email,
        name: user.name,
      },
      secret: process.env.AUTH_SECRET,
      maxAge: 30 * 24 * 60 * 60, // 30 days
    });
    console.log("Step 5 SUCCESS: Token created");

    console.log("Step 6: Creating session in database");
    // Create a session in the database
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await sql`
      INSERT INTO auth_sessions ("userId", "sessionToken", expires)
      VALUES (${user.id}, ${token}, ${expiresAt})
    `;
    console.log("Step 6 SUCCESS: Session created");

    console.log("Step 7: Setting cookie and returning response");
    // Set the session cookie
    const response = Response.json({
      success: true,
      isSystemAdmin: true,
      user: {
        id: user.id,
        email: user.email,
        system_role: user.system_role,
      },
    });

    const isSecure = process.env.AUTH_URL?.startsWith("https");
    response.headers.set(
      "Set-Cookie",
      `authjs.session-token=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${30 * 24 * 60 * 60}${isSecure ? "; Secure" : ""}`,
    );

    console.log("Step 7 SUCCESS: All done!");
    return response;
  } catch (error) {
    console.error("❌ Admin signin error:", error);
    console.error("Error name:", error.name);
    console.error("Error message:", error.message);
    console.error("Error stack:", error.stack);

    // More detailed error for argon2 issues
    if (
      error.message?.includes("salt") ||
      error.message?.includes("Uint8Array")
    ) {
      console.error(
        "🔍 This is an argon2 verification error - the hash format may be corrupted",
      );
    }

    return Response.json(
      {
        error: "Authentication failed",
        details: error.message,
        step: "Check server logs for details",
      },
      { status: 500 },
    );
  }
}
