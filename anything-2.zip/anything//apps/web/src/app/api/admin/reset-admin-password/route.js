import sql from "../../utils/sql";
import argon2 from "argon2";

export async function POST(request) {
  try {
    const { email, newPassword } = await request.json();

    if (!email || !newPassword) {
      return Response.json(
        { error: "Email and new password are required" },
        { status: 400 },
      );
    }

    console.log("Looking for user:", email);

    // Find user
    const users = await sql`
      SELECT id, system_role
      FROM auth_users
      WHERE email = ${email}
    `;

    if (users.length === 0) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    const userId = users[0].id;
    console.log("User found, ID:", userId);

    // Hash new password
    const hashedPassword = await argon2.hash(newPassword);
    console.log("Password hashed, length:", hashedPassword.length);

    // Update password in auth_accounts
    await sql`
      UPDATE auth_accounts
      SET password = ${hashedPassword}
      WHERE "userId" = ${userId} AND type = 'credentials'
    `;

    console.log("Password updated successfully");

    return Response.json({
      success: true,
      message: "Admin password reset successfully",
      userId,
    });
  } catch (error) {
    console.error("Password reset error:", error);
    return Response.json(
      { error: "Failed to reset password", details: error.message },
      { status: 500 },
    );
  }
}
