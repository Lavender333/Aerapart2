import sql from "@/app/api/utils/sql";
import { hash } from "argon2";

export async function POST(req) {
  try {
    const { email, password, name, role = "system_admin" } = await req.json();

    if (!email || !password) {
      return Response.json(
        { error: "Email and password required" },
        { status: 400 },
      );
    }

    // Check if user already exists
    const existing = await sql`
      SELECT id FROM auth_users WHERE email = ${email}
    `;

    if (existing.length > 0) {
      return Response.json({ error: "User already exists" }, { status: 400 });
    }

    // Hash the password
    const hashedPassword = await hash(password);

    // Create user and account in a transaction
    const result = await sql.transaction([
      sql`
        INSERT INTO auth_users (name, email, system_role)
        VALUES (${name || email}, ${email}, ${role})
        RETURNING id
      `,
      sql`
        INSERT INTO auth_accounts ("userId", type, provider, "providerAccountId", password)
        SELECT id, 'credentials', 'credentials', ${email}, ${hashedPassword}
        FROM auth_users
        WHERE email = ${email}
        RETURNING id
      `,
    ]);

    return Response.json({
      success: true,
      message: "Admin user created successfully",
      userId: result[0][0].id,
      email: email,
      role: role,
    });
  } catch (error) {
    console.error("Error creating admin user:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
