import sql from "@/app/api/utils/sql";
import { sendEmail } from "@/app/api/utils/send-email";
import crypto from "crypto";

export async function POST(request) {
  try {
    const { email } = await request.json();

    if (!email) {
      return Response.json({ error: "Email is required" }, { status: 400 });
    }

    // Find user by email
    const [user] = await sql`
      SELECT id, email, name FROM auth_users WHERE email = ${email}
    `;

    // Always return success to prevent email enumeration
    if (!user) {
      return Response.json({
        message: "If an account exists, a reset email has been sent",
      });
    }

    // Generate secure token
    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour from now

    // Store token in database
    await sql`
      INSERT INTO password_reset_tokens (token, user_id, expires_at)
      VALUES (${token}, ${user.id}, ${expiresAt})
    `;

    // Send reset email
    const resetUrl = `${process.env.APP_URL}/account/reset-password?token=${token}`;

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
              background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
              padding: 40px 20px;
              margin: 0;
            }
            .container { 
              max-width: 600px; 
              margin: 0 auto; 
              background: white; 
              border-radius: 24px; 
              overflow: hidden;
              box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            .header { 
              background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%); 
              padding: 40px 30px; 
              text-align: center;
            }
            .lock-icon {
              width: 60px;
              height: 60px;
              background: white;
              border-radius: 16px;
              display: inline-flex;
              align-items: center;
              justify-content: center;
              font-size: 32px;
              margin-bottom: 16px;
            }
            .header h1 { 
              color: white; 
              margin: 0;
              font-size: 28px;
              font-weight: 800;
            }
            .content { 
              padding: 40px 30px; 
              color: #1F2937;
              line-height: 1.6;
            }
            .greeting { 
              font-size: 20px; 
              font-weight: 700; 
              color: #111827;
              margin-bottom: 16px;
            }
            .reset-button {
              display: inline-block;
              background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
              color: white;
              padding: 16px 32px;
              border-radius: 12px;
              text-decoration: none;
              font-weight: 700;
              margin: 24px 0;
              box-shadow: 0 10px 30px rgba(59, 130, 246, 0.3);
            }
            .warning-box {
              background: #FEF3C7;
              border: 2px solid #FCD34D;
              border-radius: 12px;
              padding: 16px;
              margin: 24px 0;
            }
            .warning-box strong {
              color: #92400E;
              font-size: 14px;
            }
            .footer {
              background: #F9FAFB;
              padding: 24px 30px;
              text-align: center;
              color: #6B7280;
              font-size: 12px;
              border-top: 1px solid #E5E7EB;
            }
            .code-box {
              background: #F3F4F6;
              border: 1px solid #D1D5DB;
              border-radius: 8px;
              padding: 12px;
              font-family: monospace;
              font-size: 12px;
              color: #4B5563;
              word-break: break-all;
              margin: 16px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="lock-icon">🔒</div>
              <h1>Password Reset Request</h1>
            </div>
            <div class="content">
              <div class="greeting">Hi ${user.name || "there"}! 👋</div>
              <p>We received a request to reset your password for your AERA account. If you made this request, click the button below to create a new password.</p>
              
              <center>
                <a href="${resetUrl}" class="reset-button">Reset My Password</a>
              </center>

              <p style="margin-top: 24px; color: #6B7280; font-size: 14px;">
                Or copy and paste this link into your browser:
              </p>
              <div class="code-box">${resetUrl}</div>

              <div class="warning-box">
                <strong>⏱️ This link expires in 1 hour</strong><br/>
                <span style="color: #92400E; font-size: 12px;">For security, reset links are only valid for 60 minutes</span>
              </div>

              <p style="margin-top: 24px; color: #6B7280; font-size: 13px;">
                <strong>Didn't request this?</strong><br/>
                If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.
              </p>
            </div>
            <div class="footer">
              <p>AERA - Advanced Emergency Response & Assistance</p>
              <p>This is an automated security email.</p>
            </div>
          </div>
        </body>
      </html>
    `;

    const text = `
      Password Reset Request - AERA
      
      Hi ${user.name || "there"}!
      
      We received a request to reset your password for your AERA account.
      
      Reset your password by clicking this link:
      ${resetUrl}
      
      This link expires in 1 hour for security.
      
      If you didn't request this, you can safely ignore this email.
      
      AERA - Advanced Emergency Response & Assistance
    `;

    try {
      await sendEmail({
        to: email,
        subject: "Reset Your AERA Password",
        html,
        text,
      });
    } catch (emailError) {
      console.error("Failed to send password reset email:", emailError);
      // Don't reveal email service issues to the user
    }

    return Response.json({
      message: "If an account exists, a reset email has been sent",
    });
  } catch (error) {
    console.error("Forgot password error:", error);
    return Response.json(
      { error: "Failed to process request" },
      { status: 500 },
    );
  }
}
