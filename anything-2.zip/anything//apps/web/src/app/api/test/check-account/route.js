import sql from "@/app/api/utils/sql";
import * as argon2 from "argon2";

export async function POST(request) {
  try {
    const { email, password } = await request.json();

    console.log("🔍 Checking account for:", email);

    if (!email) {
      return Response.json({ error: "Email is required" }, { status: 400 });
    }

    // Check if user exists
    const users = await sql`
      SELECT id, name, email, system_role
      FROM auth_users
      WHERE email = ${email}
    `;

    if (users.length === 0) {
      console.log("❌ No user found with email:", email);
      return Response.json({
        userExists: false,
        message: "No user found with this email",
      });
    }

    const user = users[0];
    console.log("✅ User found:", {
      id: user.id,
      name: user.name,
      email: user.email,
    });

    // Check if password exists
    const accounts = await sql`
      SELECT id, password
      FROM auth_accounts
      WHERE "userId" = ${user.id} AND type = 'credentials'
    `;

    const hasPassword = accounts.length > 0 && accounts[0].password;
    console.log("Password exists:", hasPassword ? "Yes" : "No");

    let passwordValid = undefined;

    // If password was provided, verify it
    if (password && hasPassword) {
      try {
        passwordValid = await argon2.verify(accounts[0].password, password);
        console.log("Password valid:", passwordValid ? "Yes" : "No");
      } catch (err) {
        console.error("Password verification error:", err);
        passwordValid = false;
      }
    }

    return Response.json({
      userExists: true,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      systemRole: user.system_role,
      hasPassword,
      passwordValid,
      accountsCount: accounts.length,
      message: "Account check completed",
    });
  } catch (error) {
    console.error("❌ Account check error:", error);
    return Response.json(
      { error: "Failed to check account", details: error.message },
      { status: 500 },
    );
  }
}
