import { sendEmail } from "@/app/api/utils/send-email";
import sql from "@/app/api/utils/sql";

// Send alerts for new SOS requests to all organization members
export async function POST(request) {
  try {
    const body = await request.json();
    const { sosId, orgId } = body;

    if (!sosId || !orgId) {
      return Response.json(
        { error: "SOS ID and Organization ID are required" },
        { status: 400 },
      );
    }

    // Get SOS details
    const [sos] = await sql`
      SELECT * FROM sos_requests WHERE id = ${sosId}
    `;

    if (!sos) {
      return Response.json({ error: "SOS request not found" }, { status: 404 });
    }

    // Get organization details
    const [org] = await sql`
      SELECT * FROM organizations WHERE id = ${orgId}
    `;

    // Get all members of the organization (excluding the requester if they're a member)
    const members = await sql`
      SELECT u.email, u.name, uo.role
      FROM auth_users u
      INNER JOIN user_organizations uo ON u.id = uo.user_id::integer
      WHERE uo.org_id = ${orgId}
    `;

    const emailPromises = [];
    const smsPromises = [];

    // Send email to each member
    for (const member of members) {
      if (!member.email) continue;

      const html = `
        <!DOCTYPE html>
        <html>
          <head>
            <style>
              body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
                background: #FEF2F2;
                padding: 20px;
                margin: 0;
              }
              .container { 
                max-width: 600px; 
                margin: 0 auto; 
                background: white; 
                border-radius: 24px; 
                overflow: hidden;
                border: 3px solid #EF4444;
                box-shadow: 0 20px 60px rgba(239, 68, 68, 0.3);
              }
              .header { 
                background: linear-gradient(135deg, #DC2626 0%, #EF4444 100%); 
                padding: 30px; 
                text-align: center;
                position: relative;
              }
              .pulse {
                width: 80px;
                height: 80px;
                background: white;
                border-radius: 50%;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                font-size: 40px;
                margin-bottom: 16px;
                animation: pulse 2s infinite;
              }
              @keyframes pulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.1); }
              }
              .header h1 { 
                color: white; 
                margin: 0;
                font-size: 32px;
                font-weight: 900;
                text-transform: uppercase;
                letter-spacing: 2px;
              }
              .alert-badge {
                background: white;
                color: #DC2626;
                padding: 8px 20px;
                border-radius: 20px;
                font-weight: 900;
                font-size: 12px;
                display: inline-block;
                margin-top: 12px;
                letter-spacing: 1px;
              }
              .content { 
                padding: 30px; 
              }
              .priority-box {
                background: ${sos.priority === "high" ? "#FEE2E2" : "#FEF3C7"};
                border-left: 4px solid ${sos.priority === "high" ? "#DC2626" : "#F59E0B"};
                padding: 20px;
                border-radius: 12px;
                margin: 20px 0;
              }
              .info-row {
                display: flex;
                align-items: start;
                margin-bottom: 16px;
                padding-bottom: 16px;
                border-bottom: 1px solid #E5E7EB;
              }
              .info-row:last-child {
                border-bottom: none;
                margin-bottom: 0;
                padding-bottom: 0;
              }
              .info-label {
                font-weight: 700;
                color: #374151;
                min-width: 120px;
              }
              .info-value {
                color: #1F2937;
                flex: 1;
              }
              .map-link {
                display: inline-block;
                background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
                color: white;
                padding: 16px 32px;
                border-radius: 12px;
                text-decoration: none;
                font-weight: 700;
                margin: 24px 0;
                box-shadow: 0 10px 30px rgba(59, 130, 246, 0.3);
              }
              .footer {
                background: #FEF2F2;
                padding: 20px;
                text-align: center;
                font-size: 12px;
                color: #991B1B;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <div class="pulse">🚨</div>
                <h1>SOS Alert</h1>
                <div class="alert-badge">${sos.priority === "high" ? "HIGH PRIORITY" : "MEDIUM PRIORITY"}</div>
              </div>
              <div class="content">
                <p style="font-size: 18px; font-weight: 700; color: #1F2937; margin-bottom: 20px;">
                  Emergency assistance requested in ${org?.name || "your area"}
                </p>
                
                <div class="priority-box">
                  <div style="font-weight: 900; color: ${sos.priority === "high" ? "#991B1B" : "#92400E"}; margin-bottom: 8px; font-size: 14px;">
                    ${sos.priority === "high" ? "⚠️ HIGH PRIORITY EMERGENCY" : "⚡ ASSISTANCE NEEDED"}
                  </div>
                  <div style="color: #4B5563;">
                    ${sos.message || "No additional details provided"}
                  </div>
                </div>

                <div style="background: #F9FAFB; border-radius: 16px; padding: 24px; margin: 24px 0;">
                  <div class="info-row">
                    <div class="info-label">👤 Reporter:</div>
                    <div class="info-value">${sos.reporter_name || "Anonymous"}</div>
                  </div>
                  <div class="info-row">
                    <div class="info-label">📍 Location:</div>
                    <div class="info-value">
                      ${sos.latitude.toFixed(6)}, ${sos.longitude.toFixed(6)}
                    </div>
                  </div>
                  <div class="info-row">
                    <div class="info-label">⏰ Time:</div>
                    <div class="info-value">${new Date(sos.created_at).toLocaleString()}</div>
                  </div>
                  <div class="info-row">
                    <div class="info-label">🆔 Request ID:</div>
                    <div class="info-value">#${sos.id}</div>
                  </div>
                </div>

                <center>
                  <a href="https://www.google.com/maps?q=${sos.latitude},${sos.longitude}" class="map-link">
                    📍 View Location on Map
                  </a>
                </center>

                <div style="background: #FFFBEB; border: 2px solid #FCD34D; border-radius: 12px; padding: 16px; margin-top: 24px;">
                  <div style="color: #92400E; font-size: 14px; font-weight: 700; margin-bottom: 4px;">
                    ⚡ Action Required
                  </div>
                  <div style="color: #78350F; font-size: 12px;">
                    ${member.role === "admin" || member.role === "responder" ? "Please coordinate response efforts immediately." : "Please standby for updates from your response team."}
                  </div>
                </div>

                <p style="margin-top: 24px; color: #6B7280; font-size: 13px;">
                  Log in to your AERA dashboard to coordinate response, update status, and communicate with your team.
                </p>
              </div>
              <div class="footer">
                <strong>AERA Emergency Response System</strong><br/>
                This is an automated emergency notification
              </div>
            </div>
          </body>
        </html>
      `;

      const text = `
        🚨 EMERGENCY SOS ALERT 🚨
        
        Organization: ${org?.name || "Unknown"}
        Priority: ${sos.priority.toUpperCase()}
        
        Reporter: ${sos.reporter_name || "Anonymous"}
        Message: ${sos.message || "No additional details"}
        
        Location: ${sos.latitude}, ${sos.longitude}
        View on map: https://www.google.com/maps?q=${sos.latitude},${sos.longitude}
        
        Time: ${new Date(sos.created_at).toLocaleString()}
        Request ID: #${sos.id}
        
        ${member.role === "admin" || member.role === "responder" ? "ACTION REQUIRED: Coordinate response immediately" : "Standby for updates from response team"}
        
        Log in to AERA dashboard to manage this request.
      `;

      const emailPromise = sendEmail({
        to: member.email,
        subject: `🚨 EMERGENCY SOS - ${sos.reporter_name || "Anonymous"} - ${org?.name || "Unknown Org"}`,
        html,
        text,
      }).catch((err) => {
        console.error(`Failed to send email to ${member.email}:`, err);
        return null;
      });

      emailPromises.push(emailPromise);
    }

    // Wait for all notifications to complete
    const results = await Promise.allSettled(emailPromises);
    const successCount = results.filter((r) => r.status === "fulfilled").length;

    return Response.json({
      success: true,
      emailsSent: successCount,
      totalMembers: members.length,
    });
  } catch (error) {
    console.error("Error sending SOS alerts:", error);
    return Response.json({ error: "Failed to send alerts" }, { status: 500 });
  }
}
