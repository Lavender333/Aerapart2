import sql from "../../utils/sql";

export async function GET() {
  try {
    // Check for admin user
    const users = await sql`
      SELECT id, email, system_role, name
      FROM auth_users
      WHERE email = 'aerapp369@gmail.com'
    `;

    if (users.length === 0) {
      return Response.json({
        status: "NOT_FOUND",
        message: "No user with email aerapp369@gmail.com found",
      });
    }

    const user = users[0];

    // Check for credentials
    const accounts = await sql`
      SELECT id, type, provider, password IS NOT NULL as has_password
      FROM auth_accounts
      WHERE "userId" = ${user.id}
    `;

    return Response.json({
      status: "FOUND",
      user: {
        id: user.id,
        email: user.email,
        system_role: user.system_role,
        name: user.name,
      },
      accounts: accounts,
      message:
        user.system_role === "system_admin"
          ? "✅ Admin account exists and has system_admin role"
          : "⚠️ User exists but is NOT system_admin",
    });
  } catch (error) {
    console.error("Debug check error:", error);
    return Response.json({
      status: "ERROR",
      error: error.message,
    });
  }
}
