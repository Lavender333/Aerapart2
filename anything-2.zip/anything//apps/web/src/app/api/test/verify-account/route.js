import sql from "@/app/api/utils/sql";
import { getToken } from "@auth/core/jwt";

// Get user from JWT token
async function getCurrentUser(request) {
  const jwt = await getToken({
    req: request,
    secret: process.env.AUTH_SECRET,
    secureCookie: process.env.AUTH_URL?.startsWith("https"),
  });

  if (!jwt) {
    return null;
  }

  const users = await sql`
    SELECT id, email, name, system_role
    FROM auth_users
    WHERE id = ${parseInt(jwt.sub)}
  `;

  return users[0] || null;
}

export async function GET(request) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return Response.json({
        authenticated: false,
        message: "No user session found",
      });
    }

    // Check if user has account in auth_accounts
    const accounts = await sql`
      SELECT id, type, provider
      FROM auth_accounts
      WHERE "userId" = ${user.id}
    `;

    // Check if user has household
    const households = await sql`
      SELECT id, name, address
      FROM households
      WHERE user_id = ${user.id}
    `;

    // Check if user has organization membership
    const orgs = await sql`
      SELECT uo.id, uo.role, o.name as org_name
      FROM user_organizations uo
      JOIN organizations o ON uo.org_id = o.id
      WHERE uo.user_id = ${user.id.toString()}
    `;

    return Response.json({
      authenticated: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        system_role: user.system_role,
      },
      accounts: accounts,
      households: households,
      organizations: orgs,
      summary: {
        hasAccount: accounts.length > 0,
        hasHousehold: households.length > 0,
        hasOrganization: orgs.length > 0,
      },
    });
  } catch (error) {
    console.error("Error verifying account:", error);
    return Response.json(
      {
        error: "Failed to verify account",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
