import sql from "@/app/api/utils/sql";
import { getToken } from "@auth/core/jwt";

// Get user from JWT token
async function getCurrentUser(request) {
  const jwt = await getToken({
    req: request,
    secret: process.env.AUTH_SECRET,
    secureCookie: process.env.AUTH_URL?.startsWith("https"),
  });

  if (!jwt) {
    return null;
  }

  const users = await sql`
    SELECT id, email, name, system_role
    FROM auth_users
    WHERE id = ${parseInt(jwt.sub)}
  `;

  return users[0] || null;
}

export async function POST(request) {
  try {
    console.log("🔄 Starting household creation...");

    const user = await getCurrentUser(request);
    if (!user) {
      console.error("❌ No user found in session");
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    console.log("✅ User authenticated:", { id: user.id, email: user.email });

    const body = await request.json();
    const { householdName, address, primaryPhone, members, orgId } = body;

    console.log("📝 Received household data:", {
      householdName,
      address,
      memberCount: members?.length,
    });

    // Validate input
    if (!householdName || !address) {
      console.error("❌ Missing required fields");
      return Response.json(
        { error: "Household name and address are required" },
        { status: 400 },
      );
    }

    // Create household
    console.log("🔄 Inserting household into database...");
    const householdResult = await sql`
      INSERT INTO households (org_id, user_id, name, address)
      VALUES (${orgId || null}, ${user.id}, ${householdName}, ${address})
      RETURNING id
    `;

    const householdId = householdResult[0].id;
    console.log("✅ Household created with ID:", householdId);

    // Insert household members
    if (members && members.length > 0) {
      console.log(`🔄 Inserting ${members.length} household members...`);

      const memberInserts = members.map((member) => {
        console.log("  - Adding member:", member.name);
        return sql`
          INSERT INTO members (
            household_id,
            name,
            age,
            member_type,
            medical_conditions,
            phone,
            email,
            notes,
            contact_info
          ) VALUES (
            ${householdId},
            ${member.name},
            ${member.age || null},
            ${member.memberType || "adult"},
            ${member.medicalConditions || null},
            ${member.phone || null},
            ${member.email || null},
            ${member.notes || null},
            ${
              member.phone || member.email
                ? JSON.stringify({ phone: member.phone, email: member.email })
                : null
            }
          )
        `;
      });

      await sql.transaction(memberInserts);
      console.log("✅ All members saved successfully");
    } else {
      console.log("ℹ️  No members to add");
    }

    console.log("✅ Household creation complete!");
    return Response.json({
      success: true,
      householdId,
      message: "Household information saved successfully",
    });
  } catch (error) {
    console.error("❌ Error saving household:", error);
    console.error("Error details:", error.message);
    console.error("Stack trace:", error.stack);
    return Response.json(
      { error: "Failed to save household information", details: error.message },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const user = await getCurrentUser(request);
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get household for this user
    const householdResult = await sql`
      SELECT id, name, address, org_id, created_at
      FROM households
      WHERE user_id = ${user.id}
      LIMIT 1
    `;

    if (householdResult.length === 0) {
      return Response.json({ household: null, members: [] });
    }

    const household = householdResult[0];

    // Get all members for this household
    const members = await sql`
      SELECT 
        id,
        name,
        age,
        member_type,
        medical_conditions,
        phone,
        email,
        notes,
        status,
        last_seen
      FROM members
      WHERE household_id = ${household.id}
      ORDER BY created_at ASC
    `;

    return Response.json({
      household,
      members,
    });
  } catch (error) {
    console.error("Error fetching household:", error);
    return Response.json(
      { error: "Failed to fetch household information" },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const user = await getCurrentUser(request);
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { orgId } = body;

    console.log(
      "🔄 Updating household org_id for user:",
      user.id,
      "to org:",
      orgId,
    );

    // Update the user's household with the org_id
    const result = await sql`
      UPDATE households
      SET org_id = ${orgId}
      WHERE user_id = ${user.id}
      RETURNING id
    `;

    if (result.length === 0) {
      return Response.json(
        { error: "No household found for this user" },
        { status: 404 },
      );
    }

    console.log("✅ Household updated successfully");
    return Response.json({
      success: true,
      message: "Household connected to organization",
    });
  } catch (error) {
    console.error("Error updating household:", error);
    return Response.json(
      { error: "Failed to update household" },
      { status: 500 },
    );
  }
}
