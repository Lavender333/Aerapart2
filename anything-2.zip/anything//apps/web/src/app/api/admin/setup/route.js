import sql from "../../utils/sql";
import argon2 from "argon2";

export async function POST(request) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return Response.json(
        { error: "Email and password are required" },
        { status: 400 },
      );
    }

    // Check if user already exists
    const existingUsers = await sql`
      SELECT id FROM auth_users WHERE email = ${email}
    `;

    let userId;

    if (existingUsers.length > 0) {
      // User exists, update to system admin
      userId = existingUsers[0].id;

      await sql`
        UPDATE auth_users
        SET system_role = 'system_admin'
        WHERE id = ${userId}
      `;
    } else {
      // Create new user
      const newUsers = await sql`
        INSERT INTO auth_users (email, name, system_role)
        VALUES (${email}, ${email.split("@")[0]}, 'system_admin')
        RETURNING id
      `;
      userId = newUsers[0].id;
    }

    // Hash password
    const hashedPassword = await argon2.hash(password);

    // Check if credentials account exists
    const existingAccounts = await sql`
      SELECT id FROM auth_accounts
      WHERE "userId" = ${userId} AND type = 'credentials'
    `;

    if (existingAccounts.length > 0) {
      // Update existing password
      await sql`
        UPDATE auth_accounts
        SET password = ${hashedPassword}
        WHERE "userId" = ${userId} AND type = 'credentials'
      `;
    } else {
      // Create new credentials account
      await sql`
        INSERT INTO auth_accounts ("userId", type, provider, "providerAccountId", password)
        VALUES (${userId}, 'credentials', 'credentials', ${email}, ${hashedPassword})
      `;
    }

    return Response.json({
      success: true,
      message: "Admin account created/updated successfully",
      userId,
    });
  } catch (error) {
    console.error("Admin setup error:", error);
    return Response.json(
      { error: "Failed to setup admin account" },
      { status: 500 },
    );
  }
}
