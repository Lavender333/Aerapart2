import sql from "@/app/api/utils/sql";

// Get organization members
export async function GET(request, { params }) {
  try {
    const { id } = params;

    const members = await sql`
      SELECT u.id, u.name, u.email, uo.role
      FROM auth_users u
      INNER JOIN user_organizations uo ON u.id = uo.user_id::integer
      WHERE uo.org_id = ${id}
      ORDER BY uo.role, u.name
    `;

    return Response.json(members);
  } catch (error) {
    console.error("Error fetching members:", error);
    return Response.json({ error: "Failed to fetch members" }, { status: 500 });
  }
}

// Add member to organization
export async function POST(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const { userId, role } = body;

    if (!userId || !role) {
      return Response.json(
        { error: "User ID and role are required" },
        { status: 400 },
      );
    }

    const [membership] = await sql`
      INSERT INTO user_organizations (user_id, org_id, role)
      VALUES (${userId}, ${id}, ${role})
      ON CONFLICT (user_id, org_id) DO UPDATE
      SET role = ${role}
      RETURNING *
    `;

    return Response.json(membership);
  } catch (error) {
    console.error("Error adding member:", error);
    return Response.json({ error: "Failed to add member" }, { status: 500 });
  }
}
