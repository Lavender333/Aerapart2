import { getToken } from "@auth/core/jwt";
import sql from "../../utils/sql";

export async function GET(request) {
  try {
    const jwt = await getToken({
      req: request,
      secret: process.env.AUTH_SECRET,
      secureCookie: process.env.AUTH_URL?.startsWith("https"),
    });

    if (!jwt) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify user is system admin
    const adminCheck = await sql`
      SELECT system_role
      FROM auth_users
      WHERE id = ${parseInt(jwt.sub)}
    `;

    if (
      adminCheck.length === 0 ||
      adminCheck[0].system_role !== "system_admin"
    ) {
      return Response.json(
        { error: "Access denied. System admin privileges required." },
        { status: 403 },
      );
    }

    // Get all users with their organization memberships
    const users = await sql`
      SELECT 
        u.id,
        u.name,
        u.email,
        u.system_role,
        u."emailVerified",
        COALESCE(
          json_agg(
            json_build_object(
              'org_id', uo.org_id,
              'org_name', o.name,
              'role', uo.role,
              'joined_at', uo.created_at
            )
          ) FILTER (WHERE uo.org_id IS NOT NULL),
          '[]'
        ) as organizations
      FROM auth_users u
      LEFT JOIN user_organizations uo ON u.id::text = uo.user_id
      LEFT JOIN organizations o ON uo.org_id = o.id
      GROUP BY u.id, u.name, u.email, u.system_role, u."emailVerified"
      ORDER BY u.id DESC
    `;

    return Response.json({ users });
  } catch (error) {
    console.error("Error fetching users:", error);
    return Response.json({ error: "Failed to fetch users" }, { status: 500 });
  }
}
