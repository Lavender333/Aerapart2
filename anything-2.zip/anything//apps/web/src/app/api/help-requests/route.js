import sql from "@/app/api/utils/sql";
import { getToken } from "@auth/core/jwt";

// Get user from JWT token
async function getCurrentUser(request) {
  const jwt = await getToken({
    req: request,
    secret: process.env.AUTH_SECRET,
    secureCookie: process.env.AUTH_URL?.startsWith("https"),
  });

  if (!jwt) {
    return null;
  }

  const users = await sql`
    SELECT id, email, name, system_role
    FROM auth_users
    WHERE id = ${parseInt(jwt.sub)}
  `;

  return users[0] || null;
}

// GET - List help requests (filtered by role)
export async function GET(request) {
  try {
    const user = await getCurrentUser(request);
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const orgId = searchParams.get("org_id");
    const status = searchParams.get("status");

    let helpRequests;

    // System Admin - see all requests
    if (user.system_role === "system_admin") {
      let query =
        "SELECT hr.*, u.name as user_name, u.email as user_email, o.name as org_name FROM help_requests hr LEFT JOIN auth_users u ON hr.user_id = u.id LEFT JOIN organizations o ON hr.org_id = o.id WHERE 1=1";
      const params = [];
      let paramCount = 1;

      if (orgId) {
        query += ` AND hr.org_id = $${paramCount}`;
        params.push(parseInt(orgId));
        paramCount++;
      }
      if (status) {
        query += ` AND hr.status = $${paramCount}`;
        params.push(status);
        paramCount++;
      }
      query += " ORDER BY hr.created_at DESC";

      helpRequests = await sql(query, params);
    } else {
      // Get user's organizations and roles
      const userOrgs = await sql`
        SELECT org_id, role FROM user_organizations 
        WHERE user_id = ${user.id.toString()}
      `;

      if (userOrgs.length === 0) {
        return Response.json({ requests: [] });
      }

      // Check if user is org_admin in any org
      const adminOrgs = userOrgs.filter(
        (uo) => uo.role === "org_admin" || uo.role === "admin",
      );
      const isOrgAdmin = adminOrgs.length > 0;

      if (isOrgAdmin) {
        // Org Admin - see all requests in their org(s)
        const orgIds = adminOrgs.map((uo) => uo.org_id);

        let query =
          "SELECT hr.*, u.name as user_name, u.email as user_email, o.name as org_name FROM help_requests hr LEFT JOIN auth_users u ON hr.user_id = u.id LEFT JOIN organizations o ON hr.org_id = o.id WHERE hr.org_id = ANY($1)";
        const params = [orgIds];
        let paramCount = 2;

        if (status) {
          query += ` AND hr.status = $${paramCount}`;
          params.push(status);
          paramCount++;
        }
        query += " ORDER BY hr.created_at DESC";

        helpRequests = await sql(query, params);
      } else {
        // General User - see only their own requests
        let query =
          "SELECT hr.*, o.name as org_name FROM help_requests hr LEFT JOIN organizations o ON hr.org_id = o.id WHERE hr.user_id = $1";
        const params = [user.id];
        let paramCount = 2;

        if (status) {
          query += ` AND hr.status = $${paramCount}`;
          params.push(status);
          paramCount++;
        }
        query += " ORDER BY hr.created_at DESC";

        helpRequests = await sql(query, params);
      }
    }

    return Response.json({ requests: helpRequests });
  } catch (error) {
    console.error("Error fetching help requests:", error);
    return Response.json(
      { error: "Failed to fetch help requests" },
      { status: 500 },
    );
  }
}

// POST - Create new help request (General Users)
export async function POST(request) {
  try {
    const user = await getCurrentUser(request);
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { org_id, request_type, message, priority, latitude, longitude } =
      body;

    if (!request_type) {
      return Response.json(
        { error: "request_type is required" },
        { status: 400 },
      );
    }

    // Verify user is part of the org
    if (org_id) {
      const membership = await sql`
        SELECT id FROM user_organizations 
        WHERE user_id = ${user.id.toString()} AND org_id = ${org_id}
      `;

      if (membership.length === 0) {
        return Response.json(
          { error: "User not part of this organization" },
          { status: 403 },
        );
      }
    }

    const result = await sql`
      INSERT INTO help_requests (
        org_id, user_id, request_type, message, priority, latitude, longitude
      ) VALUES (
        ${org_id}, ${user.id}, ${request_type}, ${message || null}, 
        ${priority || "medium"}, ${latitude || null}, ${longitude || null}
      )
      RETURNING *
    `;

    return Response.json({ request: result[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating help request:", error);
    return Response.json(
      { error: "Failed to create help request" },
      { status: 500 },
    );
  }
}

// PATCH - Update help request (Org Admin or System Admin)
export async function PATCH(request) {
  try {
    const user = await getCurrentUser(request);
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { id, status, priority, resolved_by, resolved_at } = body;

    if (!id) {
      return Response.json(
        { error: "Request ID is required" },
        { status: 400 },
      );
    }

    // Get the help request
    const helpRequest = await sql`
      SELECT * FROM help_requests WHERE id = ${id}
    `;

    if (helpRequest.length === 0) {
      return Response.json(
        { error: "Help request not found" },
        { status: 404 },
      );
    }

    const request_data = helpRequest[0];

    // Check permissions
    if (user.system_role !== "system_admin") {
      // Check if user is org admin of this org
      const membership = await sql`
        SELECT role FROM user_organizations 
        WHERE user_id = ${user.id.toString()} AND org_id = ${request_data.org_id}
      `;

      if (
        membership.length === 0 ||
        (membership[0].role !== "org_admin" && membership[0].role !== "admin")
      ) {
        return Response.json(
          { error: "Only Org Admins can update help requests" },
          { status: 403 },
        );
      }
    }

    // Build update query
    const updates = [];
    const values = [];
    let paramCount = 1;

    if (status !== undefined) {
      updates.push(`status = $${paramCount}`);
      values.push(status);
      paramCount++;
    }
    if (priority !== undefined) {
      updates.push(`priority = $${paramCount}`);
      values.push(priority);
      paramCount++;
    }
    if (resolved_by !== undefined) {
      updates.push(`resolved_by = $${paramCount}`);
      values.push(resolved_by);
      paramCount++;
    }
    if (resolved_at !== undefined) {
      updates.push(`resolved_at = $${paramCount}`);
      values.push(resolved_at);
      paramCount++;
    }

    if (updates.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    updates.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(id);

    const query = `
      UPDATE help_requests 
      SET ${updates.join(", ")}
      WHERE id = $${paramCount}
      RETURNING *
    `;

    const result = await sql(query, values);

    return Response.json({ request: result[0] });
  } catch (error) {
    console.error("Error updating help request:", error);
    return Response.json(
      { error: "Failed to update help request" },
      { status: 500 },
    );
  }
}
