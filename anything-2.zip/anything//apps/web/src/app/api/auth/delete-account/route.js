import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const session = await auth();

    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    // Delete user data in a transaction
    await sql.transaction([
      // Delete help requests created by user
      sql`DELETE FROM help_requests WHERE user_id = ${userId}`,

      // Delete households owned by user
      sql`DELETE FROM households WHERE user_id = ${userId}`,

      // Delete user organization memberships
      sql`DELETE FROM user_organizations WHERE user_id = ${userId}::text`,

      // Delete password reset tokens
      sql`DELETE FROM password_reset_tokens WHERE user_id = ${userId}`,

      // Delete auth sessions
      sql`DELETE FROM auth_sessions WHERE "userId" = ${userId}`,

      // Delete auth accounts
      sql`DELETE FROM auth_accounts WHERE "userId" = ${userId}`,

      // Finally, delete the user
      sql`DELETE FROM auth_users WHERE id = ${userId}`,
    ]);

    return Response.json({
      success: true,
      message: "Account successfully deleted",
    });
  } catch (error) {
    console.error("Error deleting account:", error);
    return Response.json(
      { error: "Failed to delete account" },
      { status: 500 },
    );
  }
}
