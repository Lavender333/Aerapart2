import { getToken } from "@auth/core/jwt";
import sql from "../../utils/sql";

export async function GET(request) {
  try {
    const jwt = await getToken({
      req: request,
      secret: process.env.AUTH_SECRET,
      secureCookie: process.env.AUTH_URL?.startsWith("https"),
    });

    if (!jwt) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify user is system admin
    const adminCheck = await sql`
      SELECT system_role
      FROM auth_users
      WHERE id = ${parseInt(jwt.sub)}
    `;

    if (
      adminCheck.length === 0 ||
      adminCheck[0].system_role !== "system_admin"
    ) {
      return Response.json(
        { error: "Access denied. System admin privileges required." },
        { status: 403 },
      );
    }

    // Get all organizations with creator info
    const organizations = await sql`
      SELECT 
        o.id,
        o.name,
        o.address,
        o.join_code,
        o.created_at,
        u.email as creator_email,
        u.name as creator_name,
        COUNT(DISTINCT uo.user_id) as member_count
      FROM organizations o
      LEFT JOIN auth_users u ON o.creator_user_id::integer = u.id
      LEFT JOIN user_organizations uo ON o.id = uo.org_id
      GROUP BY o.id, o.name, o.address, o.join_code, o.created_at, u.email, u.name
      ORDER BY o.created_at DESC
    `;

    return Response.json({ organizations });
  } catch (error) {
    console.error("Error fetching organizations:", error);
    return Response.json(
      { error: "Failed to fetch organizations" },
      { status: 500 },
    );
  }
}
