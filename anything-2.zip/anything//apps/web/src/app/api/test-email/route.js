import { sendEmail } from "@/app/api/utils/send-email";

export async function POST(request) {
  try {
    const { email } = await request.json();

    const testEmail = email || "antoinetteqwilliams@gmail.com";

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
              background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
              padding: 40px 20px;
              margin: 0;
            }
            .container { 
              max-width: 600px; 
              margin: 0 auto; 
              background: white; 
              border-radius: 24px; 
              overflow: hidden;
              box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            .header { 
              background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%); 
              padding: 40px 30px; 
              text-align: center;
            }
            .celebration-icon {
              width: 80px;
              height: 80px;
              background: white;
              border-radius: 50%;
              display: inline-flex;
              align-items: center;
              justify-content: center;
              font-size: 48px;
              margin-bottom: 16px;
            }
            .header h1 { 
              color: white; 
              margin: 0;
              font-size: 32px;
              font-weight: 800;
            }
            .content { 
              padding: 40px 30px; 
              color: #1F2937;
              line-height: 1.6;
            }
            .success-badge {
              background: linear-gradient(135deg, #10B981 0%, #059669 100%);
              color: white;
              padding: 12px 24px;
              border-radius: 100px;
              font-weight: 700;
              display: inline-block;
              margin: 24px 0;
              box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);
            }
            .feature-list {
              background: #F0F9FF;
              border-left: 4px solid #3B82F6;
              padding: 20px;
              border-radius: 8px;
              margin: 24px 0;
            }
            .feature-list li {
              margin: 12px 0;
              color: #1E40AF;
            }
            .footer {
              background: #F9FAFB;
              padding: 24px 30px;
              text-align: center;
              color: #6B7280;
              font-size: 12px;
              border-top: 1px solid #E5E7EB;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="celebration-icon">🎉</div>
              <h1>Email System Ready!</h1>
            </div>
            <div class="content">
              <center>
                <div class="success-badge">✅ Resend Connected Successfully</div>
              </center>

              <p style="font-size: 18px; font-weight: 600; color: #111827;">
                Congratulations! Your AERA email system is fully operational! 🚀
              </p>

              <p>Your disaster relief platform can now send:</p>

              <div class="feature-list">
                <ul style="margin: 0; padding-left: 24px;">
                  <li><strong>Password Reset Emails</strong> - Secure recovery links</li>
                  <li><strong>Welcome Emails</strong> - Onboard new users</li>
                  <li><strong>SOS Alerts</strong> - Emergency notifications to all organization members</li>
                  <li><strong>Safety Check-ins</strong> - Community status updates</li>
                  <li><strong>Inventory Alerts</strong> - Low stock warnings</li>
                </ul>
              </div>

              <p style="margin-top: 24px; color: #6B7280;">
                <strong>Next Steps:</strong><br/>
                • Test password reset flow<br/>
                • Create a test organization<br/>
                • Send a test SOS alert<br/>
                • Customize email templates (optional)
              </p>

              <p style="margin-top: 24px; background: #FEF3C7; padding: 16px; border-radius: 8px; border: 2px solid #FCD34D;">
                <strong style="color: #92400E;">📧 Sending from:</strong><br/>
                <span style="color: #92400E; font-size: 14px;">
                  Currently using: <code>onboarding@resend.dev</code><br/>
                  Want to use your own domain? Let me know!
                </span>
              </p>
            </div>
            <div class="footer">
              <p><strong>AERA - Advanced Emergency Response & Assistance</strong></p>
              <p>Powered by Resend • Test email sent on ${new Date().toLocaleString()}</p>
            </div>
          </div>
        </body>
      </html>
    `;

    const text = `
      🎉 Email System Ready!
      
      Congratulations! Your AERA email system is fully operational!
      
      Your disaster relief platform can now send:
      • Password Reset Emails - Secure recovery links
      • Welcome Emails - Onboard new users  
      • SOS Alerts - Emergency notifications
      • Safety Check-ins - Community status updates
      • Inventory Alerts - Low stock warnings
      
      Next Steps:
      • Test password reset flow
      • Create a test organization
      • Send a test SOS alert
      
      AERA - Advanced Emergency Response & Assistance
      Powered by Resend
    `;

    await sendEmail({
      to: testEmail,
      subject: "🎉 AERA Email System Test - Success!",
      html,
      text,
    });

    return Response.json({
      success: true,
      message: `Test email sent successfully to ${testEmail}!`,
      emailId: "Check your inbox",
    });
  } catch (error) {
    console.error("Test email error:", error);
    return Response.json(
      {
        success: false,
        error: error.message || "Failed to send test email",
        details:
          "Check that RESEND_API_KEY is set correctly in environment variables",
      },
      { status: 500 },
    );
  }
}
