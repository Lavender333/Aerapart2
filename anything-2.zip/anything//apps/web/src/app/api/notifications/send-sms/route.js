// SMS notifications via Twilio
// You'll need to set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER in your environment variables

export async function POST(request) {
  try {
    const body = await request.json();
    const { to, message, priority = "normal" } = body;

    if (!to || !message) {
      return Response.json(
        { error: "Phone number and message are required" },
        { status: 400 },
      );
    }

    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const fromNumber = process.env.TWILIO_PHONE_NUMBER;

    if (!accountSid || !authToken || !fromNumber) {
      console.warn("Twilio credentials not configured");
      return Response.json({
        success: false,
        error:
          "SMS service not configured. Please add TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER to environment variables.",
        message: "SMS could not be sent - service not configured",
      });
    }

    // Add priority prefix for emergency messages
    const fullMessage =
      priority === "emergency"
        ? `🚨 EMERGENCY ALERT 🚨\n\n${message}`
        : message;

    // Twilio API call
    const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
    const response = await fetch(twilioUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization:
          "Basic " +
          Buffer.from(`${accountSid}:${authToken}`).toString("base64"),
      },
      body: new URLSearchParams({
        To: to,
        From: fromNumber,
        Body: fullMessage,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Failed to send SMS");
    }

    return Response.json({
      success: true,
      messageSid: data.sid,
      status: data.status,
    });
  } catch (error) {
    console.error("Error sending SMS:", error);
    return Response.json(
      { error: error.message || "Failed to send SMS" },
      { status: 500 },
    );
  }
}
