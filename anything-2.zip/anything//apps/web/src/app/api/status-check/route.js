import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Get active status check requests for a user's organization
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const orgIdParam = url.searchParams.get("org_id");

    if (!orgIdParam) {
      return Response.json({ error: "org_id required" }, { status: 400 });
    }

    const organizationId = parseInt(orgIdParam);

    // Get active status check requests
    const requests = await sql`
      SELECT sc.*, u.name as requested_by_name
      FROM status_check_requests sc
      LEFT JOIN auth_users u ON u.id = sc.requested_by
      WHERE sc.org_id = ${organizationId} 
        AND sc.active = true
        AND (sc.expires_at IS NULL OR sc.expires_at > NOW())
      ORDER BY sc.created_at DESC
      LIMIT 1
    `;

    // Check if user has already responded
    if (requests.length > 0) {
      const responses = await sql`
        SELECT * FROM status_responses
        WHERE user_id = ${parseInt(session.user.id)}
          AND status_check_id = ${requests[0].id}
      `;

      return Response.json({
        hasActiveCheck: true,
        statusCheck: requests[0],
        hasResponded: responses.length > 0,
        response: responses[0] || null,
      });
    }

    return Response.json({ hasActiveCheck: false });
  } catch (error) {
    console.error("Error fetching status check:", error);
    return Response.json(
      { error: "Failed to fetch status check" },
      { status: 500 },
    );
  }
}

// Submit a status response
export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { status_check_id, response, message, latitude, longitude, org_id } =
      body;

    if (!status_check_id || !response || !org_id) {
      return Response.json(
        { error: "status_check_id, response, and org_id are required" },
        { status: 400 },
      );
    }

    const organizationId = parseInt(org_id);
    const userId = parseInt(session.user.id);

    // Insert status response
    const [statusResponse] = await sql`
      INSERT INTO status_responses 
        (user_id, org_id, status_check_id, response, message, latitude, longitude)
      VALUES 
        (${userId}, ${organizationId}, ${status_check_id}, ${response}, ${message || null}, ${latitude || null}, ${longitude || null})
      RETURNING *
    `;

    // If user needs help, also create a help request
    if (response === "need_help") {
      await sql`
        INSERT INTO help_requests 
          (org_id, user_id, request_type, message, status, priority, latitude, longitude, is_status_check)
        VALUES 
          (${organizationId}, ${userId}, 'emergency', ${message || "Marked as needing help during status check"}, 'pending', 'high', ${latitude || null}, ${longitude || null}, true)
      `;
    }

    return Response.json({
      success: true,
      response: statusResponse,
    });
  } catch (error) {
    console.error("Error submitting status response:", error);
    return Response.json(
      { error: "Failed to submit status response" },
      { status: 500 },
    );
  }
}

// Create a status check request (org admins only)
export async function PUT(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { org_id, message, expires_in_hours } = body;

    if (!org_id) {
      return Response.json({ error: "org_id is required" }, { status: 400 });
    }

    const organizationId = parseInt(org_id);

    // Check if user is org admin
    const membership = await sql`
      SELECT role FROM user_organizations
      WHERE user_id = ${session.user.id.toString()} AND org_id = ${organizationId}
    `;

    if (
      membership.length === 0 ||
      (membership[0].role !== "org_admin" &&
        membership[0].role !== "system_admin")
    ) {
      return Response.json(
        { error: "Only org admins can request status checks" },
        { status: 403 },
      );
    }

    // Deactivate previous status checks
    await sql`
      UPDATE status_check_requests
      SET active = false
      WHERE org_id = ${organizationId} AND active = true
    `;

    // Create new status check
    const expiresAt = expires_in_hours
      ? new Date(Date.now() + expires_in_hours * 60 * 60 * 1000)
      : null;

    const [statusCheck] = await sql`
      INSERT INTO status_check_requests 
        (org_id, requested_by, message, expires_at)
      VALUES 
        (${organizationId}, ${parseInt(session.user.id)}, ${message || "Are you safe right now?"}, ${expiresAt})
      RETURNING *
    `;

    return Response.json({ success: true, statusCheck });
  } catch (error) {
    console.error("Error creating status check:", error);
    return Response.json(
      { error: "Failed to create status check" },
      { status: 500 },
    );
  }
}
