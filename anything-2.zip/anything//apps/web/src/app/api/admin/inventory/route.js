import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();

    if (!session?.user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is system admin
    const userRole = await sql`
      SELECT system_role FROM auth_users WHERE id = ${session.user.id}
    `;

    if (!userRole[0] || userRole[0].system_role !== "system_admin") {
      return Response.json(
        { error: "Forbidden - Admin access required" },
        { status: 403 },
      );
    }

    // Fetch all inventory items with organization names
    const inventory = await sql`
      SELECT 
        i.id,
        i.item_name,
        i.category,
        i.quantity,
        i.capacity,
        i.unit,
        i.updated_at,
        o.name as org_name,
        o.id as org_id
      FROM inventory i
      LEFT JOIN organizations o ON i.org_id = o.id
      ORDER BY o.name, i.item_name
    `;

    return Response.json({ inventory });
  } catch (error) {
    console.error("Error fetching inventory:", error);
    return Response.json(
      { error: "Failed to fetch inventory data" },
      { status: 500 },
    );
  }
}
