import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const orgId = searchParams.get("orgId") || 1;

    const rows = await sql`
      SELECT * FROM sos_requests 
      WHERE org_id = ${orgId} 
      ORDER BY created_at DESC
    `;

    return Response.json(rows);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to fetch SOS requests" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { org_id, reporter_name, latitude, longitude, message, priority } =
      body;

    const [newRequest] = await sql`
      INSERT INTO sos_requests (org_id, reporter_name, latitude, longitude, message, priority)
      VALUES (${org_id}, ${reporter_name}, ${latitude}, ${longitude}, ${message}, ${priority})
      RETURNING *
    `;

    // Send emergency notifications in background (don't block the response)
    if (org_id && newRequest.id) {
      const appUrl = process.env.APP_URL || "http://localhost:3000";
      fetch(`${appUrl}/api/notifications/alert-sos`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sosId: newRequest.id,
          orgId: org_id,
        }),
      }).catch((err) => console.error("Failed to send SOS alerts:", err));
    }

    return Response.json(newRequest);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to create SOS request" },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const body = await request.json();
    const { id, status } = body;

    const [updated] = await sql`
      UPDATE sos_requests 
      SET status = ${status} 
      WHERE id = ${id} 
      RETURNING *
    `;

    return Response.json(updated);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to update SOS request" },
      { status: 500 },
    );
  }
}
