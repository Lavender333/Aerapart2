import sql from "@/app/api/utils/sql";

// Update responder live location
export async function POST(request) {
  try {
    const body = await request.json();
    const { orgId, latitude, longitude, status, name } = body;

    if (!orgId || latitude === undefined || longitude === undefined) {
      return Response.json(
        { error: "Organization ID, latitude, and longitude are required" },
        { status: 400 },
      );
    }

    const responderName = name || "Anonymous Responder";

    // Check if responder exists
    const [existingResponder] = await sql`
      SELECT * FROM responders
      WHERE org_id = ${orgId} AND name = ${responderName}
    `;

    if (existingResponder) {
      // Update existing responder
      const [updated] = await sql`
        UPDATE responders
        SET latitude = ${latitude}, 
            longitude = ${longitude},
            status = ${status || existingResponder.status},
            last_active = CURRENT_TIMESTAMP
        WHERE id = ${existingResponder.id}
        RETURNING *
      `;
      return Response.json(updated);
    } else {
      // Create new responder
      const [newResponder] = await sql`
        INSERT INTO responders (org_id, name, latitude, longitude, status, last_active)
        VALUES (${orgId}, ${responderName}, ${latitude}, ${longitude}, ${status || "available"}, CURRENT_TIMESTAMP)
        RETURNING *
      `;
      return Response.json(newResponder);
    }
  } catch (error) {
    console.error("Error updating live location:", error);
    return Response.json(
      { error: "Failed to update location" },
      { status: 500 },
    );
  }
}

// Get all live responder locations for an organization
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const orgId = searchParams.get("orgId");

    if (!orgId) {
      return Response.json(
        { error: "Organization ID is required" },
        { status: 400 },
      );
    }

    // Get all active responders (active in last 5 minutes)
    const responders = await sql`
      SELECT * FROM responders
      WHERE org_id = ${orgId}
        AND last_active > NOW() - INTERVAL '5 minutes'
      ORDER BY last_active DESC
    `;

    return Response.json(responders);
  } catch (error) {
    console.error("Error fetching live locations:", error);
    return Response.json(
      { error: "Failed to fetch locations" },
      { status: 500 },
    );
  }
}
