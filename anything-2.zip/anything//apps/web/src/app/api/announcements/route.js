import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Get announcements for an organization
export async function GET(request) {
  try {
    const url = new URL(request.url);
    const orgId = url.searchParams.get("org_id");

    if (!orgId) {
      return Response.json({ error: "org_id required" }, { status: 400 });
    }

    const announcements = await sql`
      SELECT a.*, u.name as created_by_name
      FROM alerts a
      LEFT JOIN auth_users u ON u.id = a.created_by
      WHERE a.org_id = ${orgId}
      ORDER BY a.created_at DESC
      LIMIT 10
    `;

    return Response.json(announcements);
  } catch (error) {
    console.error("Error fetching announcements:", error);
    return Response.json(
      { error: "Failed to fetch announcements" },
      { status: 500 },
    );
  }
}
