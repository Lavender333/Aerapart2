import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Create a new organization
export async function POST(request) {
  try {
    const session = await auth();

    if (!session || !session.user) {
      return Response.json(
        { error: "You must be signed in to create an organization" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { name, address, latitude, longitude, userId } = body;

    if (!name) {
      return Response.json(
        { error: "Organization name is required" },
        { status: 400 },
      );
    }

    // Use userId from body (already passed from frontend)
    const creatorUserId = userId || session.user.id;

    // Check if user has general_user role in any organization
    const userOrgs = await sql`
      SELECT role FROM user_organizations
      WHERE user_id = ${creatorUserId.toString()}
    `;

    // If user has general_user role, they cannot create organizations
    const hasGeneralUserRole = userOrgs.some(
      (org) => org.role === "general_user",
    );
    if (hasGeneralUserRole) {
      return Response.json(
        { error: "General users are not allowed to create organizations" },
        { status: 403 },
      );
    }

    // Generate unique 6-character join code
    const generateJoinCode = () => {
      const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // Exclude confusing chars
      let code = "";
      for (let i = 0; i < 6; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return code;
    };

    let joinCode = generateJoinCode();

    // Ensure uniqueness
    let [existing] =
      await sql`SELECT id FROM organizations WHERE join_code = ${joinCode}`;
    while (existing) {
      joinCode = generateJoinCode();
      [existing] =
        await sql`SELECT id FROM organizations WHERE join_code = ${joinCode}`;
    }

    // Create organization with join code
    const [org] = await sql`
      INSERT INTO organizations (name, address, latitude, longitude, creator_user_id, join_code)
      VALUES (${name}, ${address || null}, ${latitude || null}, ${longitude || null}, ${creatorUserId || null}, ${joinCode})
      RETURNING *
    `;

    // Add creator as org_admin if userId available
    if (creatorUserId) {
      await sql`
        INSERT INTO user_organizations (user_id, org_id, role)
        VALUES (${creatorUserId}::text, ${org.id}, 'org_admin')
      `;
    }

    return Response.json(org);
  } catch (error) {
    console.error("Error creating organization:", error);
    return Response.json(
      { error: "Failed to create organization" },
      { status: 500 },
    );
  }
}

// Get all organizations
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (userId) {
      // Get user's organizations
      const organizations = await sql`
        SELECT o.*, uo.role
        FROM organizations o
        INNER JOIN user_organizations uo ON o.id = uo.org_id
        WHERE uo.user_id = ${userId}
        ORDER BY o.created_at DESC
      `;
      return Response.json(organizations);
    } else {
      // Get all organizations
      const organizations = await sql`
        SELECT * FROM organizations
        ORDER BY created_at DESC
      `;
      return Response.json(organizations);
    }
  } catch (error) {
    console.error("Error fetching organizations:", error);
    return Response.json(
      { error: "Failed to fetch organizations" },
      { status: 500 },
    );
  }
}
