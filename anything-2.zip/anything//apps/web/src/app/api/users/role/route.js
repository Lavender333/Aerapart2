import sql from "@/app/api/utils/sql";
import { getToken } from "@auth/core/jwt";

// Get current user's role information
export async function GET(request) {
  try {
    const jwt = await getToken({
      req: request,
      secret: process.env.AUTH_SECRET,
      secureCookie: process.env.AUTH_URL?.startsWith("https"),
    });

    if (!jwt) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const users = await sql`
      SELECT id, email, name, system_role
      FROM auth_users
      WHERE id = ${parseInt(jwt.sub)}
    `;

    if (users.length === 0) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    const user = users[0];

    // Get user's organizations and roles
    const userOrgs = await sql`
      SELECT uo.org_id, uo.role, o.name as org_name, o.address, o.latitude, o.longitude
      FROM user_organizations uo
      JOIN organizations o ON uo.org_id = o.id
      WHERE uo.user_id = ${user.id.toString()}
    `;

    return Response.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        system_role: user.system_role,
      },
      organizations: userOrgs.map((org) => ({
        org_id: org.org_id,
        org_name: org.org_name,
        role: org.role,
        address: org.address,
        latitude: org.latitude,
        longitude: org.longitude,
      })),
    });
  } catch (error) {
    console.error("Error fetching user role:", error);
    return Response.json(
      { error: "Failed to fetch user role" },
      { status: 500 },
    );
  }
}

// Update user's system role (System Admin only)
export async function PATCH(request) {
  try {
    const jwt = await getToken({
      req: request,
      secret: process.env.AUTH_SECRET,
      secureCookie: process.env.AUTH_URL?.startsWith("https"),
    });

    if (!jwt) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const users = await sql`
      SELECT id, system_role
      FROM auth_users
      WHERE id = ${parseInt(jwt.sub)}
    `;

    if (users.length === 0 || users[0].system_role !== "system_admin") {
      return Response.json(
        { error: "Only System Admins can update user roles" },
        { status: 403 },
      );
    }

    const body = await request.json();
    const { user_id, system_role, org_id, org_role } = body;

    if (!user_id) {
      return Response.json({ error: "user_id is required" }, { status: 400 });
    }

    // Update system role if provided
    if (system_role) {
      await sql`
        UPDATE auth_users 
        SET system_role = ${system_role}
        WHERE id = ${user_id}
      `;
    }

    // Update org role if provided
    if (org_id && org_role) {
      await sql`
        UPDATE user_organizations 
        SET role = ${org_role}
        WHERE user_id = ${user_id.toString()} AND org_id = ${org_id}
      `;
    }

    return Response.json({
      success: true,
      message: "Role updated successfully",
    });
  } catch (error) {
    console.error("Error updating user role:", error);
    return Response.json(
      { error: "Failed to update user role" },
      { status: 500 },
    );
  }
}
