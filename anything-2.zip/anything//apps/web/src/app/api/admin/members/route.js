import { getToken } from "@auth/core/jwt";
import sql from "../../utils/sql";

export async function GET(request) {
  try {
    const jwt = await getToken({
      req: request,
      secret: process.env.AUTH_SECRET,
      secureCookie: process.env.AUTH_URL?.startsWith("https"),
    });

    if (!jwt) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify user is system admin
    const adminCheck = await sql`
      SELECT system_role
      FROM auth_users
      WHERE id = ${parseInt(jwt.sub)}
    `;

    if (
      adminCheck.length === 0 ||
      adminCheck[0].system_role !== "system_admin"
    ) {
      return Response.json(
        { error: "Access denied. System admin privileges required." },
        { status: 403 },
      );
    }

    // Get all members with their household and organization info
    const members = await sql`
      SELECT 
        m.id,
        m.name,
        m.status,
        m.member_type,
        m.age,
        m.phone,
        m.email,
        m.created_at,
        h.name as household_name,
        h.address as household_address,
        o.id as org_id,
        o.name as organization_name,
        uo.role as org_role
      FROM members m
      LEFT JOIN households h ON m.household_id = h.id
      LEFT JOIN user_organizations uo ON h.user_id = uo.user_id::integer
      LEFT JOIN organizations o ON uo.org_id = o.id
      ORDER BY m.created_at DESC
    `;

    return Response.json({ members });
  } catch (error) {
    console.error("Error fetching members:", error);
    return Response.json({ error: "Failed to fetch members" }, { status: 500 });
  }
}
