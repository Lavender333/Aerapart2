import { sendEmail } from "@/app/api/utils/send-email";

export async function POST(request) {
  try {
    const body = await request.json();
    const { email, name, organizationName } = body;

    if (!email) {
      return Response.json({ error: "Email is required" }, { status: 400 });
    }

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              padding: 40px 20px;
              margin: 0;
            }
            .container { 
              max-width: 600px; 
              margin: 0 auto; 
              background: white; 
              border-radius: 24px; 
              overflow: hidden;
              box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            .header { 
              background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%); 
              padding: 40px 30px; 
              text-align: center;
            }
            .logo {
              width: 60px;
              height: 60px;
              background: white;
              border-radius: 16px;
              display: inline-flex;
              align-items: center;
              justify-content: center;
              font-size: 32px;
              font-weight: 900;
              color: #4F46E5;
              margin-bottom: 16px;
            }
            .header h1 { 
              color: white; 
              margin: 0;
              font-size: 28px;
              font-weight: 800;
            }
            .content { 
              padding: 40px 30px; 
              color: #1F2937;
              line-height: 1.6;
            }
            .welcome { 
              font-size: 24px; 
              font-weight: 700; 
              color: #111827;
              margin-bottom: 16px;
            }
            .org-badge {
              display: inline-block;
              background: linear-gradient(135deg, #10B981 0%, #059669 100%);
              color: white;
              padding: 8px 16px;
              border-radius: 12px;
              font-weight: 700;
              font-size: 14px;
              margin: 20px 0;
            }
            .feature-list {
              background: #F9FAFB;
              border-radius: 16px;
              padding: 24px;
              margin: 24px 0;
            }
            .feature {
              display: flex;
              align-items: start;
              margin-bottom: 16px;
            }
            .feature:last-child {
              margin-bottom: 0;
            }
            .feature-icon {
              width: 32px;
              height: 32px;
              background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%);
              border-radius: 8px;
              display: flex;
              align-items: center;
              justify-content: center;
              color: white;
              font-weight: 900;
              margin-right: 12px;
              flex-shrink: 0;
            }
            .cta-button {
              display: inline-block;
              background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%);
              color: white;
              padding: 16px 32px;
              border-radius: 12px;
              text-decoration: none;
              font-weight: 700;
              margin: 24px 0;
              box-shadow: 0 10px 30px rgba(79, 70, 229, 0.3);
            }
            .footer {
              background: #F9FAFB;
              padding: 24px 30px;
              text-align: center;
              color: #6B7280;
              font-size: 12px;
              border-top: 1px solid #E5E7EB;
            }
            .support-badge {
              background: #FEF3C7;
              border: 2px solid #FCD34D;
              border-radius: 12px;
              padding: 16px;
              margin: 24px 0;
              text-align: center;
            }
            .support-badge strong {
              color: #92400E;
              font-size: 14px;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">A</div>
              <h1>Welcome to AERA</h1>
            </div>
            <div class="content">
              <div class="welcome">Hi ${name || "there"}! 👋</div>
              <p>Your account has been successfully created. You're now part of a coordinated disaster relief network designed to keep communities safe during emergencies.</p>
              
              ${organizationName ? `<div class="org-badge">🏢 ${organizationName}</div>` : ""}
              
              <div class="feature-list">
                <div class="feature">
                  <div class="feature-icon">🆘</div>
                  <div>
                    <strong>Emergency SOS</strong><br/>
                    Send instant help requests with your exact location to nearby responders
                  </div>
                </div>
                <div class="feature">
                  <div class="feature-icon">📊</div>
                  <div>
                    <strong>Safety Tracking</strong><br/>
                    Monitor household members and coordinate wellness checks
                  </div>
                </div>
                <div class="feature">
                  <div class="feature-icon">📦</div>
                  <div>
                    <strong>Resource Management</strong><br/>
                    Track supplies, food, water, and medical inventory in real-time
                  </div>
                </div>
                <div class="feature">
                  <div class="feature-icon">🔔</div>
                  <div>
                    <strong>Alert System</strong><br/>
                    Receive and broadcast critical updates to your response team
                  </div>
                </div>
              </div>

              <div class="support-badge">
                <strong>⚡ Emergency Helpline: Available 24/7</strong><br/>
                <span style="color: #92400E; font-size: 12px;">Response teams are standing by</span>
              </div>

              <a href="${process.env.APP_URL}" class="cta-button">Access Your Dashboard →</a>

              <p style="margin-top: 32px; color: #6B7280; font-size: 14px;">
                <strong>Quick Start:</strong><br/>
                1. Download the mobile app for emergency SOS<br/>
                2. Set up your household members<br/>
                3. Review your organization's current status<br/>
                4. Test the SOS feature (we'll mark it as a drill)
              </p>
            </div>
            <div class="footer">
              <p>AERA - Advanced Emergency Response & Assistance</p>
              <p>Stay safe, stay connected, stay informed.</p>
            </div>
          </div>
        </body>
      </html>
    `;

    const text = `
      Welcome to AERA - Advanced Emergency Response & Assistance
      
      Hi ${name || "there"}!
      
      Your account has been successfully created. You're now part of a coordinated disaster relief network.
      
      ${organizationName ? `Organization: ${organizationName}\n` : ""}
      
      What you can do:
      - Send emergency SOS with your location
      - Track household safety status
      - Manage relief supplies and resources
      - Broadcast and receive critical alerts
      
      Get started: ${process.env.APP_URL}
      
      Emergency Helpline: Available 24/7
      
      Stay safe, stay connected.
    `;

    try {
      await sendEmail({
        to: email,
        subject: `Welcome to AERA Emergency Response ${organizationName ? `- ${organizationName}` : ""}`,
        html,
        text,
      });

      return Response.json({ success: true, message: "Welcome email sent" });
    } catch (emailError) {
      console.error("Email send error:", emailError);
      // Don't fail the request if email fails
      return Response.json({
        success: false,
        error:
          "Email service not configured. Please add your RESEND_API_KEY to environment variables.",
        message: "Account created but email could not be sent",
      });
    }
  } catch (error) {
    console.error("Error sending welcome email:", error);
    return Response.json(
      { error: "Failed to send welcome email" },
      { status: 500 },
    );
  }
}
