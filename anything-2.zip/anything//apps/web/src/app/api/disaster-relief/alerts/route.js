import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const orgId = searchParams.get("orgId");
    const session = await auth();

    // Check if user is system admin
    let isAdmin = false;
    if (session?.user?.id) {
      const userRole = await sql`
        SELECT system_role FROM auth_users WHERE id = ${session.user.id}
      `;
      isAdmin = userRole[0]?.system_role === "system_admin";
    }

    let rows;
    if (isAdmin && !orgId) {
      // Admin can fetch all alerts with additional info
      rows = await sql`
        SELECT 
          a.*,
          u.name as created_by_name,
          u.email as created_by_email,
          o.name as org_name
        FROM alerts a
        LEFT JOIN auth_users u ON a.created_by = u.id
        LEFT JOIN organizations o ON a.org_id = o.id
        ORDER BY a.created_at DESC
      `;
    } else if (orgId) {
      // Fetch alerts for specific organization
      rows = await sql`
        SELECT 
          a.*,
          u.name as created_by_name
        FROM alerts a
        LEFT JOIN auth_users u ON a.created_by = u.id
        WHERE a.org_id = ${orgId}
        ORDER BY a.created_at DESC
      `;
    } else {
      return Response.json(
        { error: "orgId required for non-admin users" },
        { status: 400 },
      );
    }

    return Response.json({ alerts: rows });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to fetch alerts" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { org_id, title, message } = body;

    if (!title || !message) {
      return Response.json(
        { error: "title and message are required" },
        { status: 400 },
      );
    }

    // If org_id is not provided, it's a broadcast to all organizations (admin only)
    if (!org_id) {
      const userRole = await sql`
        SELECT system_role FROM auth_users WHERE id = ${session.user.id}
      `;

      if (userRole[0]?.system_role !== "system_admin") {
        return Response.json(
          { error: "Only system admins can broadcast to all organizations" },
          { status: 403 },
        );
      }
    }

    const [newAlert] = await sql`
      INSERT INTO alerts (org_id, title, message, created_by)
      VALUES (${org_id || null}, ${title}, ${message}, ${parseInt(session.user.id)})
      RETURNING *
    `;

    return Response.json(newAlert);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to create alert" }, { status: 500 });
  }
}
