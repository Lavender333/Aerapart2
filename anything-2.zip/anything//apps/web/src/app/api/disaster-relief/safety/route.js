import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const orgId = searchParams.get("orgId") || 1;

    const rows = await sql`
      SELECT 
        h.id as household_id,
        h.name as household_name,
        h.address,
        m.id as member_id,
        m.name as member_name,
        m.status,
        m.last_seen
      FROM households h
      LEFT JOIN members m ON h.id = m.household_id
      WHERE h.org_id = ${orgId}
      ORDER BY h.name, m.name
    `;

    // Group members by household
    const households = rows.reduce((acc, row) => {
      if (!acc[row.household_id]) {
        acc[row.household_id] = {
          id: row.household_id,
          name: row.household_name,
          address: row.address,
          members: [],
        };
      }
      if (row.member_id) {
        acc[row.household_id].members.push({
          id: row.member_id,
          name: row.member_name,
          status: row.status,
          last_seen: row.last_seen,
        });
      }
      return acc;
    }, {});

    return Response.json(Object.values(households));
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to fetch safety status" },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const body = await request.json();
    const { id, status } = body;

    const [updated] = await sql`
      UPDATE members 
      SET status = ${status}, last_seen = CURRENT_TIMESTAMP
      WHERE id = ${id} 
      RETURNING *
    `;

    return Response.json(updated);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to update member status" },
      { status: 500 },
    );
  }
}
