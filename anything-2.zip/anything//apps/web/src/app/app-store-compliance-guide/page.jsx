export default function AppStoreComplianceGuidePage() {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">
          📱 App Store Compliance Implementation Guide
        </h1>
        <p className="text-sm text-gray-600 mb-8">
          Complete checklist for AERA app submission
        </p>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-8">
          <h2 className="text-lg font-semibold text-green-800 mb-2">
            ✅ Completed in Anything
          </h2>
          <ul className="list-disc pl-6 space-y-1 text-green-700">
            <li>Privacy Policy page created (web + mobile)</li>
            <li>Location consent modal implemented</li>
            <li>Settings page with privacy policy link</li>
            <li>Sign in with Apple enabled</li>
          </ul>
        </div>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">
            📋 Manual Steps Required
          </h2>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
            <h3 className="text-xl font-semibold mb-3">
              Step 1: Update Info.plist (iOS Configuration)
            </h3>
            <p className="mb-4 text-gray-700">
              Add these location permission strings to your Info.plist file:
            </p>

            <div className="bg-gray-900 text-white p-4 rounded-lg overflow-x-auto mb-4">
              <pre className="text-sm">{`<key>NSLocationWhenInUseUsageDescription</key>
<string>Your location is used to share your real-time position with your selected response team during active safety monitoring.</string>

<key>NSLocationAlwaysAndWhenInUseUsageDescription</key>
<string>Your location is used continuously to enable emergency assistance and real-time safety response when you activate monitoring.</string>`}</pre>
            </div>

            <p className="text-sm text-gray-600 italic">
              Location: In your Xcode project, find Info.plist and add these
              entries
            </p>
          </div>

          <div className="bg-purple-50 border border-purple-200 rounded-lg p-6 mb-6">
            <h3 className="text-xl font-semibold mb-3">
              Step 2: Enable Sign in with Apple (Apple Developer)
            </h3>
            <ol className="list-decimal pl-6 space-y-2">
              <li>
                Go to{" "}
                <a
                  href="https://developer.apple.com/account/resources/identifiers/list"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 underline"
                >
                  Apple Developer → Certificates, Identifiers & Profiles
                </a>
              </li>
              <li>Select your App ID</li>
              <li>Check "Sign in with Apple" capability</li>
              <li>Save and regenerate provisioning profiles</li>
              <li>Rebuild your app with updated profiles</li>
            </ol>
            <p className="mt-4 text-sm text-gray-600 italic">
              Sign in with Apple is now enabled in your Anything project
              settings and will appear on signup/signin pages
            </p>
          </div>

          <div className="bg-orange-50 border border-orange-200 rounded-lg p-6 mb-6">
            <h3 className="text-xl font-semibold mb-3">
              Step 3: App Store Connect - Add Privacy Policy URL
            </h3>
            <ol className="list-decimal pl-6 space-y-2">
              <li>
                Go to{" "}
                <a
                  href="https://appstoreconnect.apple.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 underline"
                >
                  App Store Connect
                </a>
              </li>
              <li>Select your app → App Information</li>
              <li>Under "Privacy Policy URL" paste:</li>
            </ol>
            <div className="bg-gray-900 text-white p-4 rounded-lg overflow-x-auto mt-3 mb-3">
              <code className="text-sm">
                {typeof window !== "undefined"
                  ? window.location.origin
                  : "https://your-domain.com"}
                /privacy-policy
              </code>
            </div>
            <p className="text-sm text-gray-600 italic">
              Make sure to publish your web app first so this URL is live!
            </p>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-6">
            <h3 className="text-xl font-semibold mb-3">
              Step 4: App Review Notes
            </h3>
            <p className="mb-3">
              In App Store Connect → App Review Information → Notes, add:
            </p>
            <div className="bg-gray-900 text-white p-4 rounded-lg overflow-x-auto">
              <pre className="text-sm">{`COMPLIANCE UPDATE - Feb 2026

Privacy Policy:
✅ Available in-app: Settings → Privacy Policy
✅ Public URL: [your-domain]/privacy-policy
✅ Covers all data collection, usage, and sharing

Location Services:
✅ Explicit consent modal before activation
✅ Clear purpose strings in Info.plist
✅ User can disable at any time
✅ Privacy policy explicitly describes location sharing with response team

Sign in with Apple:
✅ Implemented and functional
✅ Same prominence as email login
✅ Follows Apple design guidelines

All compliance issues from previous review have been addressed.`}</pre>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">
            🧪 Testing Before Submission
          </h2>
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
            <h3 className="font-semibold mb-3">Verify these in TestFlight:</h3>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-green-600">☐</span>
                <span>Privacy Policy is accessible from Settings</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">☐</span>
                <span>
                  Location consent modal appears before sharing location
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">☐</span>
                <span>
                  Location permission prompts show custom messages from
                  Info.plist
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">☐</span>
                <span>Sign in with Apple button appears on login screen</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">☐</span>
                <span>Sign in with Apple successfully creates account</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">☐</span>
                <span>User can stop location sharing from app</span>
              </li>
            </ul>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">📱 Quick Access Links</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <a
              href="/privacy-policy"
              className="block p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
            >
              <h3 className="font-semibold text-blue-900">
                Privacy Policy (Web)
              </h3>
              <p className="text-sm text-blue-700 mt-1">
                View the public privacy policy
              </p>
            </a>
            <a
              href="/settings"
              className="block p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
            >
              <h3 className="font-semibold text-blue-900">
                Settings Page (Mobile Preview)
              </h3>
              <p className="text-sm text-blue-700 mt-1">
                Test the in-app settings
              </p>
            </a>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">🎯 Compliance Summary</h2>
          <div className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg p-6">
            <h3 className="font-semibold mb-3 text-lg">Guideline Coverage:</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span>
                  <strong>5.1.1(i)</strong> Privacy Policy - In-app + public URL
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span>
                  <strong>5.1.5</strong> Location Services - Clear purpose
                  strings
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span>
                  <strong>5.1.1(ii)</strong> Data Use - Explicit in privacy
                  policy
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span>
                  <strong>5.1.2(i)</strong> User Consent - Modal before location
                  sharing
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span>
                  <strong>4.8</strong> Sign in with Apple - Enabled and
                  functional
                </span>
              </div>
            </div>
          </div>
        </section>

        <div className="bg-gray-100 border-l-4 border-gray-600 p-6 rounded-lg">
          <h3 className="font-semibold mb-2">💡 Final Tip</h3>
          <p className="text-gray-700">
            Apple reviewers look for clarity and transparency. All compliance
            elements are now in place - the manual steps above just connect them
            to your Apple Developer account and App Store listing. This should
            pass review!
          </p>
        </div>
      </div>
    </div>
  );
}
