"use client";

import { useState } from "react";
import { Send, CheckCircle, XCircle, Loader2 } from "lucide-react";

export default function TestEmailPage() {
  const [status, setStatus] = useState("idle"); // idle, loading, success, error
  const [message, setMessage] = useState("");
  const [email, setEmail] = useState("antoinetteqwilliams@gmail.com");

  const sendTestEmail = async () => {
    setStatus("loading");
    setMessage("");

    try {
      const response = await fetch("/api/test-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setStatus("success");
        setMessage(`✅ Success! Check ${email} for your test email!`);
      } else {
        setStatus("error");
        setMessage(
          `❌ Error: ${data.error || "Failed to send email"}\n\n${data.details || ""}`,
        );
      }
    } catch (error) {
      setStatus("error");
      setMessage(`❌ Network error: ${error.message}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 via-blue-600 to-blue-700 p-6 flex items-center justify-center">
      <div className="max-w-2xl w-full">
        {/* Main Card */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 px-8 py-12 text-center">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Send className="w-10 h-10 text-blue-600" />
            </div>
            <h1 className="text-4xl font-extrabold text-white mb-2">
              Email System Test
            </h1>
            <p className="text-blue-100 text-lg">
              Verify your Resend integration
            </p>
          </div>

          {/* Content */}
          <div className="p-8">
            {/* Instructions */}
            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-6 mb-6">
              <h2 className="font-bold text-blue-900 mb-3 text-lg">
                📝 Quick Setup:
              </h2>
              <ol className="space-y-2 text-blue-800 text-sm">
                <li className="flex items-start">
                  <span className="font-bold mr-2">1.</span>
                  <span>
                    Add your Resend API key to environment variables:
                    <br />
                    <code className="bg-blue-100 px-2 py-1 rounded text-xs mt-1 inline-block">
                      RESEND_API_KEY = re_NHh6wm22_KnDiBbqgdK5nG7EZmQ8oXzFn
                    </code>
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="font-bold mr-2">2.</span>
                  <span>Click the button below to send a test email</span>
                </li>
                <li className="flex items-start">
                  <span className="font-bold mr-2">3.</span>
                  <span>Check your inbox for the test email!</span>
                </li>
              </ol>
            </div>

            {/* Email Input */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Test Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none text-gray-800"
                placeholder="your@email.com"
              />
            </div>

            {/* Send Button */}
            <button
              onClick={sendTestEmail}
              disabled={status === "loading"}
              className={`w-full py-4 rounded-xl font-bold text-lg transition-all shadow-lg ${
                status === "loading"
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 hover:shadow-xl transform hover:-translate-y-1"
              } text-white flex items-center justify-center gap-3`}
            >
              {status === "loading" ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  Sending Test Email...
                </>
              ) : (
                <>
                  <Send className="w-6 h-6" />
                  Send Test Email
                </>
              )}
            </button>

            {/* Status Message */}
            {status === "success" && (
              <div className="mt-6 bg-green-50 border-2 border-green-300 rounded-xl p-6 flex items-start gap-4">
                <CheckCircle className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-green-900 mb-2">
                    Email Sent Successfully! 🎉
                  </h3>
                  <p className="text-green-800 whitespace-pre-line">
                    {message}
                  </p>
                  <p className="text-green-700 text-sm mt-3">
                    <strong>Next Steps:</strong>
                    <br />• Check your spam folder if you don't see it
                    <br />• Try the password reset flow
                    <br />• Test SOS alerts in your app
                  </p>
                </div>
              </div>
            )}

            {status === "error" && (
              <div className="mt-6 bg-red-50 border-2 border-red-300 rounded-xl p-6 flex items-start gap-4">
                <XCircle className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-red-900 mb-2">
                    Failed to Send Email
                  </h3>
                  <p className="text-red-800 whitespace-pre-line text-sm">
                    {message}
                  </p>
                  <div className="mt-4 bg-red-100 p-4 rounded-lg">
                    <p className="text-red-900 font-semibold text-sm mb-2">
                      Troubleshooting:
                    </p>
                    <ul className="text-red-800 text-xs space-y-1">
                      <li>
                        ✓ Make sure RESEND_API_KEY is added to environment
                        variables
                      </li>
                      <li>✓ Verify the API key is correct (starts with re_)</li>
                      <li>
                        ✓ Check that you've saved the environment variable
                      </li>
                      <li>✓ Try restarting the dev server if needed</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="bg-gray-50 px-8 py-6 border-t border-gray-200">
            <div className="grid md:grid-cols-3 gap-4 text-center text-sm">
              <div>
                <div className="font-bold text-gray-700">Email Provider</div>
                <div className="text-gray-600">Resend</div>
              </div>
              <div>
                <div className="font-bold text-gray-700">Free Tier</div>
                <div className="text-gray-600">100 emails/day</div>
              </div>
              <div>
                <div className="font-bold text-gray-700">Status</div>
                <div
                  className={`font-semibold ${
                    status === "success"
                      ? "text-green-600"
                      : status === "error"
                        ? "text-red-600"
                        : "text-gray-600"
                  }`}
                >
                  {status === "success"
                    ? "✅ Connected"
                    : status === "error"
                      ? "❌ Error"
                      : "⏳ Not Tested"}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Info Card */}
        <div className="mt-6 bg-white/90 backdrop-blur rounded-2xl p-6 shadow-lg">
          <h3 className="font-bold text-gray-800 mb-3">
            📧 What emails can AERA send?
          </h3>
          <div className="grid md:grid-cols-2 gap-3 text-sm">
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="font-semibold text-blue-900">
                🔒 Password Reset
              </div>
              <div className="text-blue-700 text-xs">Secure recovery links</div>
            </div>
            <div className="bg-green-50 p-3 rounded-lg">
              <div className="font-semibold text-green-900">
                👋 Welcome Emails
              </div>
              <div className="text-green-700 text-xs">New user onboarding</div>
            </div>
            <div className="bg-red-50 p-3 rounded-lg">
              <div className="font-semibold text-red-900">🚨 SOS Alerts</div>
              <div className="text-red-700 text-xs">
                Emergency notifications
              </div>
            </div>
            <div className="bg-purple-50 p-3 rounded-lg">
              <div className="font-semibold text-purple-900">
                📦 Inventory Alerts
              </div>
              <div className="text-purple-700 text-xs">Low stock warnings</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
