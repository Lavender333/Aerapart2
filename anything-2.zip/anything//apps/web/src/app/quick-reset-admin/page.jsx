"use client";

import { useState } from "react";
import { Shield, CheckCircle, AlertCircle } from "lucide-react";

export default function QuickResetAdminPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const resetPassword = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess(false);

    try {
      const response = await fetch("/api/admin/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: email.trim(),
          password,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to reset admin password");
      }

      setSuccess(true);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-red-600 rounded-2xl mb-4 shadow-lg shadow-red-900/50">
            <Shield size={32} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Quick Admin Access
          </h1>
          <p className="text-slate-400">Reset or create admin credentials</p>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl shadow-2xl p-8">
          {success ? (
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-600 rounded-full mb-4">
                <CheckCircle size={32} className="text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">
                Password Set!
              </h2>
              <p className="text-slate-400 mb-6">
                Your admin password has been reset successfully.
              </p>
              <div className="bg-blue-900/30 border border-blue-700 rounded-lg p-4 mb-6 text-left">
                <p className="text-blue-200 text-sm font-semibold mb-2">
                  Next Steps:
                </p>
                <ol className="text-blue-200 text-sm space-y-1 list-decimal list-inside">
                  <li>Go to the signin page</li>
                  <li>
                    Use email:{" "}
                    <code className="bg-blue-950/50 px-2 py-0.5 rounded">
                      {email}
                    </code>
                  </li>
                  <li>Use the password you just set</li>
                  <li>You'll be redirected to /admin</li>
                </ol>
              </div>
              <a
                href="/account/signin"
                className="block w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition-colors text-center"
              >
                Go to Sign In
              </a>
            </div>
          ) : (
            <form onSubmit={resetPassword} className="space-y-6">
              {error && (
                <div className="bg-red-900/30 border border-red-700 text-red-200 px-4 py-3 rounded-lg flex items-start gap-3">
                  <AlertCircle size={20} className="flex-shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Admin Email
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 outline-none transition-all"
                  placeholder="admin@example.com"
                  autoComplete="email"
                />
                <p className="text-xs text-slate-500 mt-1">
                  Use an existing admin email or create a new one
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  New Password
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 outline-none transition-all"
                  placeholder="Enter a strong password"
                  autoComplete="new-password"
                  minLength={8}
                />
                <p className="text-xs text-slate-500 mt-1">
                  Minimum 8 characters
                </p>
              </div>

              <div className="bg-amber-900/20 border border-amber-700/50 rounded-lg p-4">
                <p className="text-amber-200 text-sm">
                  💡 This will create or update the admin account and set the
                  password
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition-colors shadow-lg shadow-red-900/30"
              >
                {loading ? "Setting Password..." : "Set Admin Password"}
              </button>
            </form>
          )}
        </div>

        {!success && (
          <div className="mt-6 bg-slate-800/30 border border-slate-700 rounded-lg p-4">
            <p className="text-slate-400 text-sm mb-2">
              <strong className="text-white">Existing Admins:</strong>
            </p>
            <ul className="text-slate-400 text-sm space-y-1">
              <li>• aerapp369@gmail.com</li>
              <li>• admin2@aera.org</li>
            </ul>
            <p className="text-slate-500 text-xs mt-3">
              You can reset the password for any of these or create a new admin
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
