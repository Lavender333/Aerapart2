"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function AdminDebug() {
  const { data: user, loading } = useUser();
  const [roleData, setRoleData] = useState(null);
  const [adminCheck, setAdminCheck] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (user) {
      fetchRole();
    }
  }, [user]);

  const fetchRole = async () => {
    try {
      const response = await fetch("/api/users/role");
      const data = await response.json();
      setRoleData(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const checkAdminAccount = async () => {
    try {
      const response = await fetch("/api/admin/debug-check");
      const data = await response.json();
      setAdminCheck(data);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div style={{ padding: "40px", fontFamily: "monospace" }}>
      <h1>Admin Debug Info</h1>

      <div style={{ marginTop: "20px" }}>
        <button
          onClick={checkAdminAccount}
          style={{
            padding: "12px 24px",
            fontSize: "16px",
            backgroundColor: "#3b82f6",
            color: "white",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
          }}
        >
          Check Admin Account in Database
        </button>
      </div>

      {adminCheck && (
        <div
          style={{
            marginTop: "20px",
            padding: "20px",
            backgroundColor: "#f0f0f0",
            borderRadius: "8px",
          }}
        >
          <h2>Admin Account Check:</h2>
          <pre>{JSON.stringify(adminCheck, null, 2)}</pre>
        </div>
      )}

      <div
        style={{
          marginTop: "20px",
          padding: "20px",
          backgroundColor: "#f0f0f0",
          borderRadius: "8px",
        }}
      >
        <h2>User Loading State:</h2>
        <pre>{loading ? "Loading..." : "Loaded"}</pre>
      </div>

      <div
        style={{
          marginTop: "20px",
          padding: "20px",
          backgroundColor: "#f0f0f0",
          borderRadius: "8px",
        }}
      >
        <h2>User Data from useUser:</h2>
        <pre>{JSON.stringify(user, null, 2)}</pre>
      </div>

      <div
        style={{
          marginTop: "20px",
          padding: "20px",
          backgroundColor: "#f0f0f0",
          borderRadius: "8px",
        }}
      >
        <h2>Role Data from /api/users/role:</h2>
        <pre>{JSON.stringify(roleData, null, 2)}</pre>
      </div>

      {error && (
        <div
          style={{
            marginTop: "20px",
            padding: "20px",
            backgroundColor: "#ffcccc",
            borderRadius: "8px",
          }}
        >
          <h2>Error:</h2>
          <pre>{error}</pre>
        </div>
      )}

      <div
        style={{
          marginTop: "20px",
          padding: "20px",
          backgroundColor: "#ffffcc",
          borderRadius: "8px",
        }}
      >
        <h2>Expected for Admin Access:</h2>
        <pre>system_role: "system_admin"</pre>
      </div>

      <div style={{ marginTop: "20px" }}>
        <a
          href="/admin"
          style={{
            padding: "10px 20px",
            backgroundColor: "#007bff",
            color: "white",
            textDecoration: "none",
            borderRadius: "8px",
          }}
        >
          Try Admin Panel
        </a>
      </div>
    </div>
  );
}
