"use client";

import { useEffect } from "react";

export default function AdminLoginRedirect() {
  useEffect(() => {
    // Redirect to the main sign-in page
    window.location.href = "/account/signin";
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
      <div className="text-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-red-600 border-t-transparent mb-4"></div>
        <p className="text-slate-300">Redirecting to sign in...</p>
        <p className="text-slate-500 text-sm mt-2">
          Admins use the same login as everyone else
        </p>
      </div>
    </div>
  );
}
