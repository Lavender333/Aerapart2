"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  Shield,
  Users,
  Building2,
  AlertTriangle,
  HelpCircle,
  Search,
  Edit,
  LogOut,
  BarChart3,
  Activity,
  UserCircle,
  UserPlus,
  Package,
  Radio,
  Database,
  PlusCircle,
  Send,
} from "lucide-react";

export default function AdminDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [users, setUsers] = useState([]);
  const [organizations, setOrganizations] = useState([]);
  const [members, setMembers] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingUser, setEditingUser] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");

  // Broadcast state
  const [showBroadcastModal, setShowBroadcastModal] = useState(false);
  const [broadcastTitle, setBroadcastTitle] = useState("");
  const [broadcastMessage, setBroadcastMessage] = useState("");
  const [broadcastOrgId, setBroadcastOrgId] = useState("all");

  useEffect(() => {
    if (!userLoading && !user) {
      window.location.href = "/admin/login";
      return;
    }

    if (user) {
      checkAdminAccess();
    }
  }, [user, userLoading]);

  const checkAdminAccess = async () => {
    try {
      const response = await fetch("/api/users/role");
      const data = await response.json();

      if (data.user?.system_role !== "system_admin") {
        window.location.href = "/admin/login";
        return;
      }

      fetchData();
    } catch (error) {
      console.error("Error checking admin access:", error);
      window.location.href = "/admin/login";
    }
  };

  const fetchData = async () => {
    try {
      const [usersRes, statsRes, orgsRes, membersRes, inventoryRes, alertsRes] =
        await Promise.all([
          fetch("/api/admin/users"),
          fetch("/api/admin/stats"),
          fetch("/api/admin/organizations"),
          fetch("/api/admin/members"),
          fetch("/api/admin/inventory"),
          fetch("/api/disaster-relief/alerts"),
        ]);

      if (!usersRes.ok || !statsRes.ok) {
        throw new Error("Failed to fetch admin data");
      }

      const usersData = await usersRes.json();
      const statsData = await statsRes.json();
      const orgsData = orgsRes.ok
        ? await orgsRes.json()
        : { organizations: [] };
      const membersData = membersRes.ok
        ? await membersRes.json()
        : { members: [] };
      const inventoryData = inventoryRes.ok
        ? await inventoryRes.json()
        : { inventory: [] };
      const alertsData = alertsRes.ok ? await alertsRes.json() : { alerts: [] };

      setUsers(usersData.users || []);
      setStats(statsData);
      setOrganizations(orgsData.organizations || []);
      setMembers(membersData.members || []);
      setInventory(inventoryData.inventory || []);
      setAlerts(alertsData.alerts || []);
    } catch (error) {
      console.error("Error fetching admin data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEditUser = (user) => {
    setEditingUser({
      ...user,
      new_system_role: user.system_role,
    });
    setShowEditModal(true);
  };

  const handleUpdateRole = async () => {
    try {
      const response = await fetch("/api/users/role", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: editingUser.id,
          system_role: editingUser.new_system_role,
        }),
      });

      if (!response.ok) throw new Error("Failed to update role");

      await fetchData();
      setShowEditModal(false);
      setEditingUser(null);
    } catch (error) {
      console.error("Error updating role:", error);
      alert("Failed to update user role");
    }
  };

  const handleSendBroadcast = async () => {
    try {
      const payload = {
        title: broadcastTitle,
        message: broadcastMessage,
      };

      if (broadcastOrgId !== "all") {
        payload.org_id = parseInt(broadcastOrgId);
      }

      const response = await fetch("/api/disaster-relief/alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) throw new Error("Failed to send broadcast");

      alert("Broadcast sent successfully!");
      setShowBroadcastModal(false);
      setBroadcastTitle("");
      setBroadcastMessage("");
      setBroadcastOrgId("all");
      fetchData();
    } catch (error) {
      console.error("Error sending broadcast:", error);
      alert("Failed to send broadcast");
    }
  };

  const filteredUsers = users.filter((u) => {
    const search = searchTerm.toLowerCase();
    return (
      u.name?.toLowerCase().includes(search) ||
      u.email?.toLowerCase().includes(search) ||
      u.system_role?.toLowerCase().includes(search)
    );
  });

  if (loading || userLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-500 mx-auto mb-4"></div>
          <p className="text-slate-400">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-800/50 backdrop-blur-xl border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-red-600 rounded-xl flex items-center justify-center shadow-lg shadow-red-900/50">
                <Shield size={24} className="text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">
                  AERA System Administrator
                </h1>
                <p className="text-slate-400 text-sm">
                  Full Access • All Organizations
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowBroadcastModal(true)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
              >
                <Radio size={18} />
                Broadcast Alert
              </button>
              <a
                href="/admin/create-admin"
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
              >
                <UserPlus size={18} />
                Create Admin
              </a>
              <a
                href="/"
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm font-medium transition-colors"
              >
                Dashboard
              </a>
              <a
                href="/account/logout"
                className="w-10 h-10 bg-slate-700 hover:bg-slate-600 rounded-lg flex items-center justify-center transition-colors"
              >
                <LogOut size={18} className="text-white" />
              </a>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Tab Navigation */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          <TabButton
            active={activeTab === "dashboard"}
            onClick={() => setActiveTab("dashboard")}
            icon={BarChart3}
            label="Dashboard"
          />
          <TabButton
            active={activeTab === "users"}
            onClick={() => setActiveTab("users")}
            icon={Users}
            label="User Directory"
          />
          <TabButton
            active={activeTab === "organizations"}
            onClick={() => setActiveTab("organizations")}
            icon={Building2}
            label="Organizations"
          />
          <TabButton
            active={activeTab === "members"}
            onClick={() => setActiveTab("members")}
            icon={UserCircle}
            label="Members"
          />
          <TabButton
            active={activeTab === "inventory"}
            onClick={() => setActiveTab("inventory")}
            icon={Package}
            label="Master Inventory"
          />
          <TabButton
            active={activeTab === "broadcasts"}
            onClick={() => setActiveTab("broadcasts")}
            icon={Radio}
            label="Broadcasts"
          />
          <TabButton
            active={activeTab === "database"}
            onClick={() => setActiveTab("database")}
            icon={Database}
            label="Raw Database"
          />
        </div>

        {/* Dashboard Tab */}
        {activeTab === "dashboard" && stats && (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard
                title="Total Users"
                value={stats.users.total_users}
                icon={Users}
                color="blue"
              />
              <StatCard
                title="Organizations"
                value={stats.organizations.total_organizations}
                icon={Building2}
                color="purple"
              />
              <StatCard
                title="Active SOS"
                value={stats.sos.pending_sos}
                icon={AlertTriangle}
                color="red"
              />
              <StatCard
                title="Safe Members"
                value={stats.members.safe_members}
                icon={Shield}
                color="green"
              />
            </div>

            {/* System Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Activity size={20} className="text-red-400" />
                  <h3 className="text-lg font-bold text-white">
                    Emergency Status
                  </h3>
                </div>
                <div className="space-y-3">
                  <StatusRow
                    label="Pending SOS"
                    value={stats.sos.pending_sos}
                    color="red"
                  />
                  <StatusRow
                    label="Responding"
                    value={stats.sos.responding_sos}
                    color="yellow"
                  />
                  <StatusRow
                    label="Resolved SOS"
                    value={stats.sos.resolved_sos}
                    color="green"
                  />
                </div>
              </div>

              <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <HelpCircle size={20} className="text-blue-400" />
                  <h3 className="text-lg font-bold text-white">
                    Help Requests
                  </h3>
                </div>
                <div className="space-y-3">
                  <StatusRow
                    label="Pending"
                    value={stats.helpRequests.pending_requests}
                    color="yellow"
                  />
                  <StatusRow
                    label="In Progress"
                    value={stats.helpRequests.in_progress_requests}
                    color="blue"
                  />
                  <StatusRow
                    label="Resolved"
                    value={stats.helpRequests.resolved_requests}
                    color="green"
                  />
                </div>
              </div>

              <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <BarChart3 size={20} className="text-green-400" />
                  <h3 className="text-lg font-bold text-white">
                    Safety Status
                  </h3>
                </div>
                <div className="space-y-3">
                  <StatusRow
                    label="Safe"
                    value={stats.members.safe_members}
                    color="green"
                  />
                  <StatusRow
                    label="Unknown"
                    value={stats.members.unknown_members}
                    color="gray"
                  />
                  <StatusRow
                    label="At Risk"
                    value={stats.members.at_risk_members}
                    color="red"
                  />
                </div>
              </div>
            </div>
          </>
        )}

        {/* Users Table */}
        {activeTab === "users" && (
          <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">
                User Directory & Access Control
              </h2>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search
                    size={18}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                  />
                  <input
                    type="text"
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 outline-none"
                  />
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      User
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      System Role
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Organizations
                    </th>
                    <th className="text-right py-3 px-4 text-slate-400 font-semibold text-sm">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((u) => (
                    <tr
                      key={u.id}
                      className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors"
                    >
                      <td className="py-4 px-4">
                        <div>
                          <p className="text-white font-medium">
                            {u.name || "No name"}
                          </p>
                          <p className="text-slate-400 text-sm">{u.email}</p>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                            u.system_role === "system_admin"
                              ? "bg-red-900/30 text-red-300 border border-red-700"
                              : "bg-slate-700 text-slate-300 border border-slate-600"
                          }`}
                        >
                          {u.system_role === "system_admin"
                            ? "SYSTEM ADMIN"
                            : "USER"}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        {u.organizations.length > 0 ? (
                          <div className="space-y-1">
                            {u.organizations.slice(0, 2).map((org, idx) => (
                              <div
                                key={idx}
                                className="text-sm text-slate-300 flex items-center gap-2"
                              >
                                <Building2
                                  size={14}
                                  className="text-slate-500"
                                />
                                <span className="font-medium">
                                  {org.org_name}
                                </span>
                                <span className="text-slate-500">
                                  ({org.role})
                                </span>
                              </div>
                            ))}
                            {u.organizations.length > 2 && (
                              <p className="text-xs text-slate-500">
                                +{u.organizations.length - 2} more
                              </p>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-500 text-sm">
                            No organizations
                          </span>
                        )}
                      </td>
                      <td className="py-4 px-4 text-right">
                        <button
                          onClick={() => handleEditUser(u)}
                          className="inline-flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm font-medium transition-colors"
                        >
                          <Edit size={14} />
                          Edit Role
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredUsers.length === 0 && (
                <p className="text-center py-8 text-slate-500">
                  No users found
                </p>
              )}
            </div>
          </div>
        )}

        {/* Organizations Table */}
        {activeTab === "organizations" && (
          <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">
                Organization Directory
              </h2>
              <a
                href="/organizations"
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
              >
                <PlusCircle size={18} />
                Create Organization
              </a>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Name
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Creator
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Created At
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Members
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Join Code
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {organizations.map((org) => (
                    <tr
                      key={org.id}
                      className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors"
                    >
                      <td className="py-4 px-4">
                        <div>
                          <p className="text-white font-medium">{org.name}</p>
                          {org.address && (
                            <p className="text-slate-400 text-sm">
                              {org.address}
                            </p>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <p className="text-slate-300">
                          {org.creator_email || "N/A"}
                        </p>
                        {org.creator_name && (
                          <p className="text-slate-500 text-sm">
                            {org.creator_name}
                          </p>
                        )}
                      </td>
                      <td className="py-4 px-4 text-slate-300">
                        {new Date(org.created_at).toLocaleDateString()}
                      </td>
                      <td className="py-4 px-4">
                        <span className="bg-blue-900/30 text-blue-300 px-3 py-1 rounded-full text-sm font-semibold">
                          {org.member_count} members
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <span className="font-mono text-slate-300 bg-slate-900/50 px-3 py-1 rounded">
                          {org.join_code}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {organizations.length === 0 && (
                <p className="text-center py-8 text-slate-500">
                  No organizations found
                </p>
              )}
            </div>
          </div>
        )}

        {/* Members Table */}
        {activeTab === "members" && (
          <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
            <h2 className="text-2xl font-bold text-white mb-6">
              Member Directory
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Name
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Organization
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Status
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Type
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Contact
                    </th>
                    <th className="text-left py-3 px-4 text-slate-400 font-semibold text-sm">
                      Household
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {members.map((member) => (
                    <tr
                      key={member.id}
                      className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors"
                    >
                      <td className="py-4 px-4">
                        <div>
                          <p className="text-white font-medium">
                            {member.name}
                          </p>
                          {member.age && (
                            <p className="text-slate-400 text-sm">
                              Age: {member.age}
                            </p>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <p className="text-slate-300">
                          {member.organization_name || "No organization"}
                        </p>
                      </td>
                      <td className="py-4 px-4">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            member.status === "safe"
                              ? "bg-green-900/30 text-green-300"
                              : member.status === "unknown"
                                ? "bg-gray-700 text-gray-300"
                                : "bg-red-900/30 text-red-300"
                          }`}
                        >
                          {member.status}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-slate-300">
                        {member.member_type}
                      </td>
                      <td className="py-4 px-4">
                        {member.phone && (
                          <p className="text-slate-300 text-sm">
                            {member.phone}
                          </p>
                        )}
                        {member.email && (
                          <p className="text-slate-400 text-xs">
                            {member.email}
                          </p>
                        )}
                      </td>
                      <td className="py-4 px-4">
                        <p className="text-slate-300">
                          {member.household_name || "N/A"}
                        </p>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {members.length === 0 && (
                <p className="text-center py-8 text-slate-500">
                  No members found
                </p>
              )}
            </div>
          </div>
        )}

        {/* Master Inventory Tab */}
        {activeTab === "inventory" && (
          <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
            <h2 className="text-2xl font-bold text-white mb-6">
              Master Inventory Database
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {inventory.map((item) => (
                <div
                  key={item.id}
                  className="bg-slate-900/50 border border-slate-700 rounded-xl p-5"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-blue-900/30 rounded-xl flex items-center justify-center">
                        <Package size={24} className="text-blue-400" />
                      </div>
                      <div>
                        <h3 className="text-white font-bold">
                          {item.item_name}
                        </h3>
                        <p className="text-slate-400 text-sm">
                          {item.category}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Organization:</span>
                      <span className="text-white font-medium">
                        {item.org_name}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Stock Level:</span>
                      <span
                        className={`font-bold ${item.quantity / item.capacity < 0.2 ? "text-red-400" : "text-green-400"}`}
                      >
                        {item.quantity} / {item.capacity} {item.unit}
                      </span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden mt-3">
                      <div
                        className={`h-full rounded-full ${item.quantity / item.capacity < 0.2 ? "bg-red-500" : "bg-blue-500"}`}
                        style={{
                          width: `${(item.quantity / item.capacity) * 100}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {inventory.length === 0 && (
              <p className="text-center py-12 text-slate-500">
                No inventory items found
              </p>
            )}
          </div>
        )}

        {/* Broadcasts Tab */}
        {activeTab === "broadcasts" && (
          <div className="space-y-6">
            <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">
                  Broadcast Management
                </h2>
                <button
                  onClick={() => setShowBroadcastModal(true)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
                >
                  <Send size={18} />
                  Send New Broadcast
                </button>
              </div>

              <div className="space-y-4">
                {alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="bg-slate-900/50 border border-slate-700 rounded-xl p-5"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Radio size={18} className="text-blue-400" />
                          <h3 className="text-white font-bold text-lg">
                            {alert.title}
                          </h3>
                        </div>
                        <p className="text-slate-300 mb-3">{alert.message}</p>
                        <div className="flex items-center gap-4 text-sm flex-wrap">
                          <span className="text-slate-400">
                            Sent by:{" "}
                            <span className="text-slate-300">
                              {alert.created_by_name || "System"}
                            </span>
                          </span>
                          <span className="text-slate-400">
                            {new Date(alert.created_at).toLocaleString()}
                          </span>
                          {alert.org_name && (
                            <span className="px-2 py-1 bg-blue-900/30 text-blue-300 rounded">
                              {alert.org_name}
                            </span>
                          )}
                          {!alert.org_id && (
                            <span className="px-2 py-1 bg-red-900/30 text-red-300 rounded font-bold">
                              ALL ORGANIZATIONS
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {alerts.length === 0 && (
                  <p className="text-center py-12 text-slate-500">
                    No broadcasts sent yet
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Raw Database Tab */}
        {activeTab === "database" && (
          <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">
                Raw Database View
              </h2>
              <a
                href="/admin/debug"
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm font-medium transition-colors"
              >
                Open Debug Panel
              </a>
            </div>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <DatabaseStats title="Total Users" value={users.length} />
                <DatabaseStats
                  title="Total Organizations"
                  value={organizations.length}
                />
                <DatabaseStats title="Total Members" value={members.length} />
                <DatabaseStats
                  title="Total Inventory Items"
                  value={inventory.length}
                />
                <DatabaseStats title="Total Alerts" value={alerts.length} />
                <DatabaseStats
                  title="Active SOS Requests"
                  value={stats?.sos?.pending_sos || 0}
                />
              </div>

              <div className="bg-slate-900/50 border border-slate-700 rounded-xl p-6">
                <h3 className="text-white font-bold mb-4">Database Access</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <a
                    href="/admin/debug"
                    className="px-4 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-center transition-colors font-medium"
                  >
                    View All Tables
                  </a>
                  <button className="px-4 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors font-medium">
                    Export Database
                  </button>
                  <button className="px-4 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors font-medium">
                    Run SQL Query
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Broadcast Modal */}
      {showBroadcastModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl w-full max-w-lg p-6">
            <h2 className="text-2xl font-bold text-white mb-6">
              Send Broadcast Alert
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">
                  Target Organization
                </label>
                <select
                  value={broadcastOrgId}
                  onChange={(e) => setBroadcastOrgId(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
                >
                  <option value="all">All Organizations</option>
                  {organizations.map((org) => (
                    <option key={org.id} value={org.id}>
                      {org.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">
                  Alert Title
                </label>
                <input
                  type="text"
                  placeholder="Enter broadcast title"
                  value={broadcastTitle}
                  onChange={(e) => setBroadcastTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">
                  Message
                </label>
                <textarea
                  placeholder="Enter broadcast message"
                  value={broadcastMessage}
                  onChange={(e) => setBroadcastMessage(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none resize-none"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setShowBroadcastModal(false);
                    setBroadcastTitle("");
                    setBroadcastMessage("");
                    setBroadcastOrgId("all");
                  }}
                  className="flex-1 px-4 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg font-semibold transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSendBroadcast}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2"
                >
                  <Send size={18} />
                  Send Broadcast
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {showEditModal && editingUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl w-full max-w-md p-6">
            <h2 className="text-2xl font-bold text-white mb-6">
              Edit User Role
            </h2>

            <div className="space-y-4">
              <div>
                <p className="text-sm text-slate-400 mb-1">User</p>
                <p className="text-white font-medium">{editingUser.email}</p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">
                  System Role
                </label>
                <select
                  value={editingUser.new_system_role}
                  onChange={(e) =>
                    setEditingUser({
                      ...editingUser,
                      new_system_role: e.target.value,
                    })
                  }
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:border-red-500 focus:ring-2 focus:ring-red-500/20 outline-none"
                >
                  <option value="user">User</option>
                  <option value="system_admin">System Admin</option>
                </select>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingUser(null);
                  }}
                  className="flex-1 px-4 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg font-semibold transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpdateRole}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-3 rounded-lg font-semibold transition-colors"
                >
                  Update Role
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TabButton({ active, onClick, icon: Icon, label }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap ${
        active
          ? "bg-red-600 text-white shadow-lg shadow-red-900/30"
          : "bg-slate-800/50 text-slate-400 hover:bg-slate-700/50 border border-slate-700"
      }`}
    >
      <Icon size={18} />
      {label}
    </button>
  );
}

function StatCard({ title, value, icon: Icon, color }) {
  const colors = {
    blue: "bg-blue-900/30 border-blue-700 text-blue-300",
    purple: "bg-purple-900/30 border-purple-700 text-purple-300",
    red: "bg-red-900/30 border-red-700 text-red-300",
    green: "bg-green-900/30 border-green-700 text-green-300",
  };

  return (
    <div className={`backdrop-blur-xl border rounded-2xl p-6 ${colors[color]}`}>
      <div className="flex items-center justify-between mb-4">
        <Icon size={24} />
      </div>
      <p className="text-3xl font-bold mb-1">{value}</p>
      <p className="text-sm opacity-80">{title}</p>
    </div>
  );
}

function StatusRow({ label, value, color }) {
  const colors = {
    red: "text-red-400",
    yellow: "text-yellow-400",
    blue: "text-blue-400",
    green: "text-green-400",
    gray: "text-slate-400",
  };

  return (
    <div className="flex justify-between items-center">
      <span className="text-slate-400 text-sm">{label}</span>
      <span className={`font-bold ${colors[color]}`}>{value}</span>
    </div>
  );
}

function DatabaseStats({ title, value }) {
  return (
    <div className="bg-slate-900/50 border border-slate-700 rounded-xl p-5">
      <p className="text-slate-400 text-sm mb-2">{title}</p>
      <p className="text-3xl font-bold text-white">{value}</p>
    </div>
  );
}
