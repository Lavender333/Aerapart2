"use client";

import { useState } from "react";
import { Shield, CheckCircle } from "lucide-react";

export default function AdminSetup() {
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const setupAdmin = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/admin/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: "aerapp369@gmail.com",
          password: "aerapp369",
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Setup failed");
      }

      setDone(true);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-red-600 rounded-2xl mb-4 shadow-lg shadow-red-900/50">
            <Shield size={32} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">
            System Admin Setup
          </h1>
          <p className="text-slate-400">One-time admin account creation</p>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl shadow-2xl p-8">
          {!done ? (
            <>
              {error && (
                <div className="bg-red-900/30 border border-red-700 text-red-200 px-4 py-3 rounded-lg mb-6">
                  {error}
                </div>
              )}

              <div className="space-y-4 mb-6">
                <div>
                  <p className="text-sm text-slate-400 mb-1">Email</p>
                  <p className="text-white font-mono">aerapp369@gmail.com</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400 mb-1">Password</p>
                  <p className="text-white font-mono">aerapp369</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400 mb-1">Role</p>
                  <p className="text-red-300 font-semibold">System Admin</p>
                </div>
              </div>

              <button
                onClick={setupAdmin}
                disabled={loading}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-red-900/30"
              >
                {loading ? "Creating Admin..." : "Create Admin Account"}
              </button>
            </>
          ) : (
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-600 rounded-full mb-4">
                <CheckCircle size={32} className="text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">
                Admin Created!
              </h2>
              <p className="text-slate-400 mb-6">
                Your system admin account is ready to use
              </p>
              <a
                href="/admin/login"
                className="inline-block bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                Go to Admin Login
              </a>
            </div>
          )}
        </div>

        {!done && (
          <div className="mt-6 bg-amber-900/20 border border-amber-700/50 rounded-xl p-4">
            <p className="text-amber-200 text-xs text-center">
              ⚠️ This page should be removed after first use for security
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
