"use client";
import { useState } from "react";

export default function CreateAdminNow() {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const createAdmin = async () => {
    setLoading(true);
    setResult(null);

    try {
      const response = await fetch("/api/admin/create-user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: "admin@aera.com",
          password: "Admin123!",
          name: "AERA Admin",
          role: "system_admin",
        }),
      });

      const data = await response.json();
      setResult(data);
    } catch (error) {
      setResult({ error: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-6">
            Create Admin User
          </h1>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6">
            <h2 className="font-semibold text-blue-900 mb-2">
              Admin Credentials:
            </h2>
            <div className="space-y-1 text-blue-800">
              <p>
                <strong>Email:</strong> admin@aera.com
              </p>
              <p>
                <strong>Password:</strong> Admin123!
              </p>
              <p>
                <strong>Role:</strong> System Admin
              </p>
            </div>
          </div>

          <button
            onClick={createAdmin}
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {loading ? "Creating Admin..." : "Create Admin User"}
          </button>

          {result && (
            <div
              className={`mt-6 p-4 rounded-lg ${result.error ? "bg-red-50 border border-red-200" : "bg-green-50 border border-green-200"}`}
            >
              {result.error ? (
                <div>
                  <h3 className="font-semibold text-red-800 mb-2">Error</h3>
                  <p className="text-red-700">{result.error}</p>
                </div>
              ) : (
                <div>
                  <h3 className="font-semibold text-green-800 mb-2">
                    ✅ Success!
                  </h3>
                  <div className="text-green-700 space-y-1">
                    <p>{result.message}</p>
                    <p>
                      <strong>User ID:</strong> {result.userId}
                    </p>
                    <p>
                      <strong>Email:</strong> {result.email}
                    </p>
                    <p>
                      <strong>Role:</strong> {result.role}
                    </p>
                  </div>

                  <div className="mt-4 pt-4 border-t border-green-200">
                    <p className="text-green-800 font-semibold mb-2">
                      Now you can sign in:
                    </p>
                    <a
                      href="/account/signin"
                      className="inline-block bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded transition-colors"
                    >
                      Go to Sign In
                    </a>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
