"use client";

import { useState, useEffect } from "react";
import { useUser } from "@/utils/useUser";
import {
  Package,
  AlertTriangle,
  Home,
  MapPin,
  HelpCircle,
  Clock,
  CheckCircle,
  XCircle,
} from "lucide-react";

export default function HelpRequestsDashboard() {
  const { user, loading: userLoading } = useUser();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all"); // 'all', 'pending', 'in_progress', 'resolved'

  useEffect(() => {
    async function fetchRequests() {
      try {
        const params = new URLSearchParams();
        if (filter !== "all") {
          params.set("status", filter);
        }

        const response = await fetch(`/api/help-requests?${params}`);
        if (!response.ok) throw new Error("Failed to fetch requests");

        const data = await response.json();
        setRequests(data.requests || []);
      } catch (error) {
        console.error("Error fetching help requests:", error);
      } finally {
        setLoading(false);
      }
    }

    if (user) {
      fetchRequests();
    }
  }, [user, filter]);

  const updateRequestStatus = async (requestId, newStatus) => {
    try {
      const response = await fetch("/api/help-requests", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: requestId,
          status: newStatus,
          resolved_by: newStatus === "resolved" ? user.id : null,
          resolved_at:
            newStatus === "resolved" ? new Date().toISOString() : null,
        }),
      });

      if (!response.ok) throw new Error("Failed to update request");

      // Refresh requests
      const params = new URLSearchParams();
      if (filter !== "all") {
        params.set("status", filter);
      }
      const refreshResponse = await fetch(`/api/help-requests?${params}`);
      const data = await refreshResponse.json();
      setRequests(data.requests || []);
    } catch (error) {
      console.error("Error updating request:", error);
      alert("Failed to update request");
    }
  };

  const getRequestIcon = (type) => {
    switch (type) {
      case "food":
        return <Package className="w-5 h-5 text-blue-600" />;
      case "medical":
        return <AlertTriangle className="w-5 h-5 text-red-600" />;
      case "shelter":
        return <Home className="w-5 h-5 text-green-600" />;
      case "transport":
        return <MapPin className="w-5 h-5 text-yellow-600" />;
      default:
        return <HelpCircle className="w-5 h-5 text-purple-600" />;
    }
  };

  const getStatusBadge = (status) => {
    const styles = {
      pending: "bg-blue-100 text-blue-800 border-blue-200",
      in_progress: "bg-yellow-100 text-yellow-800 border-yellow-200",
      resolved: "bg-green-100 text-green-800 border-green-200",
      closed: "bg-gray-100 text-gray-800 border-gray-200",
    };

    const icons = {
      pending: <Clock className="w-3 h-3" />,
      in_progress: <Clock className="w-3 h-3" />,
      resolved: <CheckCircle className="w-3 h-3" />,
      closed: <XCircle className="w-3 h-3" />,
    };

    return (
      <span
        className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold border ${styles[status]}`}
      >
        {icons[status]}
        {status.replace("_", " ").toUpperCase()}
      </span>
    );
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading help requests...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="w-16 h-16 text-red-600 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900">
            Authentication Required
          </h1>
          <p className="mt-2 text-gray-600">
            Please sign in to view help requests
          </p>
        </div>
      </div>
    );
  }

  const stats = {
    total: requests.length,
    pending: requests.filter((r) => r.status === "pending").length,
    in_progress: requests.filter((r) => r.status === "in_progress").length,
    resolved: requests.filter((r) => r.status === "resolved").length,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Help Requests Dashboard
          </h1>
          <p className="mt-2 text-gray-600">
            Manage and respond to assistance requests from your organization
            members
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <StatCard title="Total Requests" value={stats.total} color="blue" />
          <StatCard title="Pending" value={stats.pending} color="yellow" />
          <StatCard
            title="In Progress"
            value={stats.in_progress}
            color="orange"
          />
          <StatCard title="Resolved" value={stats.resolved} color="green" />
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <div className="flex gap-2 flex-wrap">
            <FilterButton
              active={filter === "all"}
              onClick={() => setFilter("all")}
            >
              All
            </FilterButton>
            <FilterButton
              active={filter === "pending"}
              onClick={() => setFilter("pending")}
            >
              Pending
            </FilterButton>
            <FilterButton
              active={filter === "in_progress"}
              onClick={() => setFilter("in_progress")}
            >
              In Progress
            </FilterButton>
            <FilterButton
              active={filter === "resolved"}
              onClick={() => setFilter("resolved")}
            >
              Resolved
            </FilterButton>
          </div>
        </div>

        {/* Requests List */}
        <div className="space-y-4">
          {requests.length === 0 ? (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
              <HelpCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No help requests found</p>
            </div>
          ) : (
            requests.map((request) => (
              <div
                key={request.id}
                className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="flex-shrink-0 mt-1">
                      {getRequestIcon(request.request_type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900 capitalize">
                          {request.request_type}
                        </h3>
                        {getStatusBadge(request.status)}
                      </div>

                      {request.user_name && (
                        <p className="text-sm text-gray-600 mb-1">
                          Requested by:{" "}
                          <span className="font-medium">
                            {request.user_name}
                          </span>
                          {request.user_email && (
                            <span className="text-gray-500">
                              {" "}
                              ({request.user_email})
                            </span>
                          )}
                        </p>
                      )}

                      {request.org_name && (
                        <p className="text-sm text-gray-600 mb-1">
                          Organization:{" "}
                          <span className="font-medium">
                            {request.org_name}
                          </span>
                        </p>
                      )}

                      {request.message && (
                        <p className="text-sm text-gray-700 mt-2 italic">
                          "{request.message}"
                        </p>
                      )}

                      <p className="text-xs text-gray-500 mt-2">
                        Submitted:{" "}
                        {new Date(request.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  {/* Action buttons */}
                  {request.status !== "resolved" && (
                    <div className="flex gap-2 ml-4">
                      {request.status === "pending" && (
                        <button
                          onClick={() =>
                            updateRequestStatus(request.id, "in_progress")
                          }
                          className="px-3 py-2 bg-yellow-600 text-white rounded-lg text-sm font-medium hover:bg-yellow-700 transition-colors"
                        >
                          Start
                        </button>
                      )}
                      <button
                        onClick={() =>
                          updateRequestStatus(request.id, "resolved")
                        }
                        className="px-3 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
                      >
                        Resolve
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, color }) {
  const colors = {
    blue: "bg-blue-50 border-blue-200 text-blue-800",
    yellow: "bg-yellow-50 border-yellow-200 text-yellow-800",
    orange: "bg-orange-50 border-orange-200 text-orange-800",
    green: "bg-green-50 border-green-200 text-green-800",
  };

  return (
    <div className={`rounded-lg border p-6 ${colors[color]}`}>
      <p className="text-sm font-medium opacity-80">{title}</p>
      <p className="text-3xl font-bold mt-2">{value}</p>
    </div>
  );
}

function FilterButton({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
        active
          ? "bg-blue-600 text-white"
          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
      }`}
    >
      {children}
    </button>
  );
}
