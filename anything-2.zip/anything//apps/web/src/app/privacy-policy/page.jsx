export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
        <p className="text-sm text-gray-600 mb-8">
          Last updated: February 7, 2026
        </p>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">1. Data Collected</h2>
          <p className="mb-4">
            AERA collects the following information to provide emergency
            disaster relief services:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Location Data:</strong> Your real-time GPS location when
              you enable live location sharing, both when the app is in use
              (foreground) and when monitoring is active (background)
            </li>
            <li>
              <strong>Safety Status:</strong> Your reported safety status (safe,
              need help, emergency)
            </li>
            <li>
              <strong>Emergency Help Requests:</strong> Messages and details you
              submit when requesting assistance
            </li>
            <li>
              <strong>Account Information:</strong> Email address, name, and
              authentication data
            </li>
            <li>
              <strong>Household Data:</strong> Information about your household
              members and their safety status
            </li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">
            2. How Data Is Collected
          </h2>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>User Input:</strong> Information you provide when creating
              an account, updating your profile, or submitting help requests
            </li>
            <li>
              <strong>Device Permissions:</strong> GPS location data when you
              grant location access
            </li>
            <li>
              <strong>Background Services:</strong> Continuous location tracking
              when you activate safety monitoring (only when explicitly enabled
              by you)
            </li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">3. How Data Is Used</h2>
          <p className="mb-4">Your data is used exclusively for:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Safety Monitoring:</strong> Tracking your location during
              active safety monitoring to enable emergency response
            </li>
            <li>
              <strong>Emergency Response Coordination:</strong> Sharing your
              location and status with your designated response team when you
              request help
            </li>
            <li>
              <strong>App Functionality:</strong> Providing core features like
              household tracking, inventory management, and alerts
            </li>
          </ul>
          <p className="mt-4 text-gray-700">
            We do not use your data for advertising, marketing, or any purpose
            unrelated to emergency disaster relief.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">4. Data Sharing</h2>
          <p className="mb-4">Your data is shared only as follows:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Response Team:</strong> Your real-time location and safety
              status are shared with members of your organization's emergency
              response team when you activate live location sharing or submit a
              help request
            </li>
            <li>
              <strong>Organization Members:</strong> Information you choose to
              share within your organization (such as household status updates)
            </li>
            <li>
              <strong>No Third-Party Sales:</strong> We never sell your personal
              data to third parties
            </li>
            <li>
              <strong>No External Sharing:</strong> Your data is not shared with
              advertisers or external services except as required by law
            </li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">5. User Consent</h2>
          <p className="mb-4">You are in control of your data:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              Location access requires explicit permission through iOS system
              prompts
            </li>
            <li>Live location sharing requires additional in-app consent</li>
            <li>
              You can turn off location sharing at any time through the app
            </li>
            <li>You can manage permissions in your device Settings</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">
            6. Data Retention & Deletion
          </h2>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Active Data:</strong> Your data is retained while you have
              an active account
            </li>
            <li>
              <strong>Location History:</strong> Real-time location data is used
              for immediate emergency response and is not stored long-term
            </li>
            <li>
              <strong>Account Deletion:</strong> You can delete your account
              directly from the mobile app (Settings → Delete Account) or by
              contacting support at aerapp369@gmail.com. All your personal data
              will be permanently removed within 30 days.
            </li>
            <li>
              <strong>Inactive Accounts:</strong> Accounts inactive for 2 years
              may be automatically deleted
            </li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">7. User Rights</h2>
          <p className="mb-4">You have the right to:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Access:</strong> Request a copy of your personal data
            </li>
            <li>
              <strong>Correction:</strong> Update or correct your information
              through the app
            </li>
            <li>
              <strong>Deletion:</strong> Request permanent deletion of your
              account and data
            </li>
            <li>
              <strong>Opt-Out:</strong> Disable location sharing or other
              features at any time
            </li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">
            8. Contact Information
          </h2>
          <p className="mb-4">
            For privacy concerns, data requests, or account deletion:
          </p>
          <p className="font-semibold">Email: aerapp369@gmail.com</p>
          <p className="mt-2 text-gray-700">
            We will respond to all privacy-related inquiries within 7 business
            days.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">
            9. Changes to This Policy
          </h2>
          <p>
            We may update this privacy policy as our services evolve.
            Significant changes will be communicated through the app or via
            email. Continued use of the app after changes constitutes acceptance
            of the updated policy.
          </p>
        </section>

        <div className="mt-12 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-gray-700">
            <strong>Questions?</strong> If you have any questions about this
            privacy policy or how we handle your data, please contact us at
            aerapp369@gmail.com
          </p>
        </div>
      </div>
    </div>
  );
}
