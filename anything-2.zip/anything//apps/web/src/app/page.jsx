"use client";

import React, { useState, useEffect } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
} from "recharts";
import {
  Settings,
  Bell,
  Filter,
  Calendar,
  Download,
  Plus,
  MoreHorizontal,
  Map as MapIcon,
  AlertTriangle,
  Package,
  Users,
  Shield,
  Activity,
  Menu,
  X,
  ChevronRight,
  Send,
  Building2,
  LogOut,
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { APIProvider, Map, Marker } from "@vis.gl/react-google-maps";
import useUser from "@/utils/useUser";

// API fetching functions
const fetchSOS = async (orgId) => {
  const res = await fetch(`/api/disaster-relief/sos?org_id=${orgId}`);
  if (!res.ok) throw new Error("Failed to fetch SOS requests");
  return res.json();
};

const fetchInventory = async (orgId) => {
  const res = await fetch(`/api/disaster-relief/inventory?org_id=${orgId}`);
  if (!res.ok) throw new Error("Failed to fetch inventory");
  return res.json();
};

const fetchSafety = async (orgId) => {
  const res = await fetch(`/api/disaster-relief/safety?org_id=${orgId}`);
  if (!res.ok) throw new Error("Failed to fetch safety status");
  return res.json();
};

const fetchOrganizations = async () => {
  const res = await fetch("/api/organizations");
  if (!res.ok) throw new Error("Failed to fetch organizations");
  return res.json();
};

export default function AERADashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("Dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedOrgId, setSelectedOrgId] = useState(null);
  const [showOrgSelector, setShowOrgSelector] = useState(false);
  const queryClient = useQueryClient();

  const [alertTitle, setAlertTitle] = useState("");
  const [alertMessage, setAlertMessage] = useState("");
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);

  // Fetch user's organizations
  const { data: organizations = [], isLoading: loadingOrgs } = useQuery({
    queryKey: ["organizations", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const res = await fetch(`/api/organizations?userId=${user.id}`);
      if (!res.ok) throw new Error("Failed to fetch organizations");
      return res.json();
    },
    enabled: !!user,
  });

  // Check user role and redirect members to member home
  useEffect(() => {
    if (!loadingOrgs && user) {
      // If user has no organizations
      if (organizations.length === 0) {
        const isSystemAdmin = user.system_role === "system_admin";

        if (!isSystemAdmin) {
          // Regular users without org go to member home
          console.log(
            "Member without org detected, redirecting to member home",
          );
          window.location.href = "/member-home";
          return;
        } else {
          // System admins without org go to admin panel
          console.log("System admin without org, redirecting to /admin");
          window.location.href = "/admin";
          return;
        }
      }

      // If user has organizations, check their role in the primary org
      const primaryOrg = organizations[0];
      const isMember =
        primaryOrg.role === "member" && user.system_role !== "system_admin";

      if (isMember) {
        console.log("Member detected, redirecting to member home");
        window.location.href = "/member-home";
        return;
      }
    }
  }, [organizations, loadingOrgs, user]);

  // Set default organization
  useEffect(() => {
    if (organizations.length > 0 && !selectedOrgId) {
      setSelectedOrgId(organizations[0].id);
    }
  }, [organizations, selectedOrgId]);

  const selectedOrg = organizations.find((org) => org.id === selectedOrgId);

  const { data: sosRequests = [], isLoading: loadingSOS } = useQuery({
    queryKey: ["sosRequests", selectedOrgId],
    queryFn: () => fetchSOS(selectedOrgId),
    refetchInterval: 5000,
    enabled: !!selectedOrgId,
  });

  const { data: inventory = [], isLoading: loadingInventory } = useQuery({
    queryKey: ["inventory", selectedOrgId],
    queryFn: () => fetchInventory(selectedOrgId),
    enabled: !!selectedOrgId,
  });

  const { data: households = [], isLoading: loadingSafety } = useQuery({
    queryKey: ["safetyStatus", selectedOrgId],
    queryFn: () => fetchSafety(selectedOrgId),
    enabled: !!selectedOrgId,
  });

  const updateSOSMutation = useMutation({
    mutationFn: async ({ id, status }) => {
      const res = await fetch("/api/disaster-relief/sos", {
        method: "PATCH",
        body: JSON.stringify({ id, status }),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["sosRequests", selectedOrgId],
      });
    },
  });

  const sendAlertMutation = useMutation({
    mutationFn: async (data) => {
      const res = await fetch("/api/disaster-relief/alerts", {
        method: "POST",
        body: JSON.stringify(data),
      });
      return res.json();
    },
    onSuccess: () => {
      setIsAlertModalOpen(false);
      setAlertTitle("");
      setAlertMessage("");
      alert("Alert broadcasted successfully!");
    },
  });

  // Redirect to signin if not authenticated
  useEffect(() => {
    if (!userLoading && !user) {
      window.location.href = "/account/signin";
    }
  }, [user, userLoading]);

  // Loading state
  if (userLoading || loadingOrgs || !selectedOrgId) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your relief hub...</p>
        </div>
      </div>
    );
  }

  const stats = [
    {
      label: "Active SOS",
      value: sosRequests.filter((r) => r.status === "pending").length,
      icon: AlertTriangle,
      color: "bg-red-500",
    },
    {
      label: "Safe Members",
      value: households.reduce(
        (acc, h) => acc + h.members.filter((m) => m.status === "safe").length,
        0,
      ),
      icon: Shield,
      color: "bg-green-500",
    },
    {
      label: "Water Stock",
      value: inventory.find((i) => i.category === "water")?.quantity || 0,
      icon: Package,
      color: "bg-blue-500",
    },
    { label: "Responders", value: 1, icon: Users, color: "bg-purple-500" },
  ];

  return (
    <div className="min-h-screen bg-[#F7F9FC] dark:bg-[#121212] font-inter">
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Geist:wght@400;700&family=Bricolage+Grotesque:wght@600;800&family=Inter:wght@300;400;500;600&display=swap');
        .font-geist { font-family: 'Geist', sans-serif; }
        .font-bricolage { font-family: 'Bricolage Grotesque', sans-serif; }
        .font-inter { font-family: 'Inter', sans-serif; }
      `}</style>

      {/* Alert Modal */}
      {isAlertModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white dark:bg-[#1E1E1E] w-full max-w-lg p-8 rounded-3xl shadow-2xl">
            <h2 className="text-2xl font-bricolage font-bold text-[#1F2937] dark:text-white mb-6">
              Send Alert to Team
            </h2>
            <div className="space-y-4">
              <input
                className="w-full p-4 rounded-2xl bg-gray-50 dark:bg-[#2A2A2A] border border-gray-200 dark:border-gray-700 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all"
                placeholder="Alert Title"
                value={alertTitle}
                onChange={(e) => setAlertTitle(e.target.value)}
              />
              <textarea
                className="w-full p-4 rounded-2xl bg-gray-50 dark:bg-[#2A2A2A] border border-gray-200 dark:border-gray-700 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 min-h-[120px] transition-all"
                placeholder="Message details..."
                value={alertMessage}
                onChange={(e) => setAlertMessage(e.target.value)}
              />
              <div className="flex gap-4">
                <button
                  onClick={() => setIsAlertModalOpen(false)}
                  className="flex-1 py-4 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-400 font-semibold rounded-2xl hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() =>
                    sendAlertMutation.mutate({
                      org_id: selectedOrgId,
                      title: alertTitle,
                      message: alertMessage,
                    })
                  }
                  className="flex-1 py-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold rounded-2xl shadow-lg shadow-blue-200 hover:shadow-blue-300 hover:from-blue-600 hover:to-blue-700 transition-all"
                >
                  Send Alert
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-[#1E1E1E]/80 backdrop-blur-xl border-b border-gray-100 dark:border-[#2A2A2A] h-[72px] flex items-center px-4 lg:px-10">
        <div className="flex items-center justify-between w-full max-w-screen-2xl mx-auto">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-blue-200">
              A
            </div>
            <div>
              <span className="text-[#1F2937] dark:text-white font-bold text-lg font-bricolage tracking-tight block">
                AERA Relief
              </span>
              {selectedOrg && (
                <button
                  onClick={() => setShowOrgSelector(!showOrgSelector)}
                  className="text-xs text-gray-500 hover:text-blue-600 flex items-center gap-1 mt-0.5 transition-colors"
                >
                  <Building2 size={12} />
                  {selectedOrg.name}
                  <ChevronRight
                    size={12}
                    className={`transform transition-transform ${showOrgSelector ? "rotate-90" : ""}`}
                  />
                </button>
              )}
            </div>
          </div>

          {/* Organization Selector Dropdown */}
          {showOrgSelector && (
            <div className="absolute top-20 left-4 bg-white dark:bg-[#1E1E1E] rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-700 p-2 w-72 z-50">
              <div className="p-3 border-b border-gray-100">
                <p className="text-xs font-semibold text-gray-500 uppercase">
                  Your Organizations
                </p>
              </div>
              {organizations.map((org) => (
                <button
                  key={org.id}
                  onClick={() => {
                    setSelectedOrgId(org.id);
                    setShowOrgSelector(false);
                  }}
                  className={`w-full text-left p-3 rounded-xl transition-all ${
                    org.id === selectedOrgId
                      ? "bg-blue-50 dark:bg-blue-900/20"
                      : "hover:bg-gray-50 dark:hover:bg-gray-800"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">
                        {org.name}
                      </p>
                      <p className="text-xs text-gray-500">{org.role}</p>
                    </div>
                    {org.id === selectedOrgId && (
                      <div className="w-2 h-2 rounded-full bg-blue-500" />
                    )}
                  </div>
                </button>
              ))}
              <div className="border-t border-gray-100 mt-2 pt-2">
                <a
                  href="/organizations"
                  className="block w-full text-center py-3 text-blue-600 font-semibold text-sm hover:bg-blue-50 rounded-xl transition-colors"
                >
                  Manage Organizations
                </a>
              </div>
            </div>
          )}

          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center">
              <Bell size={18} className="text-gray-600" />
            </div>
            <a
              href="/account/logout"
              className="w-10 h-10 rounded-full border border-gray-200 dark:border-gray-700 flex items-center justify-center hover:bg-gray-50 transition-colors"
            >
              <LogOut size={18} className="text-gray-600" />
            </a>
          </div>
        </div>
      </header>

      <main className="max-w-screen-2xl mx-auto px-4 lg:px-10 py-8">
        {/* Welcome Section */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div>
            <h1 className="text-4xl font-bricolage font-bold text-[#1F2937] dark:text-white mb-2">
              Relief Coordination
            </h1>
            <p className="text-gray-600 dark:text-gray-400 max-w-lg">
              {selectedOrg?.name} • Real-time monitoring and response
              coordination
            </p>
          </div>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 px-6 py-3 bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl font-semibold text-sm shadow-sm hover:shadow-md hover:border-gray-300 transition-all">
              <Download size={16} /> Export
            </button>
            <button
              onClick={() => setIsAlertModalOpen(true)}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-2xl font-semibold text-sm shadow-lg shadow-blue-200 hover:shadow-blue-300 hover:from-blue-600 hover:to-blue-700 transition-all"
            >
              <Send size={16} /> Send Alert
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            {
              label: "Active Requests",
              value: sosRequests.filter((r) => r.status === "pending").length,
              icon: AlertTriangle,
              color: "bg-amber-500",
              bgColor: "bg-amber-50",
              textColor: "text-amber-700",
            },
            {
              label: "Safe Members",
              value: households.reduce(
                (acc, h) =>
                  acc + h.members.filter((m) => m.status === "safe").length,
                0,
              ),
              icon: Shield,
              color: "bg-emerald-500",
              bgColor: "bg-emerald-50",
              textColor: "text-emerald-700",
            },
            {
              label: "Water Stock",
              value:
                inventory.find((i) => i.category === "water")?.quantity || 0,
              icon: Package,
              color: "bg-blue-500",
              bgColor: "bg-blue-50",
              textColor: "text-blue-700",
            },
            {
              label: "Team Members",
              value: households.reduce((acc, h) => acc + h.members.length, 0),
              icon: Users,
              color: "bg-purple-500",
              bgColor: "bg-purple-50",
              textColor: "text-purple-700",
            },
          ].map((stat, i) => (
            <div
              key={i}
              className="bg-white dark:bg-[#1E1E1E] p-6 rounded-3xl border border-gray-100 dark:border-[#2A2A2A] shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-2xl ${stat.bgColor}`}>
                  <stat.icon size={24} className={stat.textColor} />
                </div>
              </div>
              <div className="text-3xl font-bricolage font-bold text-[#1F2937] dark:text-white mb-1">
                {stat.value}
              </div>
              <div className="text-sm font-medium text-gray-500 dark:text-gray-400">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Map View */}
          <div className="lg:col-span-8 space-y-8">
            <div className="bg-white dark:bg-[#1E1E1E] rounded-[32px] border border-[#EEF2FA] dark:border-[#2A2A2A] overflow-hidden shadow-sm h-[600px] relative">
              <div className="absolute top-6 left-6 z-10 flex gap-2">
                <div className="bg-white/90 backdrop-blur px-4 py-2 rounded-xl border border-gray-200 shadow-sm flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                  <span className="text-sm font-bold text-[#1B2E54]">
                    LIVE TRACKING
                  </span>
                </div>
              </div>

              <APIProvider apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}>
                <Map
                  defaultCenter={{ lat: 34.0522, lng: -118.2437 }}
                  defaultZoom={13}
                  mapId="AERA_EMERGENCY_MAP"
                  style={{ width: "100%", height: "100%" }}
                >
                  {sosRequests.map((req) => (
                    <Marker
                      key={req.id}
                      position={{ lat: req.latitude, lng: req.longitude }}
                      title={`SOS: ${req.reporter_name}`}
                      onClick={() => console.log("Clicked SOS", req.id)}
                    />
                  ))}
                </Map>
              </APIProvider>
            </div>

            {/* Inventory List */}
            <div className="bg-white dark:bg-[#1E1E1E] rounded-[32px] border border-[#EEF2FA] dark:border-[#2A2A2A] p-8 shadow-sm">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-bricolage font-extrabold text-[#1B2E54] dark:text-white">
                  Inventory Stock Level
                </h3>
                <button className="text-blue-600 font-bold text-sm hover:underline">
                  Manage All
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {inventory.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl bg-gray-50 dark:bg-[#2A2A2A] flex items-center gap-4"
                  >
                    <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600">
                      <Package size={24} />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <span className="font-bold text-[#1B2E54] dark:text-white">
                          {item.item_name}
                        </span>
                        <span className="text-sm font-medium text-gray-500">
                          {item.quantity} / {item.capacity} {item.unit}
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${item.quantity / item.capacity < 0.2 ? "bg-red-500" : "bg-blue-500"}`}
                          style={{
                            width: `${(item.quantity / item.capacity) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar Action Center */}
          <div className="lg:col-span-4 space-y-8">
            {/* SOS Requests List */}
            <div className="bg-white dark:bg-[#1E1E1E] rounded-[32px] border border-[#EEF2FA] dark:border-[#2A2A2A] p-6 shadow-sm max-h-[500px] flex flex-col">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bricolage font-extrabold text-[#1B2E54] dark:text-white">
                  SOS Queue
                </h3>
                <div className="px-3 py-1 bg-red-50 text-red-600 rounded-full text-xs font-bold">
                  {sosRequests.filter((r) => r.status === "pending").length}{" "}
                  ACTIVE
                </div>
              </div>
              <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                {sosRequests.map((req) => (
                  <div
                    key={req.id}
                    className={`p-4 rounded-2xl border transition-all hover:scale-[1.01] ${
                      req.priority === "high"
                        ? "border-red-200 bg-red-50 dark:bg-red-900/10"
                        : "border-gray-100 bg-gray-50 dark:bg-[#2A2A2A]"
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-bold text-[#1B2E54] dark:text-white">
                        {req.reporter_name}
                      </span>
                      <span
                        className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded ${
                          req.priority === "high"
                            ? "bg-red-500 text-white"
                            : "bg-orange-500 text-white"
                        }`}
                      >
                        {req.priority}
                      </span>
                    </div>
                    <p className="text-sm text-[#5C6F92] dark:text-gray-400 mb-4 line-clamp-2">
                      {req.message}
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() =>
                          updateSOSMutation.mutate({
                            id: req.id,
                            status: "responding",
                          })
                        }
                        className="flex-1 py-2 bg-white dark:bg-[#1E1E1E] border border-gray-200 text-[#1B2E54] dark:text-white rounded-xl text-xs font-bold hover:bg-gray-100 transition-colors"
                      >
                        Dispatch
                      </button>
                      <button
                        onClick={() =>
                          updateSOSMutation.mutate({
                            id: req.id,
                            status: "resolved",
                          })
                        }
                        className="px-4 py-2 bg-green-500 text-white rounded-xl text-xs font-bold hover:bg-green-600 transition-colors"
                      >
                        Resolve
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Safety Overview */}
            <div className="bg-white dark:bg-[#1E1E1E] rounded-[32px] border border-[#EEF2FA] dark:border-[#2A2A2A] p-6 shadow-sm">
              <h3 className="text-lg font-bricolage font-extrabold text-[#1B2E54] dark:text-white mb-6">
                Safety Overview
              </h3>
              <div className="h-40 mb-6">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      {
                        name: "Safe",
                        count: households.reduce(
                          (acc, h) =>
                            acc +
                            h.members.filter((m) => m.status === "safe").length,
                          0,
                        ),
                        fill: "#22C55E",
                      },
                      {
                        name: "Unknown",
                        count: households.reduce(
                          (acc, h) =>
                            acc +
                            h.members.filter((m) => m.status === "unknown")
                              .length,
                          0,
                        ),
                        fill: "#94A3B8",
                      },
                      {
                        name: "At Risk",
                        count: households.reduce(
                          (acc, h) =>
                            acc +
                            h.members.filter(
                              (m) =>
                                m.status === "unsafe" ||
                                m.status === "needs_help",
                            ).length,
                          0,
                        ),
                        fill: "#EF4444",
                      },
                    ]}
                  >
                    <Bar dataKey="count" radius={[8, 8, 0, 0]} />
                    <XAxis
                      dataKey="name"
                      axisLine={false}
                      tickLine={false}
                      fontSize={12}
                    />
                    <Tooltip />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-3">
                {households.slice(0, 3).map((h) => (
                  <div
                    key={h.id}
                    className="flex items-center justify-between p-3 bg-gray-50 dark:bg-[#2A2A2A] rounded-xl"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span className="text-sm font-bold text-[#1B2E54] dark:text-white">
                        {h.name}
                      </span>
                    </div>
                    <span className="text-xs font-medium text-gray-500">
                      {h.members.length} members
                    </span>
                  </div>
                ))}
                <button className="w-full py-3 text-[#1A5DFF] text-sm font-bold border border-blue-100 rounded-2xl hover:bg-blue-50 transition-colors">
                  View All Households
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
