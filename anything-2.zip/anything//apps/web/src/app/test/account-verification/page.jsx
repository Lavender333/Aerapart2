"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import { CheckCircle, XCircle, AlertCircle } from "lucide-react";

export default function AccountVerificationPage() {
  const { data: user, loading: userLoading } = useUser();
  const [verification, setVerification] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!userLoading && user) {
      fetchVerification();
    } else if (!userLoading && !user) {
      setLoading(false);
    }
  }, [user, userLoading]);

  const fetchVerification = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/test/verify-account");
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to verify account");
      }

      setVerification(data);
      setLoading(false);
    } catch (err) {
      console.error("Error:", err);
      setError(err.message);
      setLoading(false);
    }
  };

  if (loading || userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl p-8">
          <div className="text-center">
            <AlertCircle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Not Signed In
            </h1>
            <p className="text-gray-600 mb-6">
              You need to sign in to verify your account
            </p>
            <a
              href="/account/signin"
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
            >
              Sign In
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Account Verification
            </h1>
            <p className="text-gray-600">
              Check if your account data is properly stored in the database
            </p>
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
              {error}
            </div>
          )}

          {verification && (
            <div className="space-y-6">
              {/* User Info */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                  User Account
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-gray-700">ID:</span>{" "}
                    <span className="text-gray-900">
                      {verification.user.id}
                    </span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Email:</span>{" "}
                    <span className="text-gray-900">
                      {verification.user.email}
                    </span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Name:</span>{" "}
                    <span className="text-gray-900">
                      {verification.user.name || "(Not set)"}
                    </span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Role:</span>{" "}
                    <span className="text-gray-900">
                      {verification.user.system_role}
                    </span>
                  </div>
                </div>
              </div>

              {/* Auth Accounts */}
              <div
                className={`rounded-lg p-6 ${verification.summary.hasAccount ? "bg-green-50" : "bg-yellow-50"}`}
              >
                <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  {verification.summary.hasAccount ? (
                    <CheckCircle className="w-6 h-6 text-green-500" />
                  ) : (
                    <XCircle className="w-6 h-6 text-yellow-500" />
                  )}
                  Authentication Credentials
                </h2>
                {verification.accounts.length > 0 ? (
                  <div className="space-y-2">
                    {verification.accounts.map((account) => (
                      <div
                        key={account.id}
                        className="bg-white rounded p-3 text-sm"
                      >
                        <span className="font-medium text-gray-700">Type:</span>{" "}
                        <span className="text-gray-900">{account.type}</span>
                        {" | "}
                        <span className="font-medium text-gray-700">
                          Provider:
                        </span>{" "}
                        <span className="text-gray-900">
                          {account.provider}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600">
                    No authentication credentials found
                  </p>
                )}
              </div>

              {/* Households */}
              <div
                className={`rounded-lg p-6 ${verification.summary.hasHousehold ? "bg-green-50" : "bg-gray-50"}`}
              >
                <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  {verification.summary.hasHousehold ? (
                    <CheckCircle className="w-6 h-6 text-green-500" />
                  ) : (
                    <AlertCircle className="w-6 h-6 text-gray-400" />
                  )}
                  Household Information
                </h2>
                {verification.households.length > 0 ? (
                  <div className="space-y-2">
                    {verification.households.map((household) => (
                      <div
                        key={household.id}
                        className="bg-white rounded p-3 text-sm"
                      >
                        <div className="font-medium text-gray-900">
                          {household.name}
                        </div>
                        <div className="text-gray-600">{household.address}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600">
                    No household registered{" "}
                    <a
                      href="/account/household-setup"
                      className="text-blue-600 hover:underline"
                    >
                      (Add household)
                    </a>
                  </p>
                )}
              </div>

              {/* Organizations */}
              <div
                className={`rounded-lg p-6 ${verification.summary.hasOrganization ? "bg-green-50" : "bg-gray-50"}`}
              >
                <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  {verification.summary.hasOrganization ? (
                    <CheckCircle className="w-6 h-6 text-green-500" />
                  ) : (
                    <AlertCircle className="w-6 h-6 text-gray-400" />
                  )}
                  Organization Membership
                </h2>
                {verification.organizations.length > 0 ? (
                  <div className="space-y-2">
                    {verification.organizations.map((org) => (
                      <div
                        key={org.id}
                        className="bg-white rounded p-3 text-sm"
                      >
                        <div className="font-medium text-gray-900">
                          {org.org_name}
                        </div>
                        <div className="text-gray-600">Role: {org.role}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600">
                    No organization membership{" "}
                    <a
                      href="/organizations"
                      className="text-blue-600 hover:underline"
                    >
                      (Join or create organization)
                    </a>
                  </p>
                )}
              </div>

              {/* Summary */}
              <div className="bg-blue-50 rounded-lg p-6 border-2 border-blue-200">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  Summary
                </h2>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    {verification.summary.hasAccount ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-500" />
                    )}
                    <span className="text-gray-900">
                      Account credentials:{" "}
                      {verification.summary.hasAccount
                        ? "✓ Stored"
                        : "✗ Missing"}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {verification.summary.hasHousehold ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-gray-400" />
                    )}
                    <span className="text-gray-900">
                      Household info:{" "}
                      {verification.summary.hasHousehold
                        ? "✓ Registered"
                        : "○ Optional"}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {verification.summary.hasOrganization ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-gray-400" />
                    )}
                    <span className="text-gray-900">
                      Organization:{" "}
                      {verification.summary.hasOrganization
                        ? "✓ Member"
                        : "○ Optional"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-4 pt-4">
                <button
                  onClick={fetchVerification}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition-colors"
                >
                  Refresh Data
                </button>
                <a
                  href="/organizations"
                  className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold py-3 rounded-lg transition-colors text-center"
                >
                  Go to Dashboard
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
