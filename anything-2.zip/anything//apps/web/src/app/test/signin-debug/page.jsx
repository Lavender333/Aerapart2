"use client";

import { useState } from "react";

export default function SigninDebugPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const testAccount = async () => {
    setLoading(true);
    setResult(null);

    try {
      console.log("Testing account for:", email);

      // Check if user exists
      const response = await fetch("/api/test/check-account", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      console.log("Test result:", data);
      setResult(data);
    } catch (err) {
      console.error("Test error:", err);
      setResult({ error: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-2xl font-bold mb-6">Sign In Debug Tool</h1>

          <div className="space-y-4 mb-6">
            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg"
                placeholder="Your password"
              />
            </div>

            <button
              onClick={testAccount}
              disabled={loading || !email || !password}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white py-3 rounded-lg font-semibold"
            >
              {loading ? "Testing..." : "Test Account"}
            </button>
          </div>

          {result && (
            <div className="mt-6 p-4 bg-gray-100 rounded-lg">
              <h2 className="font-bold mb-2">Test Results:</h2>
              <pre className="text-xs overflow-auto">
                {JSON.stringify(result, null, 2)}
              </pre>

              {result.userExists && (
                <div className="mt-4 space-y-2">
                  <p className="text-green-600 font-semibold">
                    ✓ User account found!
                  </p>
                  <p>User ID: {result.userId}</p>
                  <p>Name: {result.userName}</p>
                  <p>Email: {result.userEmail}</p>
                  {result.hasPassword ? (
                    <p className="text-green-600">✓ Has password set</p>
                  ) : (
                    <p className="text-red-600">✗ No password found</p>
                  )}
                  {result.passwordValid !== undefined && (
                    <p
                      className={
                        result.passwordValid ? "text-green-600" : "text-red-600"
                      }
                    >
                      {result.passwordValid
                        ? "✓ Password is correct"
                        : "✗ Password is incorrect"}
                    </p>
                  )}
                </div>
              )}

              {!result.userExists && (
                <p className="text-red-600 font-semibold mt-4">
                  ✗ No user found with this email
                </p>
              )}
            </div>
          )}

          <div className="mt-8 p-4 bg-blue-50 rounded-lg text-sm">
            <p className="font-semibold mb-2">Instructions:</p>
            <ol className="list-decimal list-inside space-y-1">
              <li>Enter your email and password</li>
              <li>Click "Test Account"</li>
              <li>Check if your account exists and password is correct</li>
              <li>If everything looks good, try signing in again</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}
