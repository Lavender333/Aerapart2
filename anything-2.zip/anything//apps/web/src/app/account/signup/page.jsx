"use client";

import { useState } from "react";
import useAuth from "@/utils/useAuth";

export default function SignupPage() {
  const [step, setStep] = useState(1); // 1: account info, 2: role & org
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState(""); // 'general_user' or 'org_admin'
  const [orgAction, setOrgAction] = useState(""); // 'create', 'join', 'skip'
  const [orgName, setOrgName] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { signUpWithCredentials, signInWithCredentials } = useAuth();

  const handleStep1 = (e) => {
    e.preventDefault();
    setError("");

    // Validate name
    if (!name || name.trim().length === 0) {
      setError("Please enter your name");
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      setError("Please enter a valid email address");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters");
      return;
    }

    console.log("✅ Step 1 validation passed:", { name, email });
    setStep(2);
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    console.log("🔄 Starting signup process...");
    console.log("User data:", { name, email, role, orgAction });

    try {
      // Validate all required fields before proceeding
      if (!name || !email || !password) {
        throw new Error("Missing required fields");
      }

      // Store additional data in localStorage for onboarding
      if (role) {
        localStorage.setItem("pendingRole", role);
      }
      if (orgAction) {
        localStorage.setItem("pendingOrgAction", orgAction);
      }
      if (orgName) {
        localStorage.setItem("pendingOrgName", orgName);
      }
      if (joinCode) {
        localStorage.setItem("pendingJoinCode", joinCode);
      }

      console.log("🔄 Calling signUpWithCredentials...");

      // Step 1: Create the account (this will auto-signin)
      const result = await signUpWithCredentials({
        email: email.trim(),
        password,
        name: name.trim(),
        callbackUrl: "/account/household-setup",
        redirect: false, // Don't auto-redirect, handle it manually
      });

      console.log("✅ Account created successfully:", result);

      // Send welcome email in background (don't wait for it)
      fetch("/api/notifications/send-welcome-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, name }),
      }).catch((err) => console.error("Welcome email failed:", err));

      // Redirect to household setup
      console.log("🔄 Redirecting to household setup...");
      window.location.href = "/account/household-setup";
    } catch (err) {
      console.error("❌ Signup error:", err);

      // Provide user-friendly error messages
      let errorMessage = "Failed to create account. ";

      if (
        err.message?.includes("already exists") ||
        err.message?.includes("duplicate")
      ) {
        errorMessage =
          "An account with this email already exists. Please sign in instead.";
      } else if (
        err.message?.includes("network") ||
        err.message?.includes("fetch")
      ) {
        errorMessage =
          "Network error. Please check your connection and try again.";
      } else if (err.message) {
        errorMessage += err.message;
      } else {
        errorMessage += "Please try again.";
      }

      setError(errorMessage);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Create Account
          </h1>
          <p className="text-gray-600">
            {step === 1
              ? "Join AERA to coordinate disaster relief"
              : "Tell us about your role"}
          </p>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center space-x-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step >= 1
                  ? "bg-red-600 text-white"
                  : "bg-gray-200 text-gray-600"
              }`}
            >
              1
            </div>
            <div className="w-16 h-1 bg-gray-200"></div>
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step >= 2
                  ? "bg-red-600 text-white"
                  : "bg-gray-200 text-gray-600"
              }`}
            >
              2
            </div>
          </div>
        </div>

        {/* Step 1: Account Information */}
        {step === 1 && (
          <form onSubmit={handleStep1} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Full Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                placeholder="At least 8 characters"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Confirm Password
              </label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                placeholder="Re-enter your password"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 rounded-lg transition-colors"
            >
              Continue
            </button>
          </form>
        )}

        {/* Step 2: Role & Organization */}
        {step === 2 && (
          <form onSubmit={handleSignup} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            {/* Role Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                What describes you best?
              </label>
              <div className="space-y-3">
                <label className="flex items-start p-4 border-2 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                  <input
                    type="radio"
                    name="role"
                    value="general_user"
                    checked={role === "general_user"}
                    onChange={(e) => {
                      setRole(e.target.value);
                      setOrgAction("");
                    }}
                    className="mt-1 mr-3"
                  />
                  <div>
                    <div className="font-semibold text-gray-900">
                      General User
                    </div>
                    <div className="text-sm text-gray-600">
                      Need help during a disaster or want to request assistance
                    </div>
                  </div>
                </label>

                <label className="flex items-start p-4 border-2 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                  <input
                    type="radio"
                    name="role"
                    value="org_admin"
                    checked={role === "org_admin"}
                    onChange={(e) => {
                      setRole(e.target.value);
                      setOrgAction("");
                    }}
                    className="mt-1 mr-3"
                  />
                  <div>
                    <div className="font-semibold text-gray-900">
                      Organization Admin
                    </div>
                    <div className="text-sm text-gray-600">
                      Manage disaster relief operations and help requests
                    </div>
                  </div>
                </label>
              </div>
            </div>

            {/* Organization Options */}
            {role && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Organization
                </label>
                <div className="space-y-3">
                  {role === "org_admin" && (
                    <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                      <input
                        type="radio"
                        name="orgAction"
                        value="create"
                        checked={orgAction === "create"}
                        onChange={(e) => setOrgAction(e.target.value)}
                        className="mr-3"
                      />
                      <span className="text-gray-900">
                        Create a new organization
                      </span>
                    </label>
                  )}

                  <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                    <input
                      type="radio"
                      name="orgAction"
                      value="join"
                      checked={orgAction === "join"}
                      onChange={(e) => setOrgAction(e.target.value)}
                      className="mr-3"
                    />
                    <span className="text-gray-900">
                      Join an existing organization
                    </span>
                  </label>

                  <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                    <input
                      type="radio"
                      name="orgAction"
                      value="skip"
                      checked={orgAction === "skip"}
                      onChange={(e) => setOrgAction(e.target.value)}
                      className="mr-3"
                    />
                    <span className="text-gray-900">Skip for now</span>
                  </label>
                </div>
              </div>
            )}

            {/* Create Organization */}
            {orgAction === "create" && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Organization Name
                </label>
                <input
                  type="text"
                  required
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                  placeholder="Red Cross LA Chapter"
                />
              </div>
            )}

            {/* Join Organization */}
            {orgAction === "join" && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Organization Join Code
                </label>
                <input
                  type="text"
                  required
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                  placeholder="Enter 6-character code"
                  maxLength={6}
                />
                <p className="text-sm text-gray-500 mt-2">
                  Ask your organization admin for the join code
                </p>
              </div>
            )}

            <div className="flex space-x-3">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold py-3 rounded-lg transition-colors"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={loading || !role || !orgAction}
                className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white font-semibold py-3 rounded-lg transition-colors"
              >
                {loading ? "Creating Account..." : "Complete Signup"}
              </button>
            </div>
          </form>
        )}

        <div className="mt-6 text-center">
          <p className="text-gray-600 text-sm">
            Already have an account?{" "}
            <a
              href="/account/signin"
              className="text-red-600 hover:text-red-700 font-medium"
            >
              Sign In
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
