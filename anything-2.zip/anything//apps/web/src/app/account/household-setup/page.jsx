"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import { Plus, Trash2, Users } from "lucide-react";

export default function HouseholdSetupPage() {
  const { data: user, loading: isLoading } = useUser();
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  // Household info
  const [householdName, setHouseholdName] = useState("");
  const [address, setAddress] = useState("");
  const [primaryPhone, setPrimaryPhone] = useState("");

  // Members list
  const [members, setMembers] = useState([
    {
      name: "",
      age: "",
      memberType: "adult",
      medicalConditions: "",
      phone: "",
      email: "",
      notes: "",
    },
  ]);

  useEffect(() => {
    if (!isLoading && !user) {
      if (typeof window !== "undefined") {
        window.location.href = "/account/signin";
      }
    }
  }, [user, isLoading]);

  const addMember = () => {
    setMembers([
      ...members,
      {
        name: "",
        age: "",
        memberType: "adult",
        medicalConditions: "",
        phone: "",
        email: "",
        notes: "",
      },
    ]);
  };

  const removeMember = (index) => {
    setMembers(members.filter((_, i) => i !== index));
  };

  const updateMember = (index, field, value) => {
    const updated = [...members];
    updated[index][field] = value;
    setMembers(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);

    console.log("🔄 Submitting household information...");

    try {
      let orgId = null;

      // Step 1: Process organization FIRST to get org_id
      if (typeof window !== "undefined") {
        const role = localStorage.getItem("pendingRole");
        const orgAction = localStorage.getItem("pendingOrgAction");
        const orgName = localStorage.getItem("pendingOrgName");
        const joinCode = localStorage.getItem("pendingJoinCode");

        console.log("🔄 Processing organization data...", {
          role,
          orgAction,
          orgName,
          joinCode,
        });

        if (role === "org_admin" && orgAction === "create" && orgName) {
          console.log("🔄 Creating organization...");
          const orgRes = await fetch("/api/organizations", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name: orgName, userId: user?.id }),
          });

          if (!orgRes.ok) {
            throw new Error("Failed to create organization");
          }

          const orgData = await orgRes.json();
          orgId = orgData.id;
          console.log("✅ Organization created with ID:", orgId);
        } else if (orgAction === "join" && joinCode) {
          console.log("🔄 Joining organization with code:", joinCode);
          const joinRes = await fetch("/api/organizations/join", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code: joinCode, role: role }),
          });

          if (!joinRes.ok) {
            const errorData = await joinRes.json();
            throw new Error(errorData.error || "Failed to join organization");
          }

          const joinData = await joinRes.json();
          orgId = joinData.organization?.id;
          console.log("✅ Joined organization with ID:", orgId);
        }

        // Clear localStorage
        localStorage.removeItem("pendingRole");
        localStorage.removeItem("pendingOrgAction");
        localStorage.removeItem("pendingOrgName");
        localStorage.removeItem("pendingJoinCode");
      }

      // Step 2: Save household information WITH org_id
      console.log("🔄 Sending household data to API with org_id:", orgId);
      const householdRes = await fetch("/api/disaster-relief/household", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          householdName,
          address,
          primaryPhone,
          members: members.filter((m) => m.name.trim() !== ""),
          orgId: orgId, // Include the org_id we got from joining/creating
        }),
      });

      const householdData = await householdRes.json();
      console.log("API response:", householdData);

      if (!householdRes.ok) {
        console.error("❌ API error:", householdData);
        throw new Error(
          householdData.error || "Failed to save household information",
        );
      }

      console.log(
        "✅ Household saved successfully with ID:",
        householdData.householdId,
      );

      // Redirect to member home (where members should go)
      console.log("🔄 Redirecting to member home...");
      window.location.href = "/member-home";
    } catch (err) {
      console.error("❌ Error during household submission:", err);
      setError(err.message);
      setSaving(false);
    }
  };

  const handleSkip = async () => {
    // Still process organization info even if skipping household
    if (typeof window !== "undefined") {
      try {
        const role = localStorage.getItem("pendingRole");
        const orgAction = localStorage.getItem("pendingOrgAction");
        const orgName = localStorage.getItem("pendingOrgName");
        const joinCode = localStorage.getItem("pendingJoinCode");

        if (role === "org_admin" && orgAction === "create" && orgName) {
          await fetch("/api/organizations", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name: orgName, userId: user?.id }),
          });
        } else if (orgAction === "join" && joinCode) {
          await fetch("/api/organizations/join", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code: joinCode, role: role }),
          });
        }

        localStorage.removeItem("pendingRole");
        localStorage.removeItem("pendingOrgAction");
        localStorage.removeItem("pendingOrgName");
        localStorage.removeItem("pendingJoinCode");
      } catch (err) {
        console.error("Error processing organization:", err);
      }

      // Redirect to member home instead of organizations
      window.location.href = "/member-home";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
              <Users className="w-8 h-8 text-red-600" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Household Information
            </h1>
            <p className="text-gray-600">
              Register your household before emergencies occur. This helps
              responders know who to look for and any special needs.
            </p>
          </div>

          {/* Progress indicator */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center gap-2">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step === 1
                    ? "bg-red-600 text-white"
                    : "bg-green-500 text-white"
                }`}
              >
                1
              </div>
              <div className="w-12 h-1 bg-gray-300"></div>
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step === 2
                    ? "bg-red-600 text-white"
                    : "bg-gray-300 text-gray-600"
                }`}
              >
                2
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit}>
            {error && (
              <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            {/* Step 1: Household Info */}
            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Household Name
                  </label>
                  <input
                    type="text"
                    required
                    value={householdName}
                    onChange={(e) => setHouseholdName(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                    placeholder="e.g., Smith Family"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Home Address
                  </label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                    placeholder="123 Main St, City, State ZIP"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Primary Contact Phone
                  </label>
                  <input
                    type="tel"
                    required
                    value={primaryPhone}
                    onChange={(e) => setPrimaryPhone(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                    placeholder="(555) 123-4567"
                  />
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-3 rounded-lg transition-colors"
                  >
                    Continue to Household Members
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Household Members */}
            {step === 2 && (
              <div className="space-y-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-gray-900">
                    Household Members
                  </h2>
                  <button
                    type="button"
                    onClick={addMember}
                    className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    Add Member
                  </button>
                </div>

                <p className="text-sm text-gray-600 mb-4">
                  Add everyone in your household including children, elderly,
                  and pets. This information helps emergency responders.
                </p>

                {members.map((member, index) => (
                  <div
                    key={index}
                    className="border border-gray-200 rounded-lg p-6 space-y-4 bg-gray-50"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium text-gray-900">
                        Member {index + 1}
                      </h3>
                      {members.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeMember(index)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Name *
                        </label>
                        <input
                          type="text"
                          required={index === 0}
                          value={member.name}
                          onChange={(e) =>
                            updateMember(index, "name", e.target.value)
                          }
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                          placeholder="Full name"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Age
                        </label>
                        <input
                          type="number"
                          value={member.age}
                          onChange={(e) =>
                            updateMember(index, "age", e.target.value)
                          }
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                          placeholder="Age"
                          min="0"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Type *
                        </label>
                        <select
                          value={member.memberType}
                          onChange={(e) =>
                            updateMember(index, "memberType", e.target.value)
                          }
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                        >
                          <option value="adult">Adult</option>
                          <option value="child">Child</option>
                          <option value="elderly">Elderly</option>
                          <option value="pet">Pet/Animal</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Phone
                        </label>
                        <input
                          type="tel"
                          value={member.phone}
                          onChange={(e) =>
                            updateMember(index, "phone", e.target.value)
                          }
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                          placeholder="(555) 123-4567"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          value={member.email}
                          onChange={(e) =>
                            updateMember(index, "email", e.target.value)
                          }
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                          placeholder="email@example.com"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Medical Conditions
                        </label>
                        <input
                          type="text"
                          value={member.medicalConditions}
                          onChange={(e) =>
                            updateMember(
                              index,
                              "medicalConditions",
                              e.target.value,
                            )
                          }
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                          placeholder="Diabetes, allergies, etc."
                        />
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Additional Notes
                        </label>
                        <textarea
                          value={member.notes}
                          onChange={(e) =>
                            updateMember(index, "notes", e.target.value)
                          }
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                          placeholder="Any other important information"
                          rows="2"
                        />
                      </div>
                    </div>
                  </div>
                ))}

                <div className="flex gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 border border-gray-300 hover:bg-gray-50 text-gray-700 font-semibold py-3 rounded-lg transition-colors"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white font-semibold py-3 rounded-lg transition-colors"
                  >
                    {saving ? "Saving..." : "Save Household Information"}
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleSkip}
                  className="w-full text-gray-600 hover:text-gray-700 text-sm font-medium py-2"
                >
                  Skip for now
                </button>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}
