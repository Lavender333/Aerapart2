"use client";

import { useState } from "react";
import useAuth from "@/utils/useAuth";

export default function SigninPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { signInWithCredentials } = useAuth();

  const handleSignin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    console.log("🔄 Starting signin process...");

    try {
      const result = await signInWithCredentials({
        email: email.trim(),
        password,
        callbackUrl: "/",
        redirect: false,
      });

      console.log("✅ SignIn result:", result);

      if (result?.error) {
        console.error("❌ SignIn error from result:", result.error);
        throw new Error(result.error);
      }

      if (result?.ok) {
        console.log("✅ SignIn successful! Checking user role...");

        // Wait a moment for the session to be established
        await new Promise((resolve) => setTimeout(resolve, 500));

        // Check if user is a system admin
        try {
          const userResponse = await fetch("/api/users/role");
          if (userResponse.ok) {
            const userData = await userResponse.json();
            console.log("User data:", userData);

            // Fix: Access the correct property path
            if (userData.user?.system_role === "system_admin") {
              console.log("🔐 Admin detected, redirecting to /admin");
              window.location.href = "/admin";
              return;
            }
          }
        } catch (err) {
          console.error("Could not check user role:", err);
          // Continue with normal redirect if role check fails
        }

        console.log("✅ Regular user, redirecting to default page");
        window.location.href = result.url || "/";
      } else {
        console.error("❌ SignIn failed - no error but not ok:", result);
        throw new Error("Invalid email or password");
      }
    } catch (err) {
      console.error("❌ SignIn exception:", err);

      let errorMessage = "Invalid email or password";

      if (err.message?.includes("fetch") || err.message?.includes("network")) {
        errorMessage =
          "Network error. Please check your connection and try again.";
      } else if (
        err.message?.includes("credentials") ||
        err.message?.includes("CredentialsSignin")
      ) {
        errorMessage =
          "Invalid email or password. Please check your credentials.";
      } else if (err.message) {
        errorMessage = err.message;
      }

      setError(errorMessage);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome Back
          </h1>
          <p className="text-gray-600">Sign in to AERA</p>
        </div>

        <form onSubmit={handleSignin} className="space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Address
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
              placeholder="you@example.com"
              autoComplete="email"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <a
                href="/account/forgot-password"
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                Forgot Password?
              </a>
            </div>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
              placeholder="Enter your password"
              autoComplete="current-password"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white font-semibold py-3 rounded-lg transition-colors"
          >
            {loading ? "Signing In..." : "Sign In"}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-gray-600 text-sm">
            Don't have an account?{" "}
            <a
              href="/account/signup"
              className="text-red-600 hover:text-red-700 font-medium"
            >
              Sign Up
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
